/*! Quality Construction & Restoration LLC — "How we build a home" cinematic hero background.
 * Dependency-free WebGL2. Loaded on demand by src/components/QCRHeroBackground.tsx.
 * API: window.QCRHero3D.mount(heroSection, hostDiv) → { destroy(), pause(), play(), seek(t) }
 * Preview helpers (URL): ?debug  ?t=12 (freeze)  ?quality=high|mid|low
 */
/* ==========================================================================================
   QUALITY CONSTRUCTION & RESTORATION LLC — "HOW WE BUILD A HOME"
   Real-time cinematic hero background. Dependency-free WebGL2 (no Three.js / no CDN, so the
   hero never waits on a large download): instanced procedural geometry, shadow-mapped sun,
   procedural PBR-style materials, HDR bloom, one deterministic 30 s timeline that loops.

   Code map:
     0  Config · quality tiers                10  Blueprint system (lines, labels)
     1  Math · tracks                         11  House model: foundation · framing · roof
     2  Renderer (WebGL2, programs, targets)       exterior · interior · kitchen · bath
     3  Materials (procedural shader library) 12  Environment: terrain · trees · street
     4  Lighting (sun, sky, shadows, lights)  13  Construction timeline + lighting keys
     5  Terrain                               14  Responsive camera
     6  Particles (dust, rain)                15  Final reveal + QCR transition
     7  Instanced construction renderer       16  Frame composition
     8  Lines · sprites · labels              17  Performance · reduced motion · lifecycle
   ========================================================================================== */
(function () {
'use strict';
/* mount(heroSection, hostElement?) → { destroy, pause, play, seek } — safe to call repeatedly (SPA routes, React StrictMode) */
function mount(HERO, HOST_IN) {

/* =====================================================================================
   0 · CONFIG & QUALITY TIERS
   ===================================================================================== */
if (!HERO) return null;
const HOST = HOST_IN || HERO.querySelector('.qcr-hero__bg');
if (!HOST) return null;
let destroyed = false;
const QS = new URLSearchParams(location.search);
const num = (v, d) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };
const LOOP = 30;
const CFG = {
  focusX: num(HERO.dataset.focusX, 0.3),
  focusYMobile: num(HERO.dataset.focusYMobile, -0.34),
  freeze: QS.has('t') ? num(QS.get('t'), 0) : null,
  speed: num(QS.get('speed'), 1),
  debug: QS.has('debug'),
};
if (QS.get('ui') === '0') HERO.classList.add('qcr-hero--no-ui');

const canvasEl = document.createElement('canvas');
HOST.appendChild(canvasEl);
const gl = canvasEl.getContext('webgl2', { antialias: false, alpha: false, depth: false, stencil: false, powerPreference: 'high-performance' });
if (!gl) { canvasEl.remove(); return null; }        // static background image remains
const EXT_CBF = gl.getExtension('EXT_color_buffer_float');
const EXT_ANISO = gl.getExtension('EXT_texture_filter_anisotropic');

function detectTier() {
  const forced = QS.get('quality'); if (forced) return forced;
  const dbg = gl.getExtension('WEBGL_debug_renderer_info');
  const gpu = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
  if (/swiftshader|llvmpipe|software|mali-4|adreno \(tm\) [34]/i.test(gpu)) return 'low';
  const coarse = matchMedia('(pointer: coarse)').matches, small = Math.min(screen.width, screen.height) < 820;
  const cores = navigator.hardwareConcurrency || 4, mem = navigator.deviceMemory || 8;
  if (coarse && small) return (cores >= 8 && mem >= 6) ? 'mid' : 'low';
  if (cores <= 4 || mem <= 4) return 'mid';
  return 'high';
}
const TIER = detectTier();
/* maxPix caps the internal resolution (the lit shader is the dominant cost) */
const Q = {
  high: { dpr: 1.5, maxPix: 3.7e6, bloom: true, bloomLv: 5, msaa: 4, shadow: 2048, pcf: 1, lights: 20, dust: 900, rain: 1600, trees: 1, detail: 1 },
  mid:  { dpr: 1.25, maxPix: 2.2e6, bloom: true, bloomLv: 4, msaa: 0, shadow: 1536, pcf: 1, lights: 14, dust: 500, rain: 1000, trees: .8, detail: 1 },
  low:  { dpr: 1.0, maxPix: 1.1e6, bloom: false, bloomLv: 0, msaa: 0, shadow: 1024, pcf: 0, lights: 10, dust: 250, rain: 600, trees: .6, detail: 0 },
}[TIER];
const REDUCED = matchMedia('(prefers-reduced-motion: reduce)');
const STATIC_T = 28.5;                                 // finished home at dusk, in the hero composition

/* =====================================================================================
   1 · MATH & TRACKS
   ===================================================================================== */
const TAU = Math.PI * 2, DEG = Math.PI / 180;
const clamp = (x, a = 0, b = 1) => x < a ? a : x > b ? b : x;
const lerp = (a, b, k) => a + (b - a) * k;
const sstep = (a, b, x) => { const k = clamp((x - a) / (b - a)); return k * k * (3 - 2 * k); };
const win = (t, a, b, fi = .4, fo = .4) => sstep(a, a + fi, t) * (1 - sstep(b - fo, b, t));
const eio = k => k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
const bump = (t, c, w) => Math.exp(-Math.pow((t - c) / w, 2));
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s], dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: a => Math.hypot(a[0], a[1], a[2]), norm: a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
  mix: (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)],
};
function lookAtM(eye, f, r, u, out) {
  out[0] = r[0]; out[1] = u[0]; out[2] = -f[0]; out[3] = 0; out[4] = r[1]; out[5] = u[1]; out[6] = -f[1]; out[7] = 0;
  out[8] = r[2]; out[9] = u[2]; out[10] = -f[2]; out[11] = 0; out[12] = -v3.dot(r, eye); out[13] = -v3.dot(u, eye); out[14] = v3.dot(f, eye); out[15] = 1; return out;
}
function mul4(a, b, o = new Float32Array(16)) { for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }

/* Monotone cubic Hermite track (C1, no overshoot). Loop mode wraps tangents across t=T. */
class Track {
  constructor(keys, loopT = null) { this.k = keys.map(r => ({ t: r[0], v: r.slice(1) })); this.n = this.k.length; this.dim = this.k[0].v.length; this.loopT = loopT; this.m = this.k.map((_, i) => this.tan(i)); }
  key(i) { const n = this.n; if (i >= 0 && i < n) return this.k[i]; if (this.loopT == null) return null;
    if (i < 0) { const s = this.k[n - 1 + i]; return { t: s.t - this.loopT, v: s.v }; } const s = this.k[i - n + 1]; return { t: s.t + this.loopT, v: s.v }; }
  tan(i) { const p = this.key(i - 1), c = this.k[i], nx = this.key(i + 1), m = [];
    for (let j = 0; j < this.dim; j++) {
      const dp = p ? (c.v[j] - p.v[j]) / (c.t - p.t) : null, dn = nx ? (nx.v[j] - c.v[j]) / (nx.t - c.t) : null;
      if (dp === null) { m.push(dn); continue; } if (dn === null) { m.push(dp); continue; } if (dp * dn <= 0) { m.push(0); continue; }
      const cr = (nx.v[j] - p.v[j]) / (nx.t - p.t), lim = 3 * Math.min(Math.abs(dp), Math.abs(dn)); m.push(Math.sign(cr) * Math.min(Math.abs(cr), lim));
    } return m; }
  eval(t, out = []) { const k = this.k, n = this.n;
    if (t <= k[0].t) { for (let j = 0; j < this.dim; j++) out[j] = k[0].v[j]; return out; }
    if (t >= k[n - 1].t) { for (let j = 0; j < this.dim; j++) out[j] = k[n - 1].v[j]; return out; }
    let i = 0; while (i < n - 2 && t > k[i + 1].t) i++;
    const a = k[i], b = k[i + 1], h = b.t - a.t, s = (t - a.t) / h, s2 = s * s, s3 = s2 * s;
    const h00 = 2 * s3 - 3 * s2 + 1, h10 = s3 - 2 * s2 + s, h01 = -2 * s3 + 3 * s2, h11 = s3 - s2;
    for (let j = 0; j < this.dim; j++) out[j] = h00 * a.v[j] + h10 * h * this.m[i][j] + h01 * b.v[j] + h11 * h * this.m[i + 1][j];
    return out; }
}

/* =====================================================================================
   2 · RENDERER — programs, meshes, render targets, shadow map, bloom
   ===================================================================================== */
const VS_HEAD = `#version 300 es
precision highp float;
uniform mat4 uView, uProj; uniform vec3 uCamPos, uCamRight, uCamUp, uCamFwd; uniform float uTime, uT, uPS;
`;
const FS_HEAD = `#version 300 es
precision highp float;
precision highp sampler2DShadow;
uniform float uTime, uT, uBoost;
out vec4 o;
float h21(vec2 p){ p = fract(p*vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x*p.y); }
float n21(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3. - 2.*f); return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p){ float v = 0., a = .5; for (int i = 0; i < 4; i++){ v += a*n21(p); p = p*2.03 + 17.1; a *= .5; } return v; }
float n31(vec3 p){ return n21(p.xz*1.3 + p.y*vec2(3.17, 1.93)); }
`;
const ATTR_LOCS = { aPos: 0, aN: 1, i0: 2, i1: 3, i2: 4, i3: 5, i4: 6, i5: 7, i6: 8, i7: 9 };
class Program {
  constructor(vs, fs, name, head = true) {
    const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { const log = gl.getShaderInfoLog(s); console.error(name, log, src.split('\n').map((l, i) => (i + 1) + ': ' + l).join('\n').slice(0, 20000)); throw new Error(name + ': ' + log); } return s; };
    const p = gl.createProgram();
    gl.attachShader(p, mk(gl.VERTEX_SHADER, (head ? VS_HEAD : '') + vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, (head ? FS_HEAD : '') + fs));
    for (const n in ATTR_LOCS) gl.bindAttribLocation(p, ATTR_LOCS[n], n);
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(name + ' link: ' + gl.getProgramInfoLog(p));
    this.p = p; this.u = {}; this.a = {};
    for (let i = 0, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS); i < n; i++) { const info = gl.getActiveUniform(p, i); this.u[info.name.replace(/\[0\]$/, '')] = { loc: gl.getUniformLocation(p, info.name), type: info.type }; }
    for (let i = 0, n = gl.getProgramParameter(p, gl.ACTIVE_ATTRIBUTES); i < n; i++) { const info = gl.getActiveAttrib(p, i); this.a[info.name] = gl.getAttribLocation(p, info.name); }
  }
  use(uniforms) {
    gl.useProgram(this.p); let unit = 0;
    for (const name in this.u) {
      const val = uniforms[name] !== undefined ? uniforms[name] : GLOBAL[name]; if (val === undefined) continue;
      const { loc, type } = this.u[name];
      switch (type) {
        case gl.FLOAT: gl.uniform1f(loc, val); break;
        case gl.FLOAT_VEC2: gl.uniform2fv(loc, val); break;
        case gl.FLOAT_VEC3: gl.uniform3fv(loc, val); break;
        case gl.FLOAT_VEC4: gl.uniform4fv(loc, val); break;
        case gl.FLOAT_MAT4: gl.uniformMatrix4fv(loc, false, val); break;
        case gl.INT: case gl.BOOL: gl.uniform1i(loc, val); break;
        case gl.SAMPLER_2D: case gl.SAMPLER_2D_SHADOW: gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, val); gl.uniform1i(loc, unit++); break;
      }
    }
  }
}
const GLOBAL = {};
const STATS = { calls: 0 };
function setBlend(b) {
  if (b === 'none') { gl.disable(gl.BLEND); return; }
  gl.enable(gl.BLEND);
  if (b === 'add') gl.blendFunc(gl.ONE, gl.ONE); else gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
}
function setDepth(d) {           // 'none' | 'test' (read-only) | 'write'
  if (d === 'none') { gl.disable(gl.DEPTH_TEST); gl.depthMask(false); return; }
  gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.depthMask(d === 'write');
}
function mesh(prog, { attribs, index, mode = gl.TRIANGLES, count }) {
  const vao = gl.createVertexArray(); gl.bindVertexArray(vao); const bufs = {};
  for (const name in attribs) {
    const a = attribs[name], buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, a.data, a.dynamic ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW);
    bufs[name] = buf; const loc = prog.a[name]; if (loc === undefined || loc < 0) continue;
    gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, a.size, gl.FLOAT, false, 0, 0); if (a.divisor) gl.vertexAttribDivisor(loc, a.divisor);
  }
  if (index) { const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, index, gl.STATIC_DRAW); }
  gl.bindVertexArray(null);
  const itype = index instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
  return {
    vao, bufs, count: count ?? (index ? index.length : 0),
    draw(uniforms = {}, { blend = 'add', depth = 'none', instances = 0 } = {}) {
      setBlend(blend); setDepth(depth); prog.use(uniforms); gl.bindVertexArray(vao);
      if (instances) index ? gl.drawElementsInstanced(mode, this.count, itype, 0, instances) : gl.drawArraysInstanced(mode, 0, this.count, instances);
      else index ? gl.drawElements(mode, this.count, itype, 0) : gl.drawArrays(mode, 0, this.count);
      STATS.calls++;
    },
  };
}
function texFromCanvas(c) {
  const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.SRGB8_ALPHA8, gl.RGBA, gl.UNSIGNED_BYTE, c);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.generateMipmap(gl.TEXTURE_2D);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  if (EXT_ANISO) gl.texParameterf(gl.TEXTURE_2D, EXT_ANISO.TEXTURE_MAX_ANISOTROPY_EXT, 4);
  return t;
}

/* ---- HDR targets, MSAA, bloom chain, shadow map ---- */
const HDR = !!EXT_CBF;
const RT = { w: 1, h: 1, scene: null, msaa: null, mips: [], shadow: null };
function makeTarget(w, h, depth) {
  const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, HDR ? gl.RGBA16F : gl.RGBA8, w, h, 0, gl.RGBA, HDR ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE, null);
  for (const [p, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, p, v);
  const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  let rb = null;
  if (depth) { rb = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, rb); }
  return { tex, fb, rb, w, h };
}
function makeMSAA(w, h, samples) {
  try {
    const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    const crb = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, crb); gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples, HDR ? gl.RGBA16F : gl.RGBA8, w, h); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, crb);
    const drb = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, drb); gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples, gl.DEPTH_COMPONENT24, w, h); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, drb);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw 0;
    return { fb, crb, drb, w, h };
  } catch (e) { return null; }
}
function makeShadow(size) {
  const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, size, size, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
  const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, tex, 0);
  gl.drawBuffers([gl.NONE]); gl.readBuffer(gl.NONE); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  return { tex, fb, size };
}
function freeTarget(t) { if (!t) return; if (t.tex) gl.deleteTexture(t.tex); if (t.rb) gl.deleteRenderbuffer(t.rb); if (t.crb) gl.deleteRenderbuffer(t.crb); if (t.drb) gl.deleteRenderbuffer(t.drb); gl.deleteFramebuffer(t.fb); }
function resizeTargets(w, h) {
  freeTarget(RT.scene); freeTarget(RT.msaa); RT.mips.forEach(freeTarget); RT.mips = [];
  RT.w = w; RT.h = h; RT.scene = makeTarget(w, h, true);
  RT.msaa = Perf.msaa > 0 ? makeMSAA(w, h, Perf.msaa) : null;
  if (Perf.bloom) { let mw = w, mh = h; for (let i = 0; i < Q.bloomLv; i++) { mw = Math.max(1, mw >> 1); mh = Math.max(1, mh >> 1); RT.mips.push(makeTarget(mw, mh, false)); } }
  if (!RT.shadow) RT.shadow = makeShadow(Q.shadow);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
}
const FS_VS = `in vec2 aPos; out vec2 vUv; void main(){ vUv = aPos*.5 + .5; gl_Position = vec4(aPos, 0., 1.); }`;
const P_DOWN = new Program(FS_VS, `
in vec2 vUv; uniform sampler2D uSrc; uniform vec2 uTexel; uniform float uPrefilter, uThreshold;
void main(){ vec2 t = uTexel;
  vec3 c = texture(uSrc, vUv).rgb*.5 + (texture(uSrc, vUv + t*vec2(-1,-1)).rgb + texture(uSrc, vUv + t*vec2(1,-1)).rgb + texture(uSrc, vUv + t*vec2(-1,1)).rgb + texture(uSrc, vUv + t*vec2(1,1)).rgb)*.125;
  if (uPrefilter > .5) { c = min(c, vec3(30.)); float br = max(c.r, max(c.g, c.b)); float soft = clamp(br - uThreshold + .3, 0., .6); soft = soft*soft/(2.4 + 1e-4); c *= max(soft, br - uThreshold)/max(br, 1e-4); }
  o = vec4(c, 1.); }`, 'down');
const P_UP = new Program(FS_VS, `
in vec2 vUv; uniform sampler2D uSrc; uniform vec2 uTexel;
void main(){ vec2 t = uTexel;
  vec3 c = (texture(uSrc, vUv + t*vec2(-1,-1)).rgb + texture(uSrc, vUv + t*vec2(1,-1)).rgb + texture(uSrc, vUv + t*vec2(-1,1)).rgb + texture(uSrc, vUv + t*vec2(1,1)).rgb)*.125
    + (texture(uSrc, vUv + t*vec2(-2,0)).rgb + texture(uSrc, vUv + t*vec2(2,0)).rgb + texture(uSrc, vUv + t*vec2(0,-2)).rgb + texture(uSrc, vUv + t*vec2(0,2)).rgb)*.125;
  o = vec4(c, 1.); }`, 'up');
const P_COMP = new Program(FS_VS, `
in vec2 vUv; uniform sampler2D uScene, uBloom; uniform float uBloomStr, uExposure, uHasBloom, uVignette, uWarm;
vec3 aces(vec3 x){ return clamp((x*(2.51*x + .03))/(x*(2.43*x + .59) + .14), 0., 1.); }
void main(){
  vec3 c = texture(uScene, vUv).rgb;
  if (uHasBloom > .5) c += texture(uBloom, vUv).rgb*uBloomStr;
  c *= uExposure;
  vec2 q = vUv - .5; c *= 1. - uVignette*dot(q, q)*1.7;
  c = aces(c);
  c = mix(c, c*vec3(1.04, 1., .93), uWarm);              // gentle warm grade toward golden hour
  c = pow(c, vec3(1./2.2));
  c += (h21(gl_FragCoord.xy + fract(uTime)*71.) - .5)/255.;
  o = vec4(c, 1.); }`, 'comp');
const FSQ = mesh(P_DOWN, { attribs: { aPos: { data: new Float32Array([-1, -1, 3, -1, -1, 3]), size: 2 } }, count: 3 });
function fsPass(prog, uniforms, target, blend = 'none') {
  gl.bindFramebuffer(gl.FRAMEBUFFER, target ? target.fb : null); gl.viewport(0, 0, target ? target.w : RT.w, target ? target.h : RT.h);
  setBlend(blend); setDepth('none'); prog.use(uniforms); gl.bindVertexArray(FSQ.vao); gl.drawArrays(gl.TRIANGLES, 0, 3); STATS.calls++;
}
function postProcess(exposure, warm) {
  if (RT.msaa) { gl.bindFramebuffer(gl.READ_FRAMEBUFFER, RT.msaa.fb); gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, RT.scene.fb); gl.blitFramebuffer(0, 0, RT.w, RT.h, 0, 0, RT.w, RT.h, gl.COLOR_BUFFER_BIT, gl.NEAREST); }
  const useBloom = Perf.bloom && RT.mips.length > 0;
  if (useBloom) {
    let src = RT.scene;
    RT.mips.forEach((m, i) => { fsPass(P_DOWN, { uSrc: src.tex, uTexel: [1 / src.w, 1 / src.h], uPrefilter: i === 0 ? 1 : 0, uThreshold: 1.5 }, m); src = m; });
    for (let i = RT.mips.length - 2; i >= 0; i--) { const s = RT.mips[i + 1]; fsPass(P_UP, { uSrc: s.tex, uTexel: [1 / s.w, 1 / s.h] }, RT.mips[i], 'add'); }
  }
  fsPass(P_COMP, { uScene: RT.scene.tex, uBloom: useBloom ? RT.mips[0].tex : RT.scene.tex, uHasBloom: useBloom ? 1 : 0, uBloomStr: .38, uExposure: exposure, uVignette: .38, uWarm: warm }, null);
}

/* =====================================================================================
   4 · LIGHTING — shared GLSL: sun + sky ambient + shadow map (PCF) + point lights + fog
   ===================================================================================== */
const LIGHT_GLSL = `
uniform vec3 uCamPos, uSunDir, uSunCol, uSkyCol, uHorCol, uGndCol, uFogCol;
uniform float uAmb, uFogDen, uShadowOn, uIntAmb, uNight, uCloud, uWet, uNL, uPcf;
uniform mat4 uShadowMat; uniform sampler2DShadow uShadow;
uniform vec4 uLP[20]; uniform vec4 uLC[20];
float insideHouse(vec3 p){ return (p.x > -5.87 && p.x < 5.87 && p.z > -4.37 && p.z < 4.37 && p.y > .2 && p.y < 5.95) ? 1. : 0.; }
vec3 skyCol(vec3 d){
  float h = max(d.y, 0.);
  vec3 c = mix(uHorCol, uSkyCol, pow(h, .5));
  c = mix(c, uGndCol*.5, clamp(-d.y*5., 0., 1.));
  float s = max(dot(d, uSunDir), 0.);
  c += uSunCol*(pow(s, 6.)*.06 + pow(s, 80.)*.35)*(1. - uCloud*.7);
  return c;
}
float shadowAt(vec3 p, vec3 n){
  if (uShadowOn < .01) return 1.;
  vec4 s = uShadowMat*vec4(p + n*.035, 1.); vec3 c = s.xyz/s.w*.5 + .5;
  if (c.x < 0. || c.y < 0. || c.x > 1. || c.y > 1. || c.z > 1.) return 1.;
  float b = .0006, r;
  if (uPcf < .5) r = texture(uShadow, vec3(c.xy, c.z - b));
  else { vec2 tx = vec2(1./float(textureSize(uShadow, 0).x)); r = 0.;
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) r += texture(uShadow, vec3(c.xy + vec2(i, j)*tx*1.3, c.z - b)); r /= 9.; }
  return mix(1., r, uShadowOn);
}
vec3 shade(vec3 P, vec3 N, vec3 V, vec3 alb, float rough, float metal, float ao, float spec){
  float inside = insideHouse(P);
  float ndl = max(dot(N, uSunDir), 0.);
  float sh = ndl > 0. ? shadowAt(P, N) : 0.;
  float shin = min(2./max(pow(rough, 4.), .001), 2048.);
  vec3 H = normalize(uSunDir + V);
  float spc = pow(max(dot(N, H), 0.), shin)*(shin + 8.)/25.13;
  float F = .04 + .96*pow(1. - max(dot(N, V), 0.), 5.);
  vec3 amb = mix(uGndCol, uSkyCol*.55 + uHorCol*.18, N.y*.5 + .5)*uAmb*ao;
  amb *= mix(1., uIntAmb, inside);
  vec3 pl = vec3(0.), pls = vec3(0.);
  for (int i = 0; i < 20; i++) {
    if (float(i) >= uNL) break;
    vec4 lp = uLP[i], lc = uLC[i];
    if (lc.w > .5 && lc.w < 1.5 && inside < .5) continue;      // interior-only light
    if (lc.w > 1.5 && inside > .5) continue;                     // exterior-only light
    vec3 d = lp.xyz - P; float dist = length(d); if (dist > lp.w) continue;
    vec3 l = d/dist; float att = pow(1. - dist/lp.w, 2.)/(1. + dist*dist*.3);
    pl += lc.rgb*att*max(dot(N, l), 0.);
    pls += lc.rgb*att*pow(max(dot(N, normalize(l + V)), 0.), min(shin, 256.))*.04;
  }
  vec3 R = reflect(-V, N);
  vec3 env = inside > .5 ? vec3(.55, .45, .36)*(uIntAmb*uAmb*1.5 + .03) + pl*.15 : skyCol(R);
  vec3 sc = mix(vec3(1.), alb, metal);
  float envK = (1. - rough)*(1. - rough);
  return alb*(1. - metal)*(uSunCol*ndl*sh + amb + pl)
       + sc*(uSunCol*spc*sh*.04 + pls)*spec
       + env*sc*mix(F, 1., metal)*envK*spec*ao;
}
vec3 fogApply(vec3 col, vec3 P){
  vec3 D = P - uCamPos; float d = length(D);
  float hf = exp(-max(P.y, 0.)*.12);
  float f = 1. - exp(-max(d - 6., 0.)*uFogDen*(.35 + hf*.8));
  vec3 fc = uFogCol + uSunCol*pow(max(dot(D/d, uSunDir), 0.), 8.)*.08;
  return mix(col, fc, clamp(f, 0., .9));
}
`;

/* =====================================================================================
   3 · MATERIALS — procedural shader library (no textures to download)
   ===================================================================================== */
const M = { LUMBER: 0, CONCRETE: 1, SOIL: 2, STEEL: 3, OSB: 4, WRAP: 5, UNDERLAY: 6, SHINGLE: 7, SIDING: 8, BRICK: 9, STONE: 10, TRIM: 11, GLASS: 12,
  FRAME: 13, WALNUT: 14, GARAGE: 15, DRYWALL: 16, FLOOR: 18, TILE: 19, QUARTZ: 20, CABINET: 21, STAINLESS: 22, BRASS: 23, DRIVE: 24, MULCH: 25,
  LEAVES: 26, BARK: 27, EMIT: 28, STUCCO: 29, METALROOF: 30, GUTTER: 31, PORCHCEIL: 32, PAINT: 33, MIRROR: 34, BLACK: 35, FLAG: 36, NSIDING: 37, ASPHALT: 38 };

/* ---- instanced construction shader: every building element is an instance of a base mesh.
   Per-instance (8 × vec4):
     i0 pos.xyz, material        i1 size.xyz, mode       i2 rot(yaw,pitch,roll), seed(≥10 = environment)
     i3 colour.rgb, emissiveOn    i4 tIn, dur, tOut, outDur
     i5 fromOffset.xyz, easing    i6 hingeAxis.xyz, hingeAngle    i7 pivot.xyz, extra
   Modes: 0 move/hinge · 1 grow ↑ · 2 grow along x · 3 grow along z · 4 grow ↓ · 5 scale-in · 6 dissolve-in · 7 door (uDoor)
   All motion is evaluated on the GPU from the global timeline → zero per-frame CPU work. ---- */
const INST_VS = `
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aN;
layout(location=2) in vec4 i0; layout(location=3) in vec4 i1; layout(location=4) in vec4 i2; layout(location=5) in vec4 i3;
layout(location=6) in vec4 i4; layout(location=7) in vec4 i5; layout(location=8) in vec4 i6; layout(location=9) in vec4 i7;
uniform float uDoor, uWind; uniform mat4 uLightVP; uniform float uShadowPass;
out vec3 vW; out vec3 vN; out vec3 vL; out vec3 vLN; out float vK;
flat out vec4 vI0; flat out vec4 vI3; flat out vec4 vI4; flat out vec4 vI7; flat out vec3 vSize; flat out float vSeed; flat out float vMode;
mat3 rotYXZ(vec3 r){ float cy = cos(r.x), sy = sin(r.x), cx = cos(r.y), sx = sin(r.y), cz = cos(r.z), sz = sin(r.z);
  return mat3(cy,0.,-sy, 0.,1.,0., sy,0.,cy)*mat3(1.,0.,0., 0.,cx,sx, 0.,-sx,cx)*mat3(cz,sz,0., -sz,cz,0., 0.,0.,1.); }
vec3 rotAxis(vec3 v, vec3 a, float ang){ float c = cos(ang), s = sin(ang); return v*c + cross(a, v)*s + a*dot(a, v)*(1. - c); }
float ease(float k, float ty){
  if (ty < .5) return 1. - pow(1. - k, 3.);
  if (ty < 1.5) return k < .5 ? 4.*k*k*k : 1. - pow(-2.*k + 2., 3.)/2.;
  if (ty < 2.5) { float c1 = .7, c3 = c1 + 1., x = k - 1.; return 1. + c3*x*x*x + c1*x*x; }   // lock-in with a tiny settle
  if (ty < 3.5) return k;
  return k*k*(3. - 2.*k);
}
void main(){
  float tIn = i4.x, dur = i4.y, tOut = i4.z, oDur = i4.w;
  float k = dur > 0. ? clamp((uT - tIn)/dur, 0., 1.) : step(tIn, uT);
  bool hidden = uT < tIn || (tOut > 0. && uT > tOut + oDur);
  float e = ease(k, i5.w), mode = i1.w;
  vec3 lp = aPos;
  if (mode > .5 && mode < 1.5) lp.y = (lp.y + .5)*e - .5;
  else if (mode > 1.5 && mode < 2.5) lp.x = (lp.x + .5)*e - .5;
  else if (mode > 2.5 && mode < 3.5) lp.z = (lp.z + .5)*e - .5;
  else if (mode > 3.5 && mode < 4.5) lp.y = .5 - (.5 - lp.y)*e;
  else if (mode > 4.5 && mode < 5.5) lp *= max(e, .001);
  vec3 local = lp*i1.xyz;
  mat3 R = rotYXZ(i2.xyz);
  vec3 wp = i0.xyz + R*local, wn = R*aN;
  if (abs(i0.w - 26.) < .5) { float h = max(wp.y - i0.y + i1.y*.5, 0.)*.012; wp.x += sin(uWind*1.3 + i0.x*.31 + wp.y*.5)*h; wp.z += cos(uWind*1.1 + i0.z*.27)*h*.6; }
  if (i6.w != 0.) { float a = (mode > 6.5 && mode < 7.5) ? i6.w*uDoor : i6.w*(1. - e); vec3 piv = i7.xyz; wp = piv + rotAxis(wp - piv, i6.xyz, a); wn = rotAxis(wn, i6.xyz, a); }
  wp += i5.xyz*(1. - e);
  vW = wp; vN = wn; vL = local; vLN = aN; vK = k; vI0 = i0; vI3 = i3; vI4 = i4; vI7 = i7; vSize = i1.xyz; vSeed = i2.w; vMode = mode;
  vec4 clip = uShadowPass > .5 ? uLightVP*vec4(wp, 1.) : uProj*uView*vec4(wp, 1.);
  gl_Position = hidden ? vec4(2., 2., 2., 1.) : clip;
}`;
const INST_FS_COMMON = `
in vec3 vW; in vec3 vN; in vec3 vL; in vec3 vLN; in float vK;
flat in vec4 vI0; flat in vec4 vI3; flat in vec4 vI4; flat in vec4 vI7; flat in vec3 vSize; flat in float vSeed; flat in float vMode;
uniform float uEnd, uShingles, uWrap, uFloorR, uPaintR, uScanPos, uScanOn, uWinGlow;
uniform vec3 uScanDir, uPaintO, uFloorO;
float gEdge;
bool clipFrag(){
  float nz = n31(vW*5.3 + fract(vSeed)*7.);
  if (vMode > 5.5 && vMode < 6.5 && nz > vK*1.05) return true;
  if (vI4.z > 0.) { float ok = clamp((uT - vI4.z)/max(vI4.w, .01), 0., 1.); if (nz < ok*1.05) return true; }
  gEdge = 0.;
  if (vSeed < 9. && uEnd > 0.) { float h = mix(13., -1., uEnd) + nz*.7; if (vW.y > h) return true; gEdge = 1. - smoothstep(0., .22, h - vW.y); }
  return false;
}`;
const INST_FS = INST_FS_COMMON + LIGHT_GLSL + `
uniform float uPass;
vec2 cellN(vec2 p, out float id){ vec2 i = floor(p), f = fract(p); float d1 = 8., d2 = 8.; id = 0.;
  for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y); vec2 oo = vec2(h21(i + g), h21(i + g + 7.7)); vec2 r = g + oo - f; float d = dot(r, r);
    if (d < d1) { d2 = d1; d1 = d; id = h21(i + g + 3.3); } else if (d < d2) d2 = d; }
  return vec2(sqrt(d1), sqrt(d2)); }
void main(){
  if (clipFrag()) discard;
  int id = int(vI0.w + .5);
  vec3 N = normalize(vN); if (!gl_FrontFacing) N = -N;
  vec3 V = normalize(uCamPos - vW);
  vec2 fc = abs(vLN.x) > .5 ? vL.zy : (abs(vLN.y) > .5 ? vL.xz : vL.xy);          // local face coords
  float hz = abs(N.x) > abs(N.z) ? vW.z : vW.x;                                    // world horizontal along a wall
  vec2 wc = abs(N.y) > .7 ? vW.xz : vec2(hz, vW.y);
  float sd = fract(vSeed)*37.;
  vec3 alb = vI3.rgb, emi = vec3(0.); float rough = .8, metal = 0., spec = 1., ao = 1., alpha = 1.;
  switch (id) {
    case 0: { // framing lumber — grain along the longest axis
      float ax = (vSize.x >= vSize.y && vSize.x >= vSize.z) ? vL.x : (vSize.y >= vSize.z ? vL.y : vL.z);
      float cr = vL.x + vL.y + vL.z - ax;
      float g = sin(cr*90. + n21(vec2(ax*2.1, sd))*7. + ax*.8)*.5 + .5;
      alb = vec3(.80, .63, .40)*(.82 + .16*g)*(.9 + .2*h21(vec2(sd, 3.)));
      alb *= .93 + .07*n21(vec2(ax*14., cr*30.)); rough = .78; spec = .4; break; }
    case 1: { // concrete: wet → cured
      float cure = clamp((uT - vI4.x - vI4.y)/1.6, 0., 1.);
      float n = fbm(wc*3.1 + sd);
      alb = vec3(.56, .55, .53)*(.82 + .25*n); alb *= mix(.55, 1., cure);
      rough = mix(.18, .85, cure); spec = mix(1.4, .5, cure); break; }
    case 2: { alb = vec3(.36, .19, .11)*(.75 + .45*fbm(vW.xz*2.3 + vW.y)); rough = .95; spec = .2; break; }   // NC red clay
    case 3: { alb = vec3(.23, .17, .13)*(.7 + .5*n21(vL.xz*40.)); metal = .6; rough = .6; break; }             // rebar
    case 4: { float n = n21(fc*26. + sd), n2 = n21(fc*9.3 - sd); alb = vec3(.76, .60, .38)*(.72 + .22*n + .12*n2); rough = .85; spec = .4; break; }  // OSB
    case 5: { alb = vec3(.9, .91, .92)*(.93 + .07*n21(wc*8.)); float band = step(.93, fract(vW.y/1.52 + .1)); alb = mix(alb, vec3(.55, .62, .72), band*.35);   // house wrap
      if (atan(vW.x - 3., vW.z - 6.)/6.2832 + .5 > uWrap) discard; rough = .55; break; }
    case 6: { alb = vec3(.13, .135, .14)*(.85 + .2*n21(wc*6.)); float ln = step(.97, fract(vW.y/.95)); alb += ln*.06; rough = .7; break; }   // underlayment
    case 7: { // architectural shingles, course by course
      float row = floor((vW.y - vI7.w)/.0777);
      if (row >= uShingles) discard;
      float u = hz/.33 + h21(vec2(row, 1.))*3.;
      float tab = h21(vec2(floor(u), row));
      float y0 = fract((vW.y - vI7.w)/.0777);
      alb = vec3(.115, .115, .12)*(.72 + .5*tab)*(.8 + .25*smoothstep(0., .3, y0));
      alb *= .9 + .2*n21(wc*60.); rough = .8; spec = .6;
      ao = mix(.55, 1., smoothstep(0., .18, y0)); break; }
    case 8: { // board & batten siding (warm white)
      float u = hz/.406, d = abs(fract(u) - .5)*.406;
      alb = vec3(.80, .79, .755)*(.96 + .04*n21(wc*vec2(2., 40.)));
      float batten = 1. - smoothstep(.028, .032, d);
      ao = mix(.8, 1., smoothstep(.032, .05, d))*(1. - (1. - batten)*.0) ; alb *= mix(1., 1.03, batten);
      rough = .55; spec = .5; break; }
    case 9: { // running-bond brick
      float row = floor(vW.y/.075), off = mod(row, 2.)*.5;
      vec2 b = vec2(hz/.215 + off, vW.y/.075); vec2 f = fract(b);
      float mortar = step(f.x, .05) + step(f.y, .13);
      float id2 = h21(floor(b));
      alb = mix(vec3(.46, .21, .14)*(.75 + .45*id2), vec3(.68, .64, .58), clamp(mortar, 0., 1.));
      alb *= .9 + .2*n21(wc*30.); rough = .9; spec = .3; ao = mix(1., .7, clamp(mortar, 0., 1.)); break; }
    case 10: { // stacked stone
      float cid; vec2 c = cellN(vec2(hz*2.4, vW.y*4.2), cid);
      float edge = smoothstep(.0, .12, c.y - c.x);
      alb = mix(vec3(.30, .28, .25), vec3(.66, .60, .52)*(.7 + .5*cid), edge)*(.85 + .3*n21(wc*18.));
      rough = .9; spec = .35; ao = mix(.55, 1., edge); break; }
    case 11: { alb = vec3(.84, .83, .8); rough = .45; spec = .6; break; }   // trim
    case 13: { alb = vec3(.035, .035, .038); rough = .35; spec = .9; break; } // window frames
    case 14: { float g = sin(vL.y*3. + vL.x*80. + n21(vL.xy*vec2(40., 2.))*5.)*.5 + .5; alb = vec3(.26, .15, .09)*(.8 + .3*g); rough = .4; spec = 1.; break; }  // walnut door
    case 15: { float p = fract((vW.y - .1)/.575); alb = vec3(.16, .16, .17)*(.9 + .1*n21(wc*20.)); ao = mix(.5, 1., smoothstep(0., .05, p)*smoothstep(1., .92, p));
      if (vW.y > 2.05 && abs(fract(hz/.6) - .5) < .38) { alb = vec3(.06); emi = vec3(.9, .6, .32)*uWinGlow*.35; } rough = .5; break; }
    case 16: { // drywall → painted (paint flows from the foyer)
      float tape = 1. - smoothstep(.0, .06, abs(fract(hz/1.22) - .5)*1.22 - .52);
      vec3 raw = vec3(.74, .74, .72)*(.95 + .05*n21(wc*9.)) + tape*.06;
      float pd = length(vW.xz - uPaintO.xz) - uPaintR + n21(wc*3.)*.5;
      float painted = 1. - smoothstep(-.02, .02, pd);
      alb = mix(raw, vI3.rgb, painted); rough = mix(.9, .7, painted); spec = mix(.2, .35, painted);
      spec += (1. - smoothstep(0., .6, abs(pd)))*painted*1.2; break; }
    case 18: { // oak plank floor, flowing through the rooms
      if (length(vW.xz - uFloorO.xz) + n21(vW.xz*2.)*.4 > uFloorR) discard;
      float pw = floor(vW.x/.19); float pl = floor((vW.z + h21(vec2(pw, 2.))*3.)/1.3);
      float pid = h21(vec2(pw, pl));
      float g = sin(vW.z*25. + n21(vW.xz*vec2(3., 30.))*6.)*.5 + .5;
      alb = vec3(.58, .41, .26)*(.78 + .3*pid)*(.9 + .12*g);
      vec2 f = vec2(fract(vW.x/.19), fract((vW.z + h21(vec2(pw, 2.))*3.)/1.3));
      ao = mix(.6, 1., smoothstep(0., .03, min(min(f.x, 1. - f.x), min(f.y, 1. - f.y)*6.)));
      rough = .35; spec = 1.; break; }
    case 19: { // tile — revealed tile by tile
      vec2 ts = vI7.w > 0. ? vec2(.15, .075) : vec2(.3, .3);
      vec2 tc = (abs(N.y) > .7 ? vW.xz : vec2(hz, vW.y))/ts;
      vec2 ci = floor(tc), f = fract(tc);
      vec2 fr = abs(vLN.x) > .5 ? (vL.zy/vSize.zy + .5) : (abs(vLN.y) > .5 ? (vL.xz/vSize.xz + .5) : (vL.xy/vSize.xy + .5));
      float delay = vI7.w > 0. ? (fr.y*.55 + fr.x*.45) : length(fr - .5)*1.3;
      float lt = (uT - vI4.x)/max(vI4.y, .01);
      if (lt < delay) discard;
      float pop = 1. - smoothstep(0., .08, lt - delay);
      float grout = max(step(f.x, .035), step(f.y, .035*ts.x/ts.y));
      alb = mix(vI3.rgb*(.94 + .08*h21(ci)), vec3(.72, .7, .67), grout); emi += vec3(1., .85, .6)*pop*.4;
      rough = mix(.12, .8, grout); spec = mix(1.6, .3, grout); ao = mix(1., .75, grout); break; }
    case 20: { float vv = fbm(fc*vec2(1.3, 2.6) + sd); float vein = smoothstep(.02, 0., abs(vv - .52))*.35; alb = vec3(.93, .92, .9) - vein*vec3(.35, .34, .32); rough = .12; spec = 1.6; break; }  // quartz
    case 21: { // shaker cabinetry
      vec2 hs = (abs(vLN.x) > .5 ? vSize.zy : (abs(vLN.y) > .5 ? vSize.xz : vSize.xy))*.5;
      vec2 dd = hs - abs(fc);
      float frame = step(min(dd.x, dd.y), .065) * step(.01, vSize.z < .05 || vSize.x < .05 ? 1. : 0.);
      float groove = smoothstep(.006, 0., abs(min(dd.x, dd.y) - .065))*step(.01, vSize.z < .05 || vSize.x < .05 ? 1. : 0.);
      alb = vI3.rgb*(.95 + .05*n21(fc*20.)); ao = 1. - groove*.5 - frame*.0; rough = .5; spec = .8; break; }
    case 22: { alb = vec3(.78, .78, .8)*(.95 + .05*n21(vL.xy*vec2(400., 4.))); metal = 1.; rough = .28; break; }   // stainless
    case 23: { alb = vec3(.86, .66, .36); metal = 1.; rough = .3; break; }                                          // brushed brass
    case 24: { alb = vec3(.62, .6, .57)*(.85 + .2*fbm(vW.xz*2.)); float j = step(.985, fract(vW.z/3.)) + step(.985, fract(vW.x/3.)); alb *= 1. - j*.35; rough = .8; spec = .4 + uWet; break; }  // driveway
    case 25: { alb = vec3(.20, .12, .07)*(.7 + .5*n21(vW.xz*25.)); rough = 1.; spec = .1; break; }
    case 26: { float n = fbm(vW.xz*1.7 + vW.y*1.3 + sd), lf = n21(vW.xy*6.3 + vW.z*4.1)*.6 + n21(vW.zy*11.7)*.4; if (lf < .6 - .55*abs(dot(normalize(vN), V)) && vSize.x > 1.2) discard; alb = vI3.rgb*(.45 + .8*n)*(.75 + .4*lf); ao = mix(.5, 1., smoothstep(-1., 1., vL.y/(vSize.y*.5))); rough = .9; spec = .15;
      N = normalize(N + (vec3(n21(vW.xy*3.), n21(vW.yz*3.), n21(vW.zx*3.)) - .5)*1.2); break; }
    case 27: { alb = vec3(.22, .16, .11)*(.7 + .5*n21(vec2(atan(vL.x, vL.z)*3., vL.y*8.))); rough = .95; spec = .1; break; }
    case 28: { float on = vI3.w > 0. ? smoothstep(vI3.w, vI3.w + .2, uT) : (vI3.w < -.5 ? uNight : 1.);
      alb = vec3(.05); emi = vI3.rgb*on*(1. - uEnd); rough = .5; spec = .2; break; }
    case 29: { alb = vec3(.9, .88, .84)*(.9 + .12*fbm(wc*12.)); rough = .95; spec = .3; break; }                       // stucco
    case 30: { float s = abs(fract(vW.x/.45) - .5); alb = vec3(.16, .165, .17)*(1. - smoothstep(.02, 0., .5 - s)*.3); metal = .6; rough = .35; break; }  // standing seam
    case 31: { alb = vec3(.09, .085, .08); metal = .5; rough = .35; break; }
    case 32: { float b = fract(vW.x/.14); alb = vec3(.55, .38, .24)*(.85 + .2*h21(vec2(floor(vW.x/.14), 1.)))*mix(.7, 1., smoothstep(0., .08, b)); rough = .5; break; }
    case 33: { rough = .6; spec = .5; break; }
    case 34: { alb = vec3(.92); metal = 1.; rough = .04; break; }
    case 35: { alb = vec3(.04); metal = .3; rough = .4; break; }
    case 36: { alb = vec3(.95, .42, .08); emi = vec3(.3, .09, .01); rough = .8; break; }
    case 37: { alb = vI3.rgb*(.9 + .1*step(.9, fract(vW.y/.2))); rough = .8; spec = .3; break; }
    case 38: { alb = vec3(.07, .07, .075)*(.8 + .4*n21(vW.xz*8.)); rough = .85 - uWet*.6; spec = .3 + uWet*1.5; break; }
    default: break;
  }
  if (id == 12) { // glass (transparent pass)
    vec3 R = reflect(-V, N);
    float F = .06 + .94*pow(1. - max(dot(N, V), 0.), 5.);
    vec3 refl = insideHouse(uCamPos) > .5 ? vec3(.02) : skyCol(R);
    vec3 col = refl*F*.9;
    float a = mix(.1, .55, F);
    if (vI7.w > .5) { col = mix(vec3(.02, .02, .025), vec3(.95, .66, .38)*uWinGlow, .9) + refl*F; a = .92; }   // sheer upstairs glass
    col = fogApply(col, vW);
    o = vec4(col*a, a); return;
  }
  ao *= mix(.55, 1., smoothstep(.0, .5, vW.y)) * (insideHouse(vW) > .5 ? .88 + .12*smoothstep(0., .4, min(abs(vW.y - .3), abs(2.99 - vW.y))) : 1.);
  vec3 col = shade(vW, N, V, alb, rough, metal, ao, spec) + emi;
  if (uScanOn > 0.) col += vec3(1., .85, .6)*exp(-pow((dot(vW, uScanDir) - uScanPos)/.03, 2.))*uScanOn*1.6;
  col += vec3(1., .72, .35)*gEdge*2.5;
  col = fogApply(col, vW);
  o = vec4(col, 1.);
}`;
const SHADOW_FS = INST_FS_COMMON + `
void main(){ if (clipFrag()) discard; if (int(vI0.w + .5) == 7 && floor((vW.y - vI7.w)/.0777) >= uShingles) discard; if (int(vI0.w + .5) == 18 && length(vW.xz - uFloorO.xz) > uFloorR) discard; o = vec4(1.); }`;
const P_INST = new Program(INST_VS, INST_FS, 'instanced');
const P_SHADOW = new Program(INST_VS, SHADOW_FS, 'shadow');

/* ---- base meshes (unit size, centred) ---- */
function geoCube() {
  const P = [], N = [], I = [];
  [[[1, 0, 0], [0, 0, -1], [0, 1, 0]], [[-1, 0, 0], [0, 0, 1], [0, 1, 0]], [[0, 1, 0], [1, 0, 0], [0, 0, -1]], [[0, -1, 0], [1, 0, 0], [0, 0, 1]], [[0, 0, 1], [1, 0, 0], [0, 1, 0]], [[0, 0, -1], [-1, 0, 0], [0, 1, 0]]]
    .forEach(([n, a, b], f) => { for (const [i, j] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) { P.push(n[0] * .5 + a[0] * i * .5 + b[0] * j * .5, n[1] * .5 + a[1] * i * .5 + b[1] * j * .5, n[2] * .5 + a[2] * i * .5 + b[2] * j * .5); N.push(...n); } I.push(f * 4, f * 4 + 1, f * 4 + 2, f * 4, f * 4 + 2, f * 4 + 3); });
  return { P, N, I };
}
function geoPrism() {   // gable: triangle in local XY (base y=-.5, apex y=+.5), extruded along Z
  const P = [], N = [], I = []; let v = 0;
  const quad = (a, b, c, d, n) => { P.push(...a, ...b, ...c, ...d); for (let i = 0; i < 4; i++) N.push(...n); I.push(v, v + 1, v + 2, v, v + 2, v + 3); v += 4; };
  const tri = (a, b, c, n) => { P.push(...a, ...b, ...c); for (let i = 0; i < 3; i++) N.push(...n); I.push(v, v + 1, v + 2); v += 3; };
  const L = [-.5, -.5], Rr = [.5, -.5], T = [0, .5];
  tri([...L, .5], [...Rr, .5], [...T, .5], [0, 0, 1]); tri([...Rr, -.5], [...L, -.5], [...T, -.5], [0, 0, -1]);
  quad([...L, -.5], [...Rr, -.5], [...Rr, .5], [...L, .5], [0, -1, 0]);
  const nl = v3.norm([-1, .5, 0]), nr = v3.norm([1, .5, 0]);
  quad([...L, .5], [...T, .5], [...T, -.5], [...L, -.5], nl); quad([...Rr, -.5], [...T, -.5], [...T, .5], [...Rr, .5], nr);
  return { P, N, I };
}
function geoSphere(seg = 14, rings = 9) {
  const P = [], N = [], I = [];
  for (let r = 0; r <= rings; r++) for (let s = 0; s <= seg; s++) { const th = r / rings * Math.PI, ph = s / seg * TAU; const n = [Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph)]; P.push(...v3.mul(n, .5)); N.push(...n); }
  for (let r = 0; r < rings; r++) for (let s = 0; s < seg; s++) { const a = r * (seg + 1) + s, b = a + seg + 1; I.push(a, b, a + 1, b, b + 1, a + 1); }
  return { P, N, I };
}
function geoCyl(seg = 14, top = .5) {   // top < .5 → tapered (cone at 0)
  const P = [], N = [], I = []; let v = 0;
  const slope = (.5 - top);
  for (let s = 0; s <= seg; s++) { const a = s / seg * TAU, c = Math.cos(a), sn = Math.sin(a), n = v3.norm([c, slope, sn]); P.push(c * .5, -.5, sn * .5, c * top, .5, sn * top); N.push(...n, ...n); }
  for (let s = 0; s < seg; s++) { const a = s * 2; I.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  v = P.length / 3;
  for (const [y, ny, r] of [[.5, 1, top], [-.5, -1, .5]]) { if (r <= 0) continue; const c0 = v; P.push(0, y, 0); N.push(0, ny, 0); v++;
    for (let s = 0; s <= seg; s++) { const a = s / seg * TAU; P.push(Math.cos(a) * r, y, Math.sin(a) * r); N.push(0, ny, 0); v++; }
    for (let s = 0; s < seg; s++) ny > 0 ? I.push(c0, c0 + s + 2, c0 + s + 1) : I.push(c0, c0 + s + 1, c0 + s + 2); }
  return { P, N, I };
}

/* =====================================================================================
   7 · INSTANCED CONSTRUCTION RENDERER
   ===================================================================================== */
class InstSet {
  constructor(geo) { this.geo = geo; this.rows = []; }
  add(r) { this.rows.push(r); }
  build() {
    const n = this.rows.length; this.n = n; if (!n) return;
    const data = new Float32Array(n * 32); this.rows.forEach((r, i) => data.set(r, i * 32));
    const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    const pb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, pb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.geo.P), gl.STATIC_DRAW); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
    const nb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, nb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.geo.N), gl.STATIC_DRAW); gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 0, 0);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, ib); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    for (let k = 0; k < 8; k++) { gl.enableVertexAttribArray(2 + k); gl.vertexAttribPointer(2 + k, 4, gl.FLOAT, false, 128, k * 16); gl.vertexAttribDivisor(2 + k, 1); }
    const eb = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, eb); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(this.geo.I), gl.STATIC_DRAW);
    gl.bindVertexArray(null); this.vao = vao; this.count = this.geo.I.length; this.rows = null;
  }
  draw(prog, uniforms, opts) {
    if (!this.n) return;
    setBlend(opts.blend || 'none'); setDepth(opts.depth || 'write');
    if (opts.cull) { gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); } else gl.disable(gl.CULL_FACE);
    prog.use(uniforms); gl.bindVertexArray(this.vao);
    gl.drawElementsInstanced(gl.TRIANGLES, this.count, gl.UNSIGNED_SHORT, 0, this.n); STATS.calls++;
    gl.disable(gl.CULL_FACE);
  }
}
const SETS = { cube: new InstSet(geoCube()), glass: new InstSet(geoCube()), prism: new InstSet(geoPrism()), sphere: new InstSet(geoSphere()), cyl: new InstSet(geoCyl()), cone: new InstSet(geoCyl(10, 0)) };
/* One construction element. Every option is optional; defaults = present from t=0, no animation. */
function el(set, p, s, mat, o = {}) {
  const r = new Float32Array(32);
  const rot = o.rot || [0, 0, 0], col = o.col || [1, 1, 1], from = o.from || [0, 0, 0], h = o.hinge || null;
  r.set([p[0], p[1], p[2], mat, s[0], s[1], s[2], o.mode || 0, rot[0], rot[1], rot[2], (o.env ? 10 : 0) + (o.seed ?? Math.random() * .999),
    col[0], col[1], col[2], o.emitOn || 0, o.t ?? -1, o.d ?? 0, o.out || 0, o.outD || .5, from[0], from[1], from[2], o.ease ?? 0,
    h ? h.axis[0] : 0, h ? h.axis[1] : 0, h ? h.axis[2] : 0, h ? h.ang : 0, h ? h.pivot[0] : 0, h ? h.pivot[1] : 0, h ? h.pivot[2] : 0, o.extra || 0]);
  SETS[set].add(r);
}

/* =====================================================================================
   5 · TERRAIN — suburban lot, NC red clay → lawn, street, sidewalks, gentle hills
   ===================================================================================== */
const P_GROUND = new Program(`
in vec3 aPos; out vec3 vW;
float hh(vec2 p){ return sin(p.x*.05)*cos(p.y*.043)*1.6 + sin(p.x*.13 + 1.)*sin(p.y*.11)*.6; }
void main(){ vec3 w = aPos; float far = smoothstep(34., 70., length(vec2(w.x - 3., (w.z + 4.)*1.2))); w.y = hh(w.xz)*far*1.5 - .02; vW = w; gl_Position = uProj*uView*vec4(w, 1.); }`, `
in vec3 vW;` + LIGHT_GLSL + `
uniform float uLawnR, uEnd;
void main(){
  vec3 N = vec3(0., 1., 0.);
  float n = fbm(vW.xz*.35), n2 = n21(vW.xz*6.);
  vec3 grass = mix(vec3(.13, .21, .07), vec3(.25, .34, .11), n)*(.85 + .25*n2);
  grass *= 1. + .06*sign(sin(vW.x*.9));                                        // mowing stripes
  vec3 alb = grass; float rough = .95, spec = .25;
  bool lot = vW.x > -15. && vW.x < 21. && vW.z > -12. && vW.z < 13.;
  if (lot) {
    vec3 clay = mix(vec3(.46, .22, .12), vec3(.32, .16, .09), n)*(.8 + .3*n2);
    float ruts = smoothstep(.25, 0., abs(sin(vW.x*.9 + sin(vW.z*.3)*2.)))*smoothstep(4., 9., vW.z)*step(vW.x, 13.);
    clay *= 1. - ruts*.25;
    float lawn = 1. - smoothstep(-.8, .8, length((vW.xz - vec2(3., 1.))*vec2(.9, 1.2)) - uLawnR + n*2.);
    float edge = smoothstep(1., 0., max(abs(vW.x - 3.) - 17., abs(vW.z) - 12.));
    alb = mix(clay, grass, max(lawn, 1. - edge));
    rough = mix(.95, .9, lawn);
  }
  if (vW.z > 13.2 && vW.z < 14.8) { alb = vec3(.55, .54, .51)*(.85 + .2*n2); float j = step(.97, fract(vW.x/1.5)); alb *= 1. - j*.4; rough = .8; }   // sidewalk
  if (vW.z > 14.8 && vW.z < 15.1) { alb = vec3(.6, .59, .56); }                                                                                 // curb
  if (vW.z > 15.1 && vW.z < 22.5) { alb = vec3(.07, .07, .075)*(.75 + .5*n2)*(.9 + .2*n); rough = .85 - uWet*.6; spec = .3 + uWet*1.5; }         // asphalt
  vec3 V = normalize(uCamPos - vW);
  vec3 col = shade(vW, N, V, alb, rough, 0., 1., spec);
  col = fogApply(col, vW);
  o = vec4(col, 1.);
}`, 'ground');
const GROUND = (() => {
  const S = 110, R = 150, P = [], I = [];
  for (let j = 0; j <= S; j++) for (let i = 0; i <= S; i++) { const u = i / S * 2 - 1, v = j / S * 2 - 1; const k = x => Math.sign(x) * Math.pow(Math.abs(x), 1.8); P.push(3 + k(u) * R, 0, -4 + k(v) * R); }
  for (let j = 0; j < S; j++) for (let i = 0; i < S; i++) { const a = j * (S + 1) + i, b = a + S + 1; I.push(a, b, a + 1, b, b + 1, a + 1); }
  return mesh(P_GROUND, { attribs: { aPos: { data: new Float32Array(P), size: 3 } }, index: new Uint16Array(I) });
})();

/* ---- sky dome (full-screen) with moving clouds and faint pre-dawn stars ---- */
const P_SKY = new Program(`in vec2 aPos; out vec2 vN; void main(){ vN = aPos; gl_Position = vec4(aPos, .99999, 1.); }`, `
in vec2 vN;` + LIGHT_GLSL + `
uniform vec3 uFwd, uRight, uUp; uniform vec2 uTan, uShift;
void main(){
  vec2 n = vN - uShift;
  vec3 d = normalize(uFwd + n.x*uTan.x*uRight + n.y*uTan.y*uUp);
  vec3 c = skyCol(d);
  if (d.y > 0.) {
    vec2 cp = d.xz/(d.y + .12)*1.6 + vec2(cos(uTime), sin(uTime))*.14;
    float cl = smoothstep(.45 - uCloud*.25, .95, fbm(cp) + .15*fbm(cp*3.1));
    vec3 cc = mix(uHorCol*1.05 + uSunCol*.08, uSkyCol*.7 + uHorCol*.5, .4) * (1. - uCloud*.35);
    c = mix(c, cc + uSunCol*pow(max(dot(d, uSunDir), 0.), 4.)*.12, cl*(.55 + uCloud*.4)*smoothstep(0., .15, d.y));
    float st = step(.9975, h21(floor(d.xz/(d.y + .3)*420.)))*uNight*smoothstep(.1, .5, d.y);
    c += st*.6;
  }
  c = mix(c, uFogCol, clamp(uFogDen*18. - d.y*3., 0., .8));
  o = vec4(c, 1.);
}`, 'sky');
const SKY = mesh(P_SKY, { attribs: { aPos: { data: new Float32Array([-1, -1, 3, -1, -1, 3]), size: 2 } }, count: 3 });

/* =====================================================================================
   6 · PARTICLES — sunlit construction dust, a brief rain shower
   ===================================================================================== */
const P_DUST = new Program(`
in vec3 aPos; in vec4 aSeed; uniform vec3 uSunDir, uSunCol; uniform float uDustA, uLW;
out vec3 vC; out float vA;
void main(){
  float ph = aSeed.z*6.2831;
  vec3 p = vec3(aPos.x + sin(uT*uLW*2. + ph)*.7, .15 + fract(uT/30. + aSeed.y)*7., aPos.z + cos(uT*uLW*3. + ph)*.7);
  vec4 mv = uView*vec4(p, 1.); float d = -mv.z;
  gl_PointSize = clamp((.018 + aSeed.x*.02)*uPS*uProj[1][1]/max(d, .1), 1., 12.);
  vec3 v = normalize(p - uCamPos);
  float fwd = pow(max(dot(v, uSunDir), 0.), 4.)*2.5 + .25;
  vC = uSunCol*fwd*.35 + vec3(.05, .045, .04);
  vA = uDustA*smoothstep(.3, 2., d)*smoothstep(40., 15., d)*(.55 + .45*sin(uT*uLW*5. + ph*3.));
  gl_Position = uProj*mv;
}`, `in vec3 vC; in float vA; void main(){ float r = length(gl_PointCoord - .5)*2.; o = vec4(vC*vA*(1. - smoothstep(.2, 1., r)), 1.); }`, 'dust');
const DUST = (() => { const R = rng(4), n = Q.dust, p = new Float32Array(n * 3), s = new Float32Array(n * 4);
  for (let i = 0; i < n; i++) { p.set([-10 + R() * 26, R() * 7, -9 + R() * 20], i * 3); s.set([R(), .3 + R(), R(), R()], i * 4); }
  return mesh(P_DUST, { attribs: { aPos: { data: p, size: 3 }, aSeed: { data: s, size: 4 } }, mode: gl.POINTS, count: n }); })();
const P_RAIN = new Program(`
in vec4 aR; in float aEnd; uniform float uRainA; out float vA;
void main(){
  vec3 base = vec3(aR.x, 0., aR.y);
  float y = 22. - mod(aR.z + uTime*16., 24.);
  vec3 cell = floor((uCamPos - vec3(18., 0., 18.))/36.)*36.;
  vec3 p = vec3(mod(base.x - uCamPos.x + 18., 36.) - 18. + uCamPos.x, y + aEnd*.55, mod(base.z - uCamPos.z + 18., 36.) - 18. + uCamPos.z);
  p.x += aEnd*.08;
  vA = uRainA*(1. - aEnd*.7)*smoothstep(0., 1.5, p.y)*aR.w;
  gl_Position = uProj*uView*vec4(p, 1.);
}`, `in float vA; void main(){ o = vec4(vec3(.55, .6, .68)*vA, 1.); }`, 'rain');
const RAIN = (() => { const R = rng(8), n = Q.rain, a = new Float32Array(n * 8), e = new Float32Array(n * 2);
  for (let i = 0; i < n; i++) { const r = [R() * 36, R() * 36, R() * 24, .3 + R() * .7]; a.set(r, i * 8); a.set(r, i * 8 + 4); e[i * 2] = 0; e[i * 2 + 1] = 1; }
  return mesh(P_RAIN, { attribs: { aR: { data: a, size: 4 }, aEnd: { data: e, size: 1 } }, mode: gl.LINES, count: n * 2 }); })();

/* =====================================================================================
   8 · LINES (blueprint), SPRITES (glows), LABELS (subtle words)
   ===================================================================================== */
const P_LINE = new Program(`
in vec3 aPos; in vec3 aCol; in float aParam; in vec3 aInfo; uniform float uYScale;
out float vParam; out vec3 vInfo; out vec3 vCol; out float vDepth;
void main(){ vec3 p = aPos; p.y *= uYScale; vec4 mv = uView*vec4(p, 1.); vDepth = -mv.z; vParam = aParam; vInfo = aInfo; vCol = aCol; gl_Position = uProj*mv; }`, `
in float vParam; in vec3 vInfo; in vec3 vCol; in float vDepth; uniform float uLocal, uOpacity, uFlow, uHead;
void main(){
  float p = vInfo.y <= 0. ? 1. : clamp((uLocal - vInfo.x)/vInfo.y, 0., 1.);
  if (p <= 0. || vParam > p) discard;
  float a = 1.; if (vInfo.z > 0.) a *= 1. - smoothstep(0., vInfo.z, uLocal - vInfo.x - vInfo.y);
  float head = p < 1. ? exp(-(p - vParam)*30.)*uHead : 0.;
  float flow = pow(fract(vParam*2. - uTime*.35 + vInfo.x), 16.)*uFlow;
  o = vec4((vCol*(1. + flow*2.) + vec3(1., .85, .6)*head*3.)*a*uOpacity*smoothstep(.2, 1.5, vDepth), 1.);
}`, 'line');
class Lines {
  constructor() { this.pos = []; this.col = []; this.par = []; this.info = []; }
  poly(pts, col, delay = 0, dur = 0, fade = 0, closed = false) {
    if (closed) pts = [...pts, pts[0]];
    const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + v3.len(v3.sub(pts[i], pts[i - 1])));
    const L = cum[cum.length - 1] || 1;
    for (let i = 0; i < pts.length - 1; i++) for (const k of [i, i + 1]) { this.pos.push(...pts[k]); this.col.push(...col); this.par.push(cum[k] / L); this.info.push(delay, dur, fade); }
    return this;
  }
  seg(a, b, col, delay = 0, dur = 0, fade = 0) { return this.poly([a, b], col, delay, dur, fade); }
  box(c, s, col, delay = 0, dur = 0) {   // 12 edges
    const [x, y, z] = c, [w, h, d] = s.map(v => v / 2);
    const P = [[x - w, y - h, z - d], [x + w, y - h, z - d], [x + w, y - h, z + d], [x - w, y - h, z + d], [x - w, y + h, z - d], [x + w, y + h, z - d], [x + w, y + h, z + d], [x - w, y + h, z + d]];
    [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(([a, b]) => this.seg(P[a], P[b], col, delay, dur));
    return this;
  }
  build() { return mesh(P_LINE, { attribs: { aPos: { data: new Float32Array(this.pos), size: 3 }, aCol: { data: new Float32Array(this.col), size: 3 }, aParam: { data: new Float32Array(this.par), size: 1 }, aInfo: { data: new Float32Array(this.info), size: 3 } }, mode: gl.LINES, count: this.pos.length / 3 }); }
}
const drawLines = (m, u) => m.draw(Object.assign({ uYScale: 1, uLocal: 99, uOpacity: 1, uFlow: 0, uHead: 0 }, u), { blend: 'add', depth: 'test' });

const P_SPRITE = new Program(`
in vec2 aQ; in vec3 iPos; in vec3 iCol; in vec4 iData; out vec2 vL; out vec3 vCol; out vec4 vData; out float vDepth;
void main(){ vec3 w = iPos + (aQ.x*uCamRight + aQ.y*uCamUp)*iData.x; vec4 mv = uView*vec4(w, 1.); vDepth = -mv.z; vL = aQ*2.; vCol = iCol; vData = iData; gl_Position = uProj*mv; }`, `
in vec2 vL; in vec3 vCol; in vec4 vData; in float vDepth;
void main(){ float r = length(vL); float a = vData.y < .5 ? exp(-r*r*5.)*.5 + exp(-r*r*50.)*1.4 : exp(-pow((r - .8)/.06, 2.));
  a *= smoothstep(1., .9, r)*smoothstep(.1, .6, vDepth); o = vec4(vCol*a, 1.); }`, 'sprite');
const Sprites = (() => {
  const MAX = 96, data = new Float32Array(MAX * 10); let n = 0;
  const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
  const qb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, qb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-.5, -.5, .5, -.5, .5, .5, -.5, -.5, .5, .5, -.5, .5]), gl.STATIC_DRAW);
  const la = P_SPRITE.a; gl.enableVertexAttribArray(la.aQ); gl.vertexAttribPointer(la.aQ, 2, gl.FLOAT, false, 0, 0);
  const ib = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, ib); gl.bufferData(gl.ARRAY_BUFFER, data.byteLength, gl.DYNAMIC_DRAW);
  [['iPos', 3, 0], ['iCol', 3, 3], ['iData', 4, 6]].forEach(([nm, s, o]) => { const l = la[nm]; if (l < 0 || l === undefined) return; gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, s, gl.FLOAT, false, 40, o * 4); gl.vertexAttribDivisor(l, 1); });
  gl.bindVertexArray(null);
  return {
    begin() { n = 0; },
    push(p, size, col, ring = 0) { if (n >= MAX || size <= 0 || col[0] + col[1] + col[2] <= 0.001) return; data.set([p[0], p[1], p[2], col[0], col[1], col[2], size, ring, 0, 0], n * 10); n++; },
    flush() { if (!n) return; gl.bindBuffer(gl.ARRAY_BUFFER, ib); gl.bufferSubData(gl.ARRAY_BUFFER, 0, data, 0, n * 10);
      setBlend('add'); setDepth('test'); P_SPRITE.use({}); gl.bindVertexArray(vao); gl.drawArraysInstanced(gl.TRIANGLES, 0, 6, n); STATS.calls++; },
  };
})();

/* Labels: one texture atlas of words, drawn as camera-facing or wall-aligned cards. */
function buildLabelAtlas(defs) {
  const W = 2048, H = 512, c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d'); const map = {};
  let X = 0, Y = 0, rowH = 0;
  for (const [key, text, size, weight, sp] of defs) {
    x.font = `${weight} ${size}px "Helvetica Neue", Helvetica, Arial, sans-serif`;
    let w = 0; for (const ch of text) w += x.measureText(ch).width + size * sp; w = Math.ceil(w) + 24; const h = Math.ceil(size * 1.4) + 12;
    if (X + w > W) { X = 0; Y += rowH; rowH = 0; }
    x.fillStyle = '#fff'; x.textBaseline = 'middle'; let cx = X + 12; for (const ch of text) { x.fillText(ch, cx, Y + h / 2); cx += x.measureText(ch).width + size * sp; }
    map[key] = { uv: [X / W, Y / H, w / W, h / H], aspect: w / h }; X += w + 4; rowH = Math.max(rowH, h + 4);
  }
  return { tex: texFromCanvas(c), map };
}
const P_LABEL = new Program(`
in vec2 aQ; in vec3 iPos; in vec3 iAx; in vec3 iAy; in vec4 iUv; in vec4 iCol;
out vec2 vUv; out vec4 vCol; out float vDepth;
void main(){ vec3 w = iPos + aQ.x*iAx + aQ.y*iAy; vec4 mv = uView*vec4(w, 1.); vDepth = -mv.z; vec2 l = aQ + .5; vUv = vec2(iUv.x + l.x*iUv.z, 1. - (iUv.y + (1. - l.y)*iUv.w)); vCol = iCol; gl_Position = uProj*mv; }`, `
in vec2 vUv; in vec4 vCol; in float vDepth; uniform sampler2D uTex;
void main(){ float a = texture(uTex, vUv).a*vCol.a*smoothstep(.3, 2., vDepth); o = vec4(vCol.rgb*a, 1.); }`, 'label');
const Labels = (() => {
  const MAX = 24, data = new Float32Array(MAX * 17); let n = 0, atlas = null;
  const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
  const qb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, qb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-.5, -.5, .5, -.5, .5, .5, -.5, -.5, .5, .5, -.5, .5]), gl.STATIC_DRAW);
  const la = P_LABEL.a; gl.enableVertexAttribArray(la.aQ); gl.vertexAttribPointer(la.aQ, 2, gl.FLOAT, false, 0, 0);
  const ib = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, ib); gl.bufferData(gl.ARRAY_BUFFER, data.byteLength, gl.DYNAMIC_DRAW);
  [['iPos', 3, 0], ['iAx', 3, 3], ['iAy', 3, 6], ['iUv', 4, 9], ['iCol', 4, 13]].forEach(([nm, s, o]) => { const l = la[nm]; if (l < 0 || l === undefined) return; gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, s, gl.FLOAT, false, 68, o * 4); gl.vertexAttribDivisor(l, 1); });
  gl.bindVertexArray(null);
  return {
    setAtlas(a) { atlas = a; },
    begin() { n = 0; },
    /* h = world height; ax/ay optional (default camera-facing); col rgb × alpha */
    push(key, p, h, alpha, col = [1, .82, .55], ax = null, ay = null) {
      if (!atlas || alpha <= .002 || n >= MAX) return; const L = atlas.map[key]; const w = h * L.aspect;
      const A = ax ? v3.mul(ax, w) : v3.mul(cam.right, w), B = ay ? v3.mul(ay, h) : v3.mul(cam.up, h);
      data.set([...p, ...A, ...B, ...L.uv, ...col, alpha], n * 17); n++;
    },
    flush() { if (!n) return; gl.bindBuffer(gl.ARRAY_BUFFER, ib); gl.bufferSubData(gl.ARRAY_BUFFER, 0, data, 0, n * 17);
      setBlend('add'); setDepth('test'); P_LABEL.use({ uTex: atlas.tex }); gl.bindVertexArray(vao); gl.drawArraysInstanced(gl.TRIANGLES, 0, 6, n); STATS.calls++; },
  };
})();

/* =====================================================================================
   11 · HOUSE MODEL — a two-storey modern-farmhouse home with attached garage and porch
   (Charlotte-area scale: ~40' × 30' main block). Units: metres. Front faces +Z.
   ===================================================================================== */
const H = { x0: -6, x1: 6, z0: -4.5, z1: 4.5, f1: .3, c1: 3.0, f2: 3.26, c2: 6.0 };
const G = { x0: 6, x1: 12.4, z0: -3.5, z1: 4.5, f: .1, c: 3.0 };
const PITCH = Math.atan(3 / 4.5), TANA = Math.tan(PITCH), SINA = Math.sin(PITCH), COSA = Math.cos(PITCH);
const RIDGE = 6.15 + 4.5 * TANA;                     // 9.15
const GRIDGE = 3.15 + 3.2 * TANA;                    // garage ridge ≈ 5.28
const COL = { white: [.93, .92, .89], paint: [.86, .82, .76], ceil: [.93, .92, .9], cabW: [.9, .89, .86], cabD: [.13, .15, .17], tileW: [.93, .93, .91], tileB: [.85, .84, .8], green: [.2, .32, .13] };
const R = rng(1234);
const yawOf = t => Math.atan2(-t[2], t[0]);
/* stick between two points in a vertical plane ('yz' at constant x, or 'xy' at constant z) */
function member(set, p1, p2, w, dep, mat, plane, o = {}) {
  const c = v3.mul(v3.add(p1, p2), .5), d = v3.sub(p2, p1), len = v3.len(d);
  if (plane === 'yz') el(set, c, [len, dep, w], mat, { ...o, rot: [Math.PI / 2, 0, Math.atan2(d[1], -d[2])] });
  else el(set, c, [len, dep, w], mat, { ...o, rot: [0, 0, Math.atan2(d[1], d[0])] });
}
/* Wall definition: line a→b, outward normal n, base y0, height, openings in (u, v) wall space */
function wall(a, b, n, y0, h, ops = [], ext = true, depth = ext ? .14 : .09) {
  const d = [b[0] - a[0], 0, b[1] - a[1]], L = Math.hypot(d[0], d[2]), t = [d[0] / L, 0, d[2] / L];
  return { a: [a[0], y0, a[1]], t, n, L, y0, h, ops, ext, D: depth, yaw: yawOf(t) };
}
const W1 = [   // ground floor exterior (main)
  wall([-6, 4.5], [6, 4.5], [0, 0, 1], .3, 2.7, [{ u0: 1.0, u1: 2.6, v0: .9, v1: 2.4, k: 'win' }, { u0: 4.5, u1: 5.5, v0: 0, v1: 2.3, k: 'door' }, { u0: 9.0, u1: 10.6, v0: .9, v1: 2.4, k: 'win' }]),
  wall([6, -4.5], [-6, -4.5], [0, 0, -1], .3, 2.7, [{ u0: 2.3, u1: 4.7, v0: 0, v1: 2.3, k: 'slider' }, { u0: 7, u1: 9, v0: 1.3, v1: 2.5, k: 'win' }]),
  wall([-6, -4.5], [-6, 4.5], [-1, 0, 0], .3, 2.7, [{ u0: 5.7, u1: 7.3, v0: .9, v1: 2.4, k: 'win' }]),
  wall([6, 4.5], [6, -4.5], [1, 0, 0], .3, 2.7, []),
];
const W2 = [   // second floor exterior
  wall([-6, 4.5], [6, 4.5], [0, 0, 1], H.f2, 2.74, [1.2, 4.4, 7.4, 10.4].map(u => ({ u0: u, u1: u + 1.2, v0: .9, v1: 2.3, k: 'win' }))),
  wall([6, -4.5], [-6, -4.5], [0, 0, -1], H.f2, 2.74, [2.0, 5.4, 8.8].map(u => ({ u0: u, u1: u + 1.2, v0: .9, v1: 2.3, k: 'win' }))),
  wall([-6, -4.5], [-6, 4.5], [-1, 0, 0], H.f2, 2.74, [{ u0: 5.4, u1: 6.6, v0: .9, v1: 2.3, k: 'win' }]),
  wall([6, 4.5], [6, -4.5], [1, 0, 0], H.f2, 2.74, []),
];
const WG = [   // garage
  wall([6, 4.5], [12.4, 4.5], [0, 0, 1], G.f, 2.9, [{ u0: .8, u1: 5.6, v0: 0, v1: 2.25, k: 'garage' }]),
  wall([12.4, 4.5], [12.4, -3.5], [1, 0, 0], G.f, 2.9, [{ u0: 3.4, u1: 4.6, v0: 1.0, v1: 2.1, k: 'win' }]),
  wall([12.4, -3.5], [6, -3.5], [0, 0, -1], G.f, 2.9, []),
];
const WI = [   // ground-floor interior partitions
  wall([-2.2, 1.5], [-2.2, 4.36], [1, 0, 0], .3, 2.7, [{ u0: .7, u1: 2.3, v0: 0, v1: 2.3, k: 'open' }], false),
  wall([.4, 2.2], [.4, 4.36], [-1, 0, 0], .3, 2.7, [], false),
  wall([.4, 2.2], [3.0, 2.2], [0, 0, -1], .3, 2.7, [{ u0: .5, u1: 1.3, v0: 0, v1: 2.1, k: 'open' }], false),
  wall([3.0, 2.2], [3.0, 4.36], [1, 0, 0], .3, 2.7, [], false),
  wall([3.0, 1.5], [5.86, 1.5], [0, 0, -1], .3, 2.7, [{ u0: .6, u1: 1.5, v0: 0, v1: 2.1, k: 'open' }], false),
];
const wp = (w, u, v, d) => [w.a[0] + w.t[0] * u + w.n[0] * d, w.a[1] + v, w.a[2] + w.t[2] * u + w.n[2] * d];
/* solid rectangles of a wall face (wall minus openings) — used for sheathing, siding, drywall */
function solidRects(w, vMin = 0, vMax = w.h) {
  const ops = w.ops.filter(o => o.v1 > vMin && o.v0 < vMax).sort((a, b) => a.u0 - b.u0), out = []; let u = 0;
  for (const o of ops) {
    if (o.u0 > u) out.push([u, o.u0, vMin, vMax]);
    if (o.v0 > vMin) out.push([o.u0, o.u1, vMin, Math.min(o.v0, vMax)]);
    if (o.v1 < vMax) out.push([o.u0, o.u1, Math.max(o.v1, vMin), vMax]);
    u = o.u1;
  }
  if (u < w.L) out.push([u, w.L, vMin, vMax]);
  return out.filter(r => r[1] - r[0] > .02 && r[3] - r[2] > .02);
}
/* panel on a wall face at depth offset d */
function wallPanel(set, w, r, d, thick, mat, o = {}) {
  const [u0, u1, v0, v1] = r;
  el(set, wp(w, (u0 + u1) / 2, (v0 + v1) / 2, d), [u1 - u0, v1 - v0, thick], mat, { ...o, rot: [w.yaw, 0, 0] });
}

/* ---------- framing: studs, plates, headers, sills, cripples; walls tilt up and lock ---------- */
function frameWall(w, t0, o = {}) {
  const D = w.D, dc = w.ext ? -D / 2 : 0, hs = w.h;
  const tiltSign = -Math.sign(v3.dot(v3.cross(w.t, [0, 1, 0]), w.n)) || 1;
  const hinge = { axis: w.t, ang: tiltSign * Math.PI / 2 * (o.flip ? -1 : 1), pivot: wp(w, 0, 0, w.ext ? 0 : 0) };
  const base = { t: t0, d: .62, ease: 2, hinge, seed: .5 };
  const stick = (u, v0, v1, thick = .038) => el('cube', wp(w, u, (v0 + v1) / 2, dc), [thick, v1 - v0, D], M.LUMBER, { ...base, rot: [w.yaw, 0, 0], seed: R() });
  const hor = (u0, u1, v, th = .038, extra = {}) => el('cube', wp(w, (u0 + u1) / 2, v, dc), [u1 - u0, th, D], M.LUMBER, { ...base, ...extra, rot: [w.yaw, 0, 0], seed: R() });
  hor(0, w.L, .019); hor(0, w.L, hs - .057);
  hor(0, w.L, hs - .019, .038, { hinge: null, t: t0 + .55, d: .32, from: v3.mul(w.t, 1.4), ease: 2 });   // 2nd top plate slides in and locks
  const inOp = u => w.ops.some(op => u > op.u0 - .09 && u < op.u1 + .09);
  const us = []; for (let u = .019; u < w.L - .01; u += .406) us.push(u); us.push(w.L - .019);
  for (const u of us) if (!inOp(u)) stick(u, .038, hs - .076);
  for (const op of w.ops) {
    stick(op.u0 - .057, .038, hs - .076); stick(op.u1 + .057, .038, hs - .076);          // king studs
    stick(op.u0 - .019, .038, op.v1); stick(op.u1 + .019, .038, op.v1);                  // jacks
    hor(op.u0 - .038, op.u1 + .038, op.v1 + .12, .24);                                   // header
    for (let u = op.u0 + .3; u < op.u1 - .1; u += .406) { if (op.v1 + .24 < hs - .1) stick(u, op.v1 + .24, hs - .076); if (op.v0 > .2) stick(u, .038, op.v0 - .038); }
    if (op.v0 > .2) hor(op.u0, op.u1, op.v0 - .019);                                      // sill
  }
}

/* ---------- windows, doors ---------- */
function windowUnit(w, op, tIn, upper) {
  const cu = (op.u0 + op.u1) / 2, cv = (op.v0 + op.v1) / 2, W = op.u1 - op.u0, Hh = op.v1 - op.v0, dz = .02, fr = .06;
  const o = { t: tIn, d: .55, ease: 2, from: v3.mul(w.n, .9), rot: [w.yaw, 0, 0] };
  const f = (u, v, sw, sh, mat = M.FRAME, d = dz, th = .12) => el('cube', wp(w, u, v, d), [sw, sh, th], mat, o);
  f(op.u0 + fr / 2, cv, fr, Hh); f(op.u1 - fr / 2, cv, fr, Hh); f(cu, op.v1 - fr / 2, W, fr); f(cu, op.v0 + fr / 2, W, fr);
  if (op.k === 'slider') f(cu, cv, .06, Hh);
  else if (W > 1.3 && op.k === 'win') f(cu, cv, .035, Hh - .1);                           // mullion
  if (upper || op.k === 'win') f(cu, cv, W - .1, .03);                                       // meeting rail
  el('glass', wp(w, cu, cv, dz), [W - .1, Hh - .1, .012], M.GLASS, { ...o, extra: upper ? 1 : 0 });
  // white casing (on top of siding) + sill
  const cs = { ...o, t: 15.0 + R() * .5, d: .45, from: v3.mul(w.n, .25) };
  const c = (u, v, sw, sh) => el('cube', wp(w, u, v, .055), [sw, sh, .03], M.TRIM, cs);
  c(op.u0 - .06, cv, .12, Hh + .24); c(op.u1 + .06, cv, .12, Hh + .24); c(cu, op.v1 + .08, W + .24, .16);
  if (op.v0 > .1) el('cube', wp(w, cu, op.v0 - .03, .07), [W + .3, .05, .09], M.TRIM, cs);
}

/* =====================================================================================
   TIMELINE (seconds in the 30 s loop)
     0.0 empty lot (pre-dawn)   2.4 blueprint   4.9 foundation   8.1 framing
    11.6 roof + weather        14.2 exterior   17.2 enter house  18.2 interior
    20.8 kitchen               22.8 bathroom   24.0 quality check 25.1 reveal
    27.4 QCR moment            28.8 → lines → footprint → loop
   ===================================================================================== */
function buildHouse() {
  const dist2 = (x, z, cx, cz) => Math.hypot(x - cx, z - cz);

  /* --- survey stakes & batter boards (scene 1) --- */
  const corners = [[-6, 4.5], [6, 4.5], [6, -4.5], [-6, -4.5], [12.4, 4.5], [12.4, -3.5], [-6, 6.6], [1.5, 6.6]];
  corners.forEach(([x, z], i) => {
    const o = { t: .35 + i * .09, d: .5, ease: 2, from: [0, .7, 0], out: 7.6, outD: .6 };
    el('cube', [x, .22, z], [.045, .44, .045], M.LUMBER, o);
    el('cube', [x, .43, z], [.06, .05, .06], M.FLAG, o);
  });
  [[-7.2, 5.7], [7.2, 5.7], [7.2, -5.7], [-7.2, -5.7]].forEach(([x, z], i) => {
    const o = { t: .8 + i * .1, d: .5, ease: 2, from: [0, .8, 0], out: 7.6, outD: .6 };
    el('cube', [x, .3, z - Math.sign(z) * .45], [.05, .6, .05], M.LUMBER, o); el('cube', [x - Math.sign(x) * .45, .3, z], [.05, .6, .05], M.LUMBER, o);
    el('cube', [x - Math.sign(x) * .22, .48, z], [.5, .09, .025], M.LUMBER, o); el('cube', [x, .48, z - Math.sign(z) * .22], [.025, .09, .5], M.LUMBER, o);
  });

  /* --- construction staging (appears with the crew, cleared before the reveal) --- */
  const stage = { t: 4.9, d: .6, mode: 6, out: 25.2, outD: .8 };
  for (let i = 0; i < 6; i++) el('cube', [15.8, .06 + i * .09, -5 + (i % 2) * .02], [4.2, .085, 1.1], M.LUMBER, { ...stage, t: 4.9 + i * .05 });
  el('cube', [18.2, .75, 1.5], [2.3, 1.5, 5.2], M.PAINT, { ...stage, col: [.62, .3, .1] });           // roll-off dumpster (QCR orange)
  el('cube', [14.4, .45, 11], [1.1, .9, 1.1], M.BRICK, { ...stage, t: 5.2 });
  el('sphere', [-9.5, .2, -7.5], [4.2, 1.6, 3.2], M.SOIL, { t: 4.9, d: .8, mode: 5, out: 15.4, outD: .8 });
  el('sphere', [15, .2, -6.5], [3.4, 1.3, 2.8], M.SOIL, { t: 5.0, d: .8, mode: 5, out: 15.4, outD: .8 });

  /* --- FOUNDATION: excavation → footings → rebar → stem walls → slab pour --- */
  const perim = [[[-6, 4.5], [6, 4.5]], [[6, 4.5], [6, -4.5]], [[6, -4.5], [-6, -4.5]], [[-6, -4.5], [-6, 4.5]], [[6, 4.5], [12.4, 4.5]], [[12.4, 4.5], [12.4, -3.5]], [[12.4, -3.5], [6, -3.5]]];
  perim.forEach(([a, b], i) => {
    const c = [(a[0] + b[0]) / 2, 0, (a[1] + b[1]) / 2], L = Math.hypot(b[0] - a[0], b[1] - a[1]) + .6, yaw = yawOf(v3.norm([b[0] - a[0], 0, b[1] - a[1]]));
    el('cube', [c[0], .005, c[2]], [L + .4, .02, 1.1], M.SOIL, { t: 5.0 + i * .06, d: .45, mode: 2, rot: [yaw, 0, 0], out: 7.2, outD: .6 });     // trench
    el('cube', [c[0], -.05, c[2]], [L, .2, .62], M.CONCRETE, { t: 5.45 + i * .1, d: .55, mode: 2, rot: [yaw, 0, 0] });                             // footing pour
    el('cube', [c[0], .15, c[2]], [L - .5, .3, .2], M.CONCRETE, { t: 6.25 + i * .06, d: .45, mode: 1, rot: [yaw, 0, 0] });                        // stem wall
  });
  for (let x = -5.6; x <= 5.6; x += .9) el('cyl', [x, .16, 0], [.016, 8.6, .016], M.STEEL, { t: 5.9 + (x + 6) * .02, d: .3, rot: [0, Math.PI / 2, 0], from: [0, .8, 0], out: 7.4, outD: .3 });
  for (let z = -4; z <= 4; z += .9) el('cyl', [0, .18, z], [.016, 11.6, .016], M.STEEL, { t: 6.1 + (z + 4.5) * .02, d: .3, rot: [0, 0, Math.PI / 2], from: [0, .8, 0], out: 7.4, outD: .3 });
  el('cube', [0, .15, 0], [12.02, .3, 9.02], M.CONCRETE, { t: 6.6, d: .95, mode: 3, ease: 1 });                                                   // main slab flows front→back
  el('cube', [9.2, .05, .5], [6.42, .1, 8.02], M.CONCRETE, { t: 6.9, d: .7, mode: 2, ease: 1 });
  el('cube', [-2.25, .15, 5.6], [7.7, .3, 2.2], M.CONCRETE, { t: 7.15, d: .5, mode: 2, ease: 1 });
  el('cube', [-1, .075, 7.0], [2.2, .15, .6], M.CONCRETE, { t: 7.3, d: .35, mode: 2 });

  /* --- FRAMING --- */
  const sillT = 8.05;
  [...W1, ...WG].forEach((w, i) => el('cube', wp(w, w.L / 2, .01, -w.D / 2), [w.L, .02, w.D], M.LUMBER, { t: sillT + i * .04, d: .3, mode: 2, rot: [w.yaw, 0, 0] }));
  const order1 = [0, 2, 1, 3];
  order1.forEach((k, i) => frameWall(W1[k], 8.25 + i * .22));
  WG.forEach((w, i) => frameWall(w, 8.6 + i * .2));
  WI.forEach((w, i) => frameWall(w, 9.05 + i * .08));
  // second-floor system: joists drop and lock, then subfloor sheets
  for (let x = -5.8, i = 0; x <= 5.81; x += .406, i++) el('cube', [x, 3.12, 0], [.045, .24, 8.72], M.LUMBER, { t: 9.45 + i * .016, d: .32, ease: 2, from: [0, 1.4, 0] });
  el('cube', [0, 3.12, 4.42], [12, .24, .045], M.LUMBER, { t: 9.4, d: .35, mode: 2 }); el('cube', [0, 3.12, -4.42], [12, .24, .045], M.LUMBER, { t: 9.45, d: .35, mode: 2 });
  for (let ix = 0; ix < 5; ix++) for (let iz = 0; iz < 8; iz++) {
    const x = -6 + ix * 2.44 + 1.22, z = -4.5 + iz * 1.22 + .61; if (x - 1.22 >= 6) continue;
    const w = Math.min(2.44, 6 - (x - 1.22));
    el('cube', [x - 1.22 + w / 2, 3.25, z - .005], [w - .006, .02, 1.214], M.OSB, { t: 9.95 + (ix + iz) * .025, d: .28, ease: 2, from: [0, .5, 0] });
  }
  [0, 2, 1, 3].forEach((k, i) => frameWall(W2[k], 10.2 + i * .18));
  // roof trusses (main): tilt upright from flat and set, one after another
  const trussMain = (x, t0) => {
    const o = { t: t0, d: .5, ease: 2, from: [0, 2.2, 0], hinge: { axis: [0, 0, 1], ang: Math.PI / 2, pivot: [x, 6.0, 0] }, seed: R() };
    const top = z => RIDGE - Math.abs(z) * TANA - .045 / COSA;
    member('cube', [x, 6.045, -4.5], [x, 6.045, 4.5], .038, .09, M.LUMBER, 'yz', o);
    member('cube', [x, top(4.95), 4.95], [x, top(0), 0], .038, .09, M.LUMBER, 'yz', o);
    member('cube', [x, top(-4.95), -4.95], [x, top(0), 0], .038, .09, M.LUMBER, 'yz', o);
    member('cube', [x, 6.09, 0], [x, top(0) - .05, 0], .038, .09, M.LUMBER, 'yz', o);
    for (const s of [1, -1]) { member('cube', [x, 6.09, s * 1.5], [x, top(s * 2.9) - .04, s * 2.9], .038, .07, M.LUMBER, 'yz', o); member('cube', [x, 6.09, s * 1.5], [x, top(s * .9) - .05, s * .9], .038, .07, M.LUMBER, 'yz', o); }
  };
  let ti = 0; for (let x = -5.98; x <= 5.99; x += .61, ti++) trussMain(Math.min(x, 5.98), 10.95 + ti * .035);
  const trussGar = (z, t0) => {
    const o = { t: t0, d: .5, ease: 2, from: [0, 2, 0], hinge: { axis: [1, 0, 0], ang: -Math.PI / 2, pivot: [9.2, 3.0, z] }, seed: R() };
    const top = x => GRIDGE - Math.abs(x - 9.2) * TANA - .045 / COSA;
    member('cube', [6.0, 3.045, z], [12.4, 3.045, z], .038, .09, M.LUMBER, 'xy', o);
    member('cube', [12.75, top(12.75), z], [9.2, top(9.2), z], .038, .09, M.LUMBER, 'xy', o);
    member('cube', [6.0, top(6.0), z], [9.2, top(9.2), z], .038, .09, M.LUMBER, 'xy', o);
    member('cube', [9.2, 3.09, z], [9.2, top(9.2) - .05, z], .038, .09, M.LUMBER, 'xy', o);
  };
  ti = 0; for (let z = -3.48; z <= 4.5; z += .61, ti++) trussGar(Math.min(z, 4.48), 11.15 + ti * .04);

  /* --- WALL SHEATHING (OSB) → HOUSE WRAP --- */
  const exterior = [...W1, ...W2, ...WG];
  exterior.forEach((w, wi) => solidRects(w).forEach((r, ri) => {
    for (let u = r[0]; u < r[1] - .01; u += 1.22) {
      const pr = [u, Math.min(u + 1.22, r[1]), r[2], r[3]];
      wallPanel('cube', w, pr, .006, .012, M.OSB, { t: 10.9 + wi * .06 + u * .015, d: .35, ease: 2, from: v3.mul(w.n, .7) });
    }
    wallPanel('cube', w, r, .014, .003, M.WRAP, { t: 13.0, d: .01 });
  }));
  // gable ends
  const gable = (p, base, h, yaw, mat, off, o = {}) => el('prism', p, [base, h, .012], mat, { ...o, rot: [yaw, 0, 0] });
  for (const s of [-1, 1]) {
    gable([s * (6 + .006), 6.0 + (RIDGE - 6.0) / 2, 0], 9.0, RIDGE - 6.0, Math.PI / 2, M.OSB, 0, { t: 11.9, d: .4, ease: 2, from: [s * .7, 0, 0] });
    gable([s * (6 + .016), 6.0 + (RIDGE - 6.0) / 2, 0], 9.0, RIDGE - 6.0, Math.PI / 2, M.WRAP, 0, { t: 13.0, d: .01 });
  }
  for (const [z, s] of [[4.506, 1], [-3.506, -1]]) {
    gable([9.2, 3.0 + (GRIDGE - 3.0) / 2, z], 6.4, GRIDGE - 3.0, 0, M.OSB, 0, { t: 12.0, d: .4, ease: 2, from: [0, 0, s * .7] });
    gable([9.2, 3.0 + (GRIDGE - 3.0) / 2, z + s * .01], 6.4, GRIDGE - 3.0, 0, M.WRAP, 0, { t: 13.0, d: .01 });
  }

  /* --- ROOF: decking → underlayment rolls → shingles course by course --- */
  const slopeLen = 4.95 / COSA;
  const slopes = [
    { eave: [0, 5.85, 4.95], dir: [0, SINA, -COSA], nrm: [0, COSA, SINA], rot: [0, PITCH, 0], width: 12.7, len: slopeLen, cx: 0, axis: 'x', delay: 0 },
    { eave: [0, 5.85, -4.95], dir: [0, SINA, COSA], nrm: [0, COSA, -SINA], rot: [0, -PITCH, 0], width: 12.7, len: slopeLen, cx: 0, axis: 'x', delay: .15 },
  ];
  const gLenR = (12.75 - 9.2) / COSA, gLenL = 3.2 / COSA;
  const gSlopes = [
    { eave: [12.75, GRIDGE - 3.55 * TANA, .5], dir: [-COSA, SINA, 0], nrm: [SINA, COSA, 0], rot: [0, 0, -PITCH], width: 8.7, len: gLenR, axis: 'z', delay: .1 },
    { eave: [6.0, 3.15, .5], dir: [COSA, SINA, 0], nrm: [-SINA, COSA, 0], rot: [0, 0, PITCH], width: 8.7, len: gLenL, axis: 'z', delay: .2 },
  ];
  const onSlope = (s, u, v, off) => v3.add(v3.add(v3.add(s.eave, s.axis === 'x' ? [u, 0, 0] : [0, 0, u]), v3.mul(s.dir, v)), v3.mul(s.nrm, off));
  const slopeBox = (set, s, u, v, w, l, off, th, mat, o) => el(set, onSlope(s, u, v, off), s.axis === 'x' ? [w, th, l] : [l, th, w], mat, { ...o, rot: s.rot });
  [...slopes, ...gSlopes].forEach((s, si) => {
    const isMain = s.axis === 'x', t0 = isMain ? 11.75 : 12.05;
    for (let v = 0, row = 0; v < s.len - .01; v += 1.22, row++) {
      const l = Math.min(1.22, s.len - v);
      for (let u = -s.width / 2, col = 0; u < s.width / 2 - .01; u += 2.44, col++) {
        const w = Math.min(2.44, s.width / 2 - u);
        slopeBox('cube', s, u + w / 2 + (isMain ? 0 : .5 - .5), v + l / 2, w - .006, l - .006, .008, .016, M.OSB,
          { t: t0 + s.delay + row * .1 + col * .025, d: .32, ease: 2, from: v3.add(v3.mul(s.dir, 1.2), v3.mul(s.nrm, .4)) });
      }
    }
    const strips = Math.ceil(s.len / 1.5);
    for (let k = 0; k < strips; k++) { const v = k * 1.5, l = Math.min(1.5, s.len - v);
      slopeBox('cube', s, 0, v + l / 2, s.width, l, .019, .004, M.UNDERLAY, { t: 12.3 + s.delay + k * .1, d: .4, mode: s.axis === 'x' ? 2 : 3, ease: 1 }); }
    slopeBox('cube', s, 0, s.len / 2, s.width, s.len, .032, .02, M.SHINGLE, { t: 12.75, d: .01, extra: s.eave[1] + .02 });
  });
  el('cube', [0, RIDGE + .035, 0], [12.8, .06, .34], M.SHINGLE, { t: 12.75, d: .01, extra: 5.85 });
  el('cube', [9.2, GRIDGE + .035, .5], [.34, .06, 8.8], M.SHINGLE, { t: 12.75, d: .01, extra: 2.9 });
  // fascia, rakes, soffits
  const trimIn = { t: 15.1, d: .4, ease: 2 };
  for (const s of [1, -1]) {
    el('cube', [0, 5.78, s * 4.965], [12.8, .22, .03], M.TRIM, { ...trimIn, mode: 2 });
    el('cube', [0, 5.9, s * 4.72], [12.7, .02, .46], M.TRIM, { ...trimIn, mode: 2 });
    for (const xs of [-6.36, 6.36]) member('cube', [xs, 5.84, s * 4.97], [xs, RIDGE + .02, 0], .03, .2, M.TRIM, 'yz', { ...trimIn, t: 15.25 });
  }
  el('cube', [12.765, GRIDGE - 3.55 * TANA - .07, .5], [.03, .22, 8.8], M.TRIM, { ...trimIn, mode: 3 });
  for (const z of [4.86, -3.86]) { member('cube', [6.0, 3.1, z], [9.2, GRIDGE + .02, z], .03, .2, M.TRIM, 'xy', { ...trimIn, t: 15.3 }); member('cube', [9.2, GRIDGE + .02, z], [12.8, GRIDGE - 3.6 * TANA - .05, z], .03, .2, M.TRIM, 'xy', { ...trimIn, t: 15.3 }); }
  // gutters & downspouts
  for (const s of [1, -1]) el('cube', [0, 5.72, s * 5.04], [12.8, .12, .13], M.GUTTER, { t: 15.45, d: .45, mode: 2, ease: 1 });
  el('cube', [12.84, GRIDGE - 3.55 * TANA - .12, .5], [.13, .12, 8.8], M.GUTTER, { t: 15.5, d: .45, mode: 3, ease: 1 });
  [[-6.25, 5.04], [5.7, 5.04], [12.84, 4.7]].forEach(([x, z], i) => el('cube', [x, 2.85, z], [.08, 5.7 * (i < 2 ? 1 : .5), .08], M.GUTTER, { t: 15.7 + i * .06, d: .35, mode: 4 }));

  /* --- EXTERIOR SKIN: stone water table, board & batten, stucco gable, brick chimney --- */
  exterior.forEach((w, wi) => {
    const isFront = w.n[2] > .5 && w.y0 < 1;
    const stoneTop = isFront ? .9 : 0;
    if (stoneTop) solidRects(w, 0, stoneTop).forEach(r => wallPanel('cube', w, r, .055, .07, M.STONE, { t: 14.3 + r[0] * .025, d: .4, mode: 2, ease: 1 }));
    solidRects(w, stoneTop, w.h).forEach(r => wallPanel('cube', w, r, .03, .02, M.SIDING, { t: 14.25 + wi * .07, d: .55, mode: 1, ease: 1 }));
    // corner boards
    if (w.ext) for (const u of [.04, w.L - .04]) el('cube', wp(w, u, w.h / 2, .045), [.11, w.h, .03], M.TRIM, { t: 15.0, d: .4, mode: 1, rot: [w.yaw, 0, 0] });
  });
  for (const s of [-1, 1]) gable([s * 6.03, 6.0 + (RIDGE - 6.0) / 2, 0], 9.0, RIDGE - 6.0, Math.PI / 2, M.SIDING, 0, { t: 14.9, d: .5, mode: 1 });
  gable([9.2, 3.0 + (GRIDGE - 3.0) / 2, 4.535], 6.4, GRIDGE - 3.0, 0, M.STUCCO, 0, { t: 15.0, d: .5, mode: 6 });
  gable([9.2, 3.0 + (GRIDGE - 3.0) / 2, -3.535], 6.4, GRIDGE - 3.0, 0, M.SIDING, 0, { t: 14.9, d: .5, mode: 1 });
  el('cube', [-6.65, 5.15, -1.25], [1.1, 10.1, 1.3], M.BRICK, { t: 14.55, d: .75, mode: 1, ease: 1 });
  el('cube', [-6.65, 10.27, -1.25], [1.25, .12, 1.45], M.STONE, { t: 15.25, d: .3, from: [0, .6, 0] });
  el('cyl', [-6.65, 10.5, -1.25], [.22, .35, .22], M.BLACK, { t: 15.35, d: .3, from: [0, .5, 0] });

  /* --- WINDOWS & DOORS --- */
  let wn = 0;
  [...W1, ...W2, ...WG].forEach(w => w.ops.forEach(op => { if (op.k === 'win' || op.k === 'slider') windowUnit(w, op, 12.55 + (wn++) * .06, w.y0 > 1); }));
  const fw = W1[0];
  el('cube', [-1.0, 1.45, 4.44], [.98, 2.28, .05], M.WALNUT, { t: 13.3, d: .5, ease: 2, from: [0, 0, 1], mode: 7, hinge: { axis: [0, 1, 0], ang: 100 * DEG, pivot: [-1.5, 1.45, 4.44] } });
  el('sphere', [-.62, 1.35, 4.49], [.06, .06, .06], M.BRASS, { t: 13.3, d: .5, ease: 2, from: [0, 0, 1], mode: 7, hinge: { axis: [0, 1, 0], ang: 100 * DEG, pivot: [-1.5, 1.45, 4.44] } });
  const dc = { t: 15.1, d: .4, ease: 2, from: [0, 0, .3] };
  el('cube', [-1.56, 1.5, 4.56], [.12, 2.5, .03], M.TRIM, dc); el('cube', [-.44, 1.5, 4.56], [.12, 2.5, .03], M.TRIM, dc); el('cube', [-1, 2.72, 4.56], [1.24, .16, .03], M.TRIM, dc);
  el('cube', [9.2, 1.225, 4.53], [4.8, 2.25, .06], M.GARAGE, { t: 15.35, d: .7, mode: 4, ease: 1 });

  /* --- PORCH --- */
  [-5.7, -3.6, 1.3].forEach((x, i) => {
    el('cube', [x, .6, 6.4], [.42, .6, .42], M.STONE, { t: 15.3 + i * .08, d: .35, mode: 1 });
    el('cube', [x, 1.81, 6.4], [.24, 1.82, .24], M.TRIM, { t: 15.45 + i * .08, d: .45, mode: 1, ease: 2 });
  });
  el('cube', [-2.2, 2.84, 6.4], [7.9, .24, .24], M.TRIM, { t: 15.7, d: .45, mode: 2 });
  const prp = Math.atan(.35 / 2.25);
  el('cube', [-2.2, 3.19, 5.62], [7.9, .05, 2.36], M.METALROOF, { t: 15.75, d: .45, ease: 2, from: [0, .8, 0], rot: [0, prp, 0] });
  el('cube', [-2.2, 2.955, 5.5], [7.7, .02, 1.95], M.PORCHCEIL, { t: 15.8, d: .4, mode: 2 });
  el('cube', [-4.65, 1.2, 6.4], [1.9, .06, .08], M.TRIM, { t: 15.9, d: .35, mode: 2 }); el('cube', [-4.65, .42, 6.4], [1.9, .05, .06], M.TRIM, { t: 15.9, d: .35, mode: 2 });
  for (let x = -5.45; x < -3.8; x += .13) el('cube', [x, .81, 6.4], [.035, .75, .035], M.TRIM, { t: 15.95 + (x + 5.45) * .15, d: .25, mode: 1 });
  // exterior lighting (lanterns)
  [[-1.78, 2.15, 4.62], [-.22, 2.15, 4.62], [6.45, 2.5, 4.6], [11.95, 2.5, 4.6]].forEach(p => {
    el('cube', p, [.16, .3, .16], M.BLACK, { t: 15.6, d: .3, ease: 2, from: [0, 0, .4] });
    el('cube', [p[0], p[1] - .01, p[2] + .005], [.12, .22, .165], M.EMIT, { t: 15.6, d: .3, ease: 2, from: [0, 0, .4], col: [7, 4.2, 1.9], emitOn: 16.7 });
  });

  /* --- LANDSCAPING: driveway, walk, beds, shrubs, trees --- */
  el('cube', [9.2, .02, 9.8], [5.2, .05, 10.6], M.DRIVE, { t: 15.65, d: .7, mode: 3, ease: 1 });
  el('cube', [-1, .02, 10.1], [1.3, .05, 5.8], M.DRIVE, { t: 15.9, d: .5, mode: 3, ease: 1 });
  [[-4.2, 7.6, 4.3, 1.6], [.2, 7.6, 1.8, 1.6], [4.0, 5.3, 3.4, 1.2], [-6.9, 1, 1.2, 7]].forEach(([x, z, w, d], i) => el('cube', [x, .015, z], [w, .03, d], M.MULCH, { t: 15.7 + i * .06, d: .5, mode: 6 }));
  const shrub = (x, z, s, c, t) => { for (let k = 0; k < 3; k++) { const a = k * 2.1 + R(), r = s * .22, q = s * (.62 + R() * .2); el('sphere', [x + Math.cos(a) * r, q * .42, z + Math.sin(a) * r * .8], [q, q * .8, q], M.LEAVES, { t: t + k * .04, d: .55, mode: 5, ease: 2, col: v3.mul(c, .85 + R() * .3) }); } };
  for (let x = -6.0, i = 0; x < -2.4; x += .85, i++) shrub(x, 7.4, .8, [.16, .27, .11], 16.0 + i * .05);
  [[-.4, 7.4], [.8, 7.3]].forEach(([x, z], i) => shrub(x, z, .75, [.16, .27, .11], 16.2 + i * .05));
  for (let z = -3, i = 0; z < 4; z += 1.1, i++) shrub(-6.95, z, .7, [.18, .29, .12], 16.1 + i * .04);
  [[2.9, 5.2], [3.8, 5.25], [4.8, 5.2]].forEach(([x, z], i) => shrub(x, z, .6, [.34, .30, .38], 16.25 + i * .05));   // hydrangeas
  const orn = (x, z, t, c) => { el('cyl', [x, .9, z], [.14, 1.8, .14], M.BARK, { t, d: .5, mode: 1 }); [[0, 2.5, 0, 2.2], [.5, 2.2, .3, 1.5], [-.5, 2.3, -.2, 1.6]].forEach(([dx, y, dz, s]) => el('sphere', [x + dx, y, z + dz], [s, s * .8, s], M.LEAVES, { t: t + .2, d: .6, mode: 5, ease: 2, col: c })); };
  orn(-9.2, 8.8, 16.1, [.28, .2, .22]); orn(14.2, 9.6, 16.2, [.2, .3, .13]);
  el('cyl', [4.4, .55, 14.1], [.08, 1.1, .08], M.BLACK, { t: 16.3, d: .3, mode: 1 }); el('cube', [4.4, 1.15, 14.1], [.22, .22, .45], M.BLACK, { t: 16.3, d: .3, from: [0, .4, 0] });
  [[-4.4, 8.6], [-2.4, 8.6], [.6, 8.6], [-1.7, 11.5], [-.3, 11.5]].forEach(([x, z], i) => {
    el('cyl', [x, .2, z], [.06, .4, .06], M.BLACK, { t: 16.2 + i * .04, d: .3, mode: 1 });
    el('cyl', [x, .41, z], [.09, .04, .09], M.EMIT, { t: 16.2 + i * .04, d: .3, col: [4, 2.6, 1.2], emitOn: 16.9 + i * .06 });
  });

  /* --- INTERIOR: drywall hangs itself, ceilings, paint, flooring, trim, lights --- */
  const foyer = [-1, 3.2];
  const dwWalls = [...W1.map(w => ({ w, faces: [-(w.D + .0065)] })), ...WI.map(w => ({ w, faces: [w.D / 2 + .0065, -(w.D / 2 + .0065)] }))];
  dwWalls.forEach(({ w, faces }) => faces.forEach(d => solidRects(w).forEach(r => {
    for (let u = r[0]; u < r[1] - .01; u += 1.22) {
      const pr = [u, Math.min(u + 1.22, r[1]), r[2], r[3]], c = wp(w, (pr[0] + pr[1]) / 2, 1, d);
      const dist = Math.hypot(c[0] - foyer[0], c[2] - foyer[1]);
      wallPanel('cube', w, pr, d, .013, M.DRYWALL, { t: 18.2 + dist * .085, d: .42, ease: 2, from: v3.mul(w.n, Math.sign(d) * .55), col: COL.paint });
    }
    if (r[2] < .01) { const c = wp(w, (r[0] + r[1]) / 2, .06, d + Math.sign(d) * .012);
      el('cube', c, [r[1] - r[0], .12, .016], M.TRIM, { t: 19.75 + Math.hypot(c[0] - foyer[0], c[2] - foyer[1]) * .03, d: .4, ease: 2, rot: [w.yaw, 0, 0], from: v3.mul(w.t, .8) }); }
  })));
  for (let x = -5.86; x < 5.85; x += 2.44) for (let z = -4.36; z < 4.35; z += 1.22) {
    const w = Math.min(2.44, 5.86 - x), d = Math.min(1.22, 4.36 - z), c = [x + w / 2, 2.985, z + d / 2];
    el('cube', c, [w - .004, .013, d - .004], M.DRYWALL, { t: 18.45 + Math.hypot(c[0] - foyer[0], c[2] - foyer[1]) * .07, d: .4, ease: 2, from: [0, -.45, 0], col: COL.ceil });
  }
  el('cube', [0, .3075, 0], [11.72, .015, 8.72], M.FLOOR, { t: 18.9, d: .01 });
  // recessed lights (switch on section by section)
  const recessed = [[-1, 3.3, 19.95], [-1, 1.9, 20.1], [-4, 3.0, 20.3], [4.4, 3.0, 20.55], [-4, -2.8, 22.0], [-1.8, -2.8, 22.12], [.4, -2.8, 22.24], [-1.8, -.6, 22.3], [3.6, -2.2, 22.36], [2.2, 3.4, 23.4]];
  recessed.forEach(([x, z, on]) => el('cyl', [x, 2.975, z], [.16, .02, .16], M.EMIT, { t: 18.6, d: .01, col: [7, 5.2, 3.4], emitOn: on }));
  // work lights (construction lighting, replaced by finished lighting)
  [[-3.5, -1.2], [1.0, -2.8]].forEach(([x, z]) => {
    const o = { t: 18.2, d: .3, mode: 6, out: 21.95, outD: .3 };
    el('cyl', [x, .95, z], [.03, 1.3, .03], M.BLACK, o); el('cube', [x, 1.7, z], [.32, .22, .1], M.BLACK, o);
    el('cube', [x, 1.7, z + .052], [.26, .16, .01], M.EMIT, { ...o, col: [8, 9, 10], emitOn: 18.2 });
  });

  /* --- KITCHEN --- */
  const bz = -4.36 + .3, top = 1.19;
  const baseCab = (x0, x1, t) => { el('cube', [(x0 + x1) / 2, .76, bz], [x1 - x0 - .005, .86, .6], M.CABINET, { t, d: .4, ease: 2, from: [0, 0, 1.2], col: COL.cabW }); };
  const door = (x0, x1, y0, y1, zf, t, hingeLeft, col) => {
    const w = x1 - x0, px = hingeLeft ? x0 : x1;
    el('cube', [(x0 + x1) / 2, (y0 + y1) / 2, zf], [w - .006, y1 - y0 - .006, .02], M.CABINET, { t, d: .45, ease: 2, col, hinge: { axis: [0, 1, 0], ang: (hingeLeft ? -1 : 1) * 105 * DEG, pivot: [px, 0, zf] } });
    el('cube', [hingeLeft ? x1 - .06 : x0 + .06, (y0 + y1) / 2 + (y1 - y0) * .25, zf + .025], [.012, .14, .012], M.BRASS, { t: t + .45, d: .2, from: [0, 0, .1] });
  };
  const bases = [[-4.2, -3.3], [-3.3, -2.45], [-2.45, -1.55], [-1.55, -.7], [.05, .65]];
  bases.forEach(([a, b], i) => { baseCab(a, b, 20.75 + i * .07); door(a, (a + b) / 2, .38, 1.14, bz + .31, 21.15 + i * .06, true, COL.cabW); door((a + b) / 2, b, .38, 1.14, bz + .31, 21.18 + i * .06, false, COL.cabW); });
  el('cube', [-5.47, 1.46, bz], [.74, 2.3, .6], M.CABINET, { t: 20.7, d: .45, ease: 2, from: [0, 0, 1.2], col: COL.cabW });                         // pantry
  door(-5.84, -5.1, .38, 2.56, bz + .31, 21.1, true, COL.cabW);
  el('cube', [-4.65, 1.25, bz - .02], [.86, 1.86, .7], M.STAINLESS, { t: 21.05, d: .5, ease: 2, from: [0, 0, 1.4] });                             // refrigerator
  el('cube', [-4.65, 2.44, bz + .05], [.88, .42, .5], M.CABINET, { t: 20.8, d: .4, ease: 2, from: [0, 0, 1], col: COL.cabW });
  el('cube', [-.325, .77, bz], [.74, .92, .64], M.STAINLESS, { t: 21.3, d: .45, ease: 2, from: [0, 0, 1.2] });                                    // range
  el('cube', [-.325, 1.235, bz + .02], [.74, .02, .58], M.BLACK, { t: 21.3, d: .45, ease: 2, from: [0, 0, 1.2] });
  el('cube', [-.325, 2.05, bz - .1], [.8, .55, .42], M.STAINLESS, { t: 21.5, d: .45, ease: 2, from: [0, .6, 0] });                              // hood
  [[-4.2, -3.05], [-3.05, -2.95], [.05, .65], [-1.0, -.7]].forEach(([a, b], i) => { if (b - a < .2) return;
    el('cube', [(a + b) / 2, 1.9, -4.36 + .17], [b - a - .005, .9, .34], M.CABINET, { t: 20.9 + i * .06, d: .4, ease: 2, from: [0, .5, .3], col: COL.cabW });
    door(a, b, 1.46, 2.34, -4.36 + .35, 21.25 + i * .05, i % 2 === 0, COL.cabW);
    el('cube', [(a + b) / 2, 1.44, -4.36 + .25], [b - a - .06, .012, .03], M.EMIT, { t: 20.95, d: .01, col: [6, 4.3, 2.4], emitOn: 22.0 }); });
  // countertops lower perfectly into place
  el('cube', [-2.075, top + .018, bz + .02], [4.3, .036, .66], M.QUARTZ, { t: 21.35, d: .55, ease: 1, from: [0, .55, 0] });
  el('cube', [.35, top + .018, bz + .02], [.62, .036, .66], M.QUARTZ, { t: 21.4, d: .55, ease: 1, from: [0, .55, 0] });
  el('cube', [-2.075, 1.41, -4.335], [4.3, .38, .012], M.TILE, { t: 21.55, d: .75, col: COL.tileW, extra: 1 });                              // backsplash, tile by tile
  el('cube', [-.325, 1.62, -4.335], [.8, .44, .012], M.TILE, { t: 21.7, d: .4, col: COL.tileW, extra: 1 });
  el('cube', [-2.0, top + .005, bz + .05], [.76, .02, .44], M.STAINLESS, { t: 21.75, d: .3, from: [0, .3, 0] });                                 // sink
  el('cyl', [-2.0, top + .2, bz - .2], [.035, .38, .035], M.BRASS, { t: 21.85, d: .35, ease: 2, from: [0, .4, 0] });
  el('cube', [-2.0, top + .38, bz - .08], [.035, .035, .26], M.BRASS, { t: 21.85, d: .35, ease: 2, from: [0, .4, 0] });
  // island (charcoal) with quartz top, pendants lower from the ceiling
  [[-3.2, -2.5], [-2.5, -1.8], [-1.8, -1.1], [-1.1, -.4]].forEach(([a, b], i) => {
    el('cube', [(a + b) / 2, .76, -1.6], [b - a - .005, .86, .9], M.CABINET, { t: 20.85 + i * .08, d: .45, ease: 2, from: [0, 0, 1.4], col: COL.cabD });
    door(a, b, .38, 1.14, -1.6 + .46, 21.3 + i * .05, i % 2 === 0, COL.cabD); });
  el('cube', [-1.8, top + .02, -1.6], [3.1, .04, 1.2], M.QUARTZ, { t: 21.5, d: .6, ease: 1, from: [0, .6, 0] });
  [-2.7, -1.8, -.9].forEach((x, i) => {
    const o = { t: 21.55 + i * .1, d: .5, ease: 2, from: [0, .75, 0] };
    el('cyl', [x, 2.6, -1.6], [.012, .76, .012], M.BLACK, o);
    el('cyl', [x, 2.13, -1.6], [.34, .2, .34], M.BLACK, o);
    el('cyl', [x, 2.025, -1.6], [.28, .012, .28], M.EMIT, { ...o, col: [9, 6, 3.2], emitOn: 22.1 + i * .06 });
  });

  /* --- BATHROOM --- */
  el('cube', [1.7, .319, 3.28], [2.5, .008, 2.12], M.TILE, { t: 22.75, d: .55, col: COL.tileB, extra: -1 });
  el('cube', [2.928, 1.6, 3.83], [.012, 2.6, 1.06], M.TILE, { t: 22.95, d: .6, col: COL.tileW, extra: 1 });
  el('cube', [2.47, 1.6, 4.335], [.94, 2.6, .012], M.TILE, { t: 23.0, d: .6, col: COL.tileW, extra: 1 });
  el('glass', [2.0, 1.4, 3.83], [.012, 2.1, 1.05], M.GLASS, { t: 23.35, d: .45, ease: 2, from: [0, 0, -1.2] });
  el('cube', [2.0, 2.46, 3.83], [.03, .03, 1.05], M.BRASS, { t: 23.35, d: .45, ease: 2, from: [0, 0, -1.2] });
  el('cyl', [2.9, 2.35, 3.83], [.18, .03, .18], M.BRASS, { t: 23.45, d: .3, from: [.3, 0, 0] });
  el('cube', [1.15, .73, 4.08], [1.2, .78, .52], M.WALNUT, { t: 23.05, d: .45, ease: 2, from: [0, 0, -.9] });
  el('cube', [1.15, 1.135, 4.08], [1.26, .03, .56], M.QUARTZ, { t: 23.2, d: .4, ease: 1, from: [0, .4, 0] });
  el('cyl', [1.15, 1.2, 4.08], [.4, .12, .32], M.TRIM, { t: 23.3, d: .3, from: [0, .3, 0] });
  el('cyl', [1.15, 1.32, 4.3], [.03, .26, .03], M.BRASS, { t: 23.35, d: .3, from: [0, .3, 0] });
  el('cube', [1.15, 1.85, 4.322], [.9, .8, .01], M.MIRROR, { t: 23.25, d: .4, ease: 2, from: [0, 0, -.5] });
  el('cube', [1.15, 1.85, 4.332], [.96, .86, .012], M.BRASS, { t: 23.25, d: .4, ease: 2, from: [0, 0, -.5] });
  el('cube', [1.15, 2.4, 4.3], [.7, .06, .05], M.EMIT, { t: 23.25, d: .3, col: [8, 6, 3.6], emitOn: 23.35 });
}

/* =====================================================================================
   12 · ENVIRONMENT — Charlotte-style street: neighbours, mature hardwoods & pines,
   street lights, the tree line behind the lot
   ===================================================================================== */
function buildEnvironment() {
  const E = { env: true };
  const tree = (x, z, s, pine) => {
    const c = [.1 + R() * .06, .17 + R() * .08, .06 + R() * .04];
    if (pine) { el('cyl', [x, 3 * s, z], [.35 * s, 6 * s, .35 * s], M.BARK, E); for (let k = 0; k < 5; k++) el('cone', [x, (3.6 + k * 1.9) * s, z], [(3.4 - k * .6) * s, 3.2 * s, (3.4 - k * .6) * s], M.LEAVES, { ...E, col: [.06, .11, .06] }); return; }
    el('cyl', [x, 3 * s, z], [.42 * s, 6 * s, .42 * s], M.BARK, E);
    const cy = 7.5 * s, cr = 3.2 * s;
    for (let k = 0; k < 9; k++) { const a = R() * TAU, r = Math.sqrt(R()) * cr, sz = (2.0 + R() * 1.8) * s, yy = cy + (R() - .45) * 3.4 * s;
      el('sphere', [x + Math.cos(a) * r, yy, z + Math.sin(a) * r], [sz, sz * .8, sz], M.LEAVES, { ...E, col: v3.mul(c, .8 + R() * .45) }); }
  };
  const n = Math.round(46 * Q.trees);
  for (let i = 0; i < n; i++) { const x = -48 + R() * 105, z = -16 - R() * 26; tree(x, z, .8 + R() * .6, R() < .35); }
  for (let i = 0; i < Math.round(12 * Q.trees); i++) { const side = i % 2 ? 1 : -1, x = side > 0 ? 27 + R() * 20 : -20 - R() * 20, z = -13 + R() * 9; tree(x, z, .8 + R() * .5, R() < .3); }
  tree(-12.5, -10, 1.15, false); tree(19, -11, 1.1, false); tree(-20, 17, 1.0, false); tree(26, 18.5, .95, false);
  // neighbour houses (muted, fog-softened; warm windows before dawn and after dusk)
  const house = (x, z, w, d, h, col, rotY = 0) => {
    el('cube', [x, h / 2, z], [w, h, d], M.NSIDING, { ...E, col });
    el('prism', [x, h + 1.7, z], [d + .6, 3.4, w + .6], M.SHINGLE, { ...E, rot: [Math.PI / 2, 0, 0], extra: 99 });
    for (let k = 0; k < 4; k++) el('cube', [x - w / 2 + 1.5 + k * (w - 3) / 3, k % 2 ? 1.7 : 4.6, z + d / 2 + .02], [1, 1.2, .04], M.EMIT, { ...E, col: [3.2, 2.1, 1.1], emitOn: -1 });
  };
  house(-27, 0, 12, 9, 6, [.42, .46, .5]); house(33, -1, 13, 10, 6, [.62, .58, .5]); house(-52, -3, 12, 9, 6, [.55, .52, .46]); house(58, 0, 12, 9, 6, [.4, .44, .47]);
  // street lights
  [[21, 13.8], [44, 13.8]].forEach(([x, z]) => {
    el('cyl', [x, 3, z], [.12, 6, .12], M.BLACK, E); el('cube', [x, 5.95, z + .5], [.08, .08, 1.1], M.BLACK, E);
    el('cube', [x, 5.88, z + 1.0], [.34, .1, .5], M.EMIT, { ...E, col: [14, 9, 4.5], emitOn: -1 });
  });
}

/* =====================================================================================
   10 · BLUEPRINT SYSTEM — survey lines, footprint, plan, dimensions, walls rising as
   outlines, floating elevation drawing, and the QCR identity at the end
   ===================================================================================== */
const GOLD = [1.0, .62, .24], WARM = [1, .86, .66];
let LN = {};
function buildBlueprint() {
  const rect = (L, x0, z0, x1, z1, y, col, d = 0, du = 0) => L.poly([[x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1]], col, d, du, 0, true);
  // footprint (also the loop anchor)
  const F = new Lines();
  rect(F, -6, -4.5, 6, 4.5, .04, GOLD, .75, .9); rect(F, 6, -3.5, 12.4, 4.5, .04, GOLD, 1.2, .7); rect(F, -6, 4.5, 1.5, 6.6, .04, GOLD, 1.45, .5);
  LN.footStatic = (() => { const S = new Lines(); rect(S, -6, -4.5, 6, 4.5, .04, GOLD); rect(S, 6, -3.5, 12.4, 4.5, .04, GOLD); rect(S, -6, 4.5, 1.5, 6.6, .04, GOLD); return S.build(); })();
  LN.foot = F.build();
  // survey: long setback line + side line, string lines between batter boards
  const S = new Lines();
  S.seg([-38, .03, 7.8], [40, .03, 7.8], WARM, .15, .95); S.seg([-7.2, .03, 13], [-7.2, .03, -14], WARM, .55, .8);
  rect(S, -7.2, -5.7, 7.2, 5.7, .48, [.9, .7, .45], 1.0, 1.1);
  [[-6, 4.5], [6, 4.5], [6, -4.5], [-6, -4.5]].forEach(([x, z], i) => { S.seg([x - .5, .04, z], [x + .5, .04, z], WARM, .6 + i * .1, .2); S.seg([x, .04, z - .5], [x, .04, z + .5], WARM, .65 + i * .1, .2); });
  LN.survey = S.build();
  // floor plan with door swings
  const P = new Lines();
  WI.forEach((w, i) => { const a = w.a, b = v3.add(w.a, v3.mul(w.t, w.L)); P.seg([a[0], .045, a[2]], [b[0], .045, b[2]], GOLD, 2.3 + i * .1, .35); });
  const arc = (cx, cz, r, a0, a1, d) => { const pts = []; for (let k = 0; k <= 16; k++) { const a = a0 + (a1 - a0) * k / 16; pts.push([cx + Math.cos(a) * r, .045, cz + Math.sin(a) * r]); } P.poly(pts, [.85, .6, .3], d, .3); };
  arc(-1.5, 4.5, 1.0, -Math.PI / 2, 0, 2.7); arc(.9, 2.2, .8, 0, -Math.PI / 2, 2.8); arc(3.6, 1.5, .9, 0, -Math.PI / 2, 2.85);
  // island + counters on plan
  rect(P, -3.25, -2.1, -.35, -1.1, .045, [.85, .6, .3], 2.9, .3); rect(P, -5.86, -4.36, .65, -3.76, .045, [.85, .6, .3], 2.95, .3);
  LN.plan = P.build();
  // dimensions (front + right side), ticks
  const D = new Lines(), dimCol = [.95, .72, .42];
  const dim = (a, b, off, d) => { const t = v3.norm(v3.sub(b, a)), n = [t[2], 0, -t[0]]; const A = v3.add(a, v3.mul(n, off)), B = v3.add(b, v3.mul(n, off));
    D.seg(A, B, dimCol, d, .4); for (const p of [A, B]) { D.seg(v3.add(p, v3.mul(n, -.25)), v3.add(p, v3.mul(n, .25)), dimCol, d + .3, .15); D.seg(v3.add(p, [-.15, 0, -.15]), v3.add(p, [.15, 0, .15]), dimCol, d + .3, .15); } };
  dim([-6, .05, 7.9], [6, .05, 7.9], 0, 2.6); dim([6, .05, 7.9], [12.4, .05, 7.9], 0, 2.75); dim([13.8, .05, 4.5], [13.8, .05, -4.5], 0, 2.9);
  LN.dims = D.build();
  // architectural outline of the whole house (rises from the plan, returns at the end)
  const O = new Lines(), oc = [1, .74, .4];
  const outlineWall = w => { const P0 = wp(w, 0, 0, 0), P1 = wp(w, w.L, 0, 0), P2 = wp(w, w.L, w.h, 0), P3 = wp(w, 0, w.h, 0); O.poly([P0, P1, P2, P3], oc, 0, 0, 0, true);
    w.ops.forEach(op => O.poly([wp(w, op.u0, op.v0, 0), wp(w, op.u1, op.v0, 0), wp(w, op.u1, op.v1, 0), wp(w, op.u0, op.v1, 0)], [.9, .6, .3], 0, 0, 0, true)); };
  [...W1, ...W2, ...WG, ...WI].forEach(outlineWall);
  for (const s of [-6.36, 6.36]) O.poly([[s, 5.85, 4.95], [s, RIDGE, 0], [s, 5.85, -4.95]], oc);
  O.seg([-6.36, RIDGE, 0], [6.36, RIDGE, 0], oc); O.seg([-6.36, 5.85, 4.95], [6.36, 5.85, 4.95], oc); O.seg([-6.36, 5.85, -4.95], [6.36, 5.85, -4.95], oc);
  for (const z of [4.86, -3.86]) O.poly([[6, 3.15, z], [9.2, GRIDGE, z], [12.75, GRIDGE - 3.55 * TANA, z]], oc);
  O.seg([9.2, GRIDGE, 4.86], [9.2, GRIDGE, -3.86], oc); O.seg([12.75, GRIDGE - 3.55 * TANA, 4.86], [12.75, GRIDGE - 3.55 * TANA, -3.86], oc);
  O.poly([[-6, 3.35, 4.5], [-6, 3.0, 6.75], [1.6, 3.0, 6.75], [1.6, 3.35, 4.5]], oc);
  [-5.7, -3.6, 1.3].forEach(x => O.seg([x, .3, 6.4], [x, 2.95, 6.4], oc));
  O.poly([[-7.2, .3, -.6], [-7.2, 10.2, -.6], [-6.1, 10.2, -.6], [-6.1, .3, -.6]], oc);
  LN.outline = O.build();
  // floating front elevation drawing behind the house
  const EL = new Lines(), ec = [.95, .7, .38], s = .42, ox = 9.5, oy = 5.4, oz = -12;
  const E = (x, y) => [ox + x * s, oy + y * s, oz];
  EL.poly([E(-11, -1), E(13.5, -1), E(13.5, 11), E(-11, 11)], [.6, .45, .28], 2.8, .6, 0, true);
  EL.seg(E(6, -1), E(6, 1), [.6, .45, .28], 3.2, .2); EL.seg(E(6, 1), E(13.5, 1), [.6, .45, .28], 3.2, .2);
  EL.poly([E(-6, 0), E(6, 0), E(6, 6), E(-6, 6)], ec, 3.0, .5, 0, true);
  EL.poly([E(-6.4, 5.85), E(0, RIDGE), E(6.4, 5.85)], ec, 3.3, .4);
  EL.poly([E(6, 0), E(12.4, 0), E(12.4, 3), E(6, 3)], ec, 3.2, .4, 0, true); EL.poly([E(6, 3.15), E(9.2, GRIDGE), E(12.75, 2.92)], ec, 3.4, .3);
  [[-5, .9, -3.4, 2.4], [-1.5, 0, -.5, 2.3], [3.0, .9, 4.6, 2.4], [-4.8, 4.2, -3.6, 5.6], [-1.6, 4.2, -.4, 5.6], [1.4, 4.2, 2.6, 5.6], [4.4, 4.2, 5.6, 5.6], [6.8, 0, 11.6, 2.25]]
    .forEach(([a, b, c, d], i) => EL.poly([E(a, b), E(c, b), E(c, d), E(a, d)], [.85, .6, .32], 3.5 + i * .05, .25, 0, true));
  LN.elev = EL.build();
  // QCR identity: guide lines → roofline chevron → Q C R strokes
  const Qn = new Lines(), qc = [1, .7, .32], cx = 3.2, by = 9.75, zq = -2.2, hh = 1.45, lw = 1.2, gap = .5;
  const P3 = (x, y) => [cx + x, by + y, zq];
  const tot = lw * 3 + gap * 2, x0 = -tot / 2;
  Qn.seg(P3(x0 - 1.2, 0), P3(-x0 + 1.2, 0), [.55, .4, .22], 0, .5); Qn.seg(P3(x0 - 1.2, hh), P3(-x0 + 1.2, hh), [.55, .4, .22], .1, .5);
  Qn.poly([P3(x0 - .35, hh + .28), P3(0, hh + .95), P3(-x0 + .35, hh + .28)], [1, .22, .12], .45, .6);   // QCR red roof
  const ell = (xc, a0, a1, d) => { const pts = []; for (let k = 0; k <= 36; k++) { const a = a0 + (a1 - a0) * k / 36; pts.push(P3(xc + Math.cos(a) * lw / 2, hh / 2 + Math.sin(a) * hh / 2)); } Qn.poly(pts, qc, d, .55); };
  ell(x0 + lw / 2, Math.PI / 2, Math.PI / 2 + TAU, .6); Qn.seg(P3(x0 + lw * .62, hh * .28), P3(x0 + lw * 1.02, -.08), qc, 1.1, .2);
  ell(x0 + lw + gap + lw / 2, .75, TAU - .75, .75);
  const rx = x0 + 2 * (lw + gap);
  Qn.poly([P3(rx, 0), P3(rx, hh), P3(rx + lw * .62, hh)], qc, .9, .35);
  const bowl = []; for (let k = 0; k <= 16; k++) { const a = Math.PI / 2 - Math.PI * k / 16; bowl.push(P3(rx + lw * .62 + Math.cos(a) * hh * .25, hh * .75 + Math.sin(a) * hh * .25)); }
  Qn.poly([...bowl, P3(rx, hh * .5)], qc, 1.15, .3); Qn.seg(P3(rx + lw * .45, hh * .5), P3(rx + lw, 0), qc, 1.35, .2);
  LN.qcr = Qn.build();
}

/* =====================================================================================
   13 · CONSTRUCTION TIMELINE — lighting keys (pre-dawn → morning → day → rain →
   afternoon → golden hour → dusk ≡ pre-dawn) and per-frame state
   ===================================================================================== */
//                 t     elev  az   int  sun rgb          sky zenith rgb       horizon rgb          fog    expo  cloud amb
const LIGHT = new Track([
  [0, -9, 20, 0, 1, 0.5, 0.3, 0.012, 0.02, 0.05, 0.045, 0.06, 0.1, 0.0143, 2.5, 0.2, 0.8],
  [2.4, -3, 20, 0, 1, 0.5, 0.3, 0.025, 0.04, 0.09, 0.16, 0.11, 0.13, 0.0121, 2.1, 0.2, 0.85],
  [4.8, 4, 22, 1.02, 1, 0.52, 0.28, 0.1, 0.16, 0.3, 0.55, 0.36, 0.28, 0.0077, 1.35, 0.2, 0.9],
  [8, 16, 35, 1.768, 1, 0.8, 0.6, 0.2, 0.35, 0.6, 0.6, 0.62, 0.66, 0.0044, 1.05, 0.25, 1],
  [11, 38, 60, 2.108, 1, 0.95, 0.88, 0.2, 0.38, 0.72, 0.62, 0.7, 0.8, 0.0033, 0.95, 0.3, 1],
  [12.8, 42, 70, 0.68, 0.9, 0.92, 0.95, 0.26, 0.29, 0.33, 0.44, 0.46, 0.5, 0.0066, 1.15, 1, 1.25],
  [13.8, 44, 78, 0.612, 0.9, 0.92, 0.95, 0.26, 0.29, 0.33, 0.44, 0.46, 0.5, 0.0066, 1.15, 1, 1.25],
  [15, 48, 90, 2.108, 1, 0.95, 0.88, 0.2, 0.38, 0.72, 0.62, 0.7, 0.8, 0.0033, 0.95, 0.3, 1],
  [18.2, 38, 115, 1.972, 1, 0.93, 0.84, 0.2, 0.37, 0.7, 0.62, 0.68, 0.76, 0.0033, 1.3, 0.25, 1],
  [24.6, 24, 135, 1.836, 1, 0.86, 0.7, 0.2, 0.34, 0.62, 0.64, 0.64, 0.66, 0.0039, 1.3, 0.25, 1],
  [25.6, 14, 145, 1.632, 1, 0.76, 0.5, 0.18, 0.28, 0.5, 0.7, 0.58, 0.46, 0.0044, 1, 0.25, 0.95],
  [27, 6, 152, 1.428, 1, 0.56, 0.26, 0.16, 0.2, 0.36, 0.85, 0.5, 0.3, 0.005, 1.1, 0.2, 0.85],
  [28.6, 0.5, 158, 0.476, 1, 0.42, 0.18, 0.06, 0.08, 0.18, 0.5, 0.28, 0.2, 0.0072, 1.6, 0.2, 0.8],
  [30, -9, 20, 0, 1, 0.5, 0.3, 0.012, 0.02, 0.05, 0.045, 0.06, 0.1, 0.0143, 2.5, 0.2, 0.8],
], LOOP);

/* ---- camera: one continuous shot (pos, look, fov). t=30 ≡ t=0 ---- */
const CAM = new Track([
  [0.0, -12, 3.4, 33,      3.5, 2.4, 0,     38],
  [2.6,  -6.5, 2.6, 21,    3, .6, 0,        40],
  [4.9,  -2.5, 1.5, 13,    1.5, .4, 0,      42],
  [6.6,   6, 1.15, 10.8,   0, .35, 0,       42],
  [8.2,  15, 3.0, 9.5,     2, 1.6, 0,       42],
  [9.8,  17.5, 6.5, -5.5,  2, 3.2, 0,       42],
  [11.2,  6.5, 11.5, -16.5, 1, 5.2, 0,      42],
  [12.6, -10, 12.5, -9,    0, 7, 0,         42],
  [14.0, -16, 7.5, 8,      1, 4.5, 0,       42],
  [15.4,  -6.5, 4.2, 17,   2, 3, 0,         42],
  [16.6,  -2.6, 2.0, 11,   -1, 1.6, 4.5,    44],
  [17.6,  -1, 1.65, 6.7,   -1, 1.5, 3,      48],
  [18.2,  -1, 1.62, 3.9,   -1, 1.5, 0,      54],
  [19.3,  -.8, 1.66, 1.4,  -2, 1.4, -2,     56],
  [20.4,   .8, 1.7, -.2,   -1.8, 1.25, -3.8, 54],
  [21.4,  -1.2, 1.3, -1.1, -2.6, 1.05, -4.2, 48],
  [22.1,   .25, 1.48, -.6,  -1.6, 1.18, -1.75, 44],
  [22.8,  1.1, 1.6, 1.2,   1.9, 1.3, 3.8,   52],
  [23.6,  1.25, 1.5, 1.95,  1.65, 1.62, 4.35, 62],
  [23.95, 1.2, 1.65, 1.55, -.3, 1.5, 3,     58],
  [24.4,  -.9, 1.7, 2.4,   -1, 1.6, 6,      52],
  [25.1,  -1, 1.85, 6.9,   -1, 2.0, 12,     48],
  [26.0,   6, 3.8, 15,     2, 3, 0,         42],
  [27.2,   9, 4.2, 22,     3, 3.2, 0,       40],
  [28.4,  -3, 3.6, 31,     3.5, 2.6, 0,     38],
  [30.0, -12, 3.4, 33,     3.5, 2.4, 0,     38],
], LOOP);

/* =====================================================================================
   14 · RESPONSIVE CAMERA — FOV / dolly / lens shift adapt to any aspect ratio
   ===================================================================================== */
const VIEW = { w: 1, h: 1, dpr: 1 };
const cam = { pos: [0, 0, 0], look: [0, 0, 0], right: [1, 0, 0], up: [0, 1, 0], fwd: [0, 0, -1], view: new Float32Array(16), proj: new Float32Array(16), tan: [1, 1], shift: [0, 0] };
const _c = [];
function updateCamera(t) {
  CAM.eval(t, _c);
  let pos = [_c[0], _c[1], _c[2]]; const look = [_c[3], _c[4], _c[5]]; const fov = _c[6];
  const interior = win(t, 17.4, 25.3, .5, .4);
  const w = TAU / LOOP; pos = v3.add(pos, v3.mul([Math.sin(t * w * 3 + 1) * .03, Math.sin(t * w * 4) * .02, 0], 1 - interior));   // subtle handheld float
  const aspect = VIEW.w / VIEW.h, base = 16 / 9;
  let tanV = Math.tan(fov * DEG / 2), dolly = 1;
  if (aspect < base) {                                  // keep ~76% of the house width on narrow screens
    const need = Math.tan(fov * DEG / 2) * base * .76 / aspect, cap = Math.tan(lerp(33, 41, interior) * DEG);
    if (need > tanV) { tanV = Math.min(need, cap); dolly = lerp(Math.min(need / tanV, 1.5), 1, interior); }
  }
  pos = v3.add(look, v3.mul(v3.sub(pos, look), dolly));
  cam.pos = pos; cam.look = look;
  const f = v3.norm(v3.sub(look, pos)); const r = v3.norm(v3.cross(f, [0, 1, 0])); const u = v3.cross(r, f);
  cam.fwd = f; cam.right = r; cam.up = u;
  lookAtM(pos, f, r, u, cam.view);
  const portrait = aspect < 1;
  const sx = portrait ? 0 : CFG.focusX * sstep(1.15, 1.5, aspect) * (1 - .55 * interior), sy = portrait ? CFG.focusYMobile * (1 - interior) : 0;
  const near = .05, far = 700, P = cam.proj; P.fill(0);
  P[5] = 1 / tanV; P[0] = P[5] / aspect; P[8] = -sx; P[9] = -sy; P[10] = (far + near) / (near - far); P[11] = -1; P[14] = 2 * far * near / (near - far);
  cam.tan = [tanV * aspect, tanV]; cam.shift = [sx, sy];
  return interior;
}

/* =====================================================================================
   16 · FRAME COMPOSITION
   ===================================================================================== */
const LIGHTS = [   // [x, y, z, radius, r, g, b, flag(1 interior / 2 exterior), onTime, offTime(0 = never), kind]
  [-1, 2.85, 3.3, 5.5, 3.4, 2.4, 1.4, 1, 19.95, 0], [-1, 2.85, 1.9, 5.5, 3.4, 2.4, 1.4, 1, 20.1, 0], [-4, 2.85, 3.0, 5.5, 3, 2.1, 1.2, 1, 20.3, 0],
  [4.4, 2.85, 3.0, 5, 3, 2.1, 1.2, 1, 20.55, 0], [-3.6, 2.85, -2.8, 5.5, 3.4, 2.4, 1.4, 1, 22.0, 0], [-.2, 2.85, -2.8, 5.5, 3.4, 2.4, 1.4, 1, 22.2, 0],
  [3.6, 2.85, -2.2, 5.5, 3, 2.1, 1.2, 1, 22.36, 0], [-2.7, 1.95, -1.6, 3.2, 2.2, 1.35, .6, 1, 22.1, 0], [-1.8, 1.95, -1.6, 3.2, 2.2, 1.35, .6, 1, 22.16, 0],
  [-.9, 1.95, -1.6, 3.2, 2.2, 1.35, .6, 1, 22.22, 0], [-2, 1.38, -4.0, 3, 1.6, 1.15, .6, 1, 22.0, 0], [-3.5, 1.9, -1.0, 6, 3.8, 4.2, 4.8, 1, 18.2, 21.95],
  [1.0, 1.9, -2.6, 6, 3.8, 4.2, 4.8, 1, 18.25, 21.95], [1.2, 2.2, 4.0, 3.5, 2.6, 1.9, 1.1, 1, 23.35, 0], [2.2, 2.85, 3.4, 4, 2.6, 1.9, 1.1, 1, 23.4, 0],
  [-1.78, 2.1, 4.9, 4.5, 2.6, 1.6, .7, 2, 16.7, 0], [-.22, 2.1, 4.9, 4.5, 2.6, 1.6, .7, 2, 16.7, 0], [6.45, 2.45, 4.9, 4.5, 2.6, 1.6, .7, 2, 16.75, 0],
  [11.95, 2.45, 4.9, 4.5, 2.6, 1.6, .7, 2, 16.75, 0], [44, 5.7, 14.8, 16, 5, 3.4, 1.6, 2, -1, 0], [21, 5.7, 14.8, 16, 5, 3.4, 1.6, 2, -1, 0],
];
const LP = new Float32Array(80), LC = new Float32Array(80);
const QC_POINTS = [[-5, .9 + .3, 4.62, 24.1], [-1.5, 2.6, 4.4, 24.2], [.65, 1.23, -3.72, 24.28], [-3.25, 1.22, -1.0, 24.36], [-2.2, 1.2, 1.5, 24.44], [-1, .33, 1.2, 24.52], [5.86, 2.9, -4.36, 24.6],
  [-6.36, 5.85, 4.95, 25.6], [0, RIDGE, 0, 25.75], [6.36, 5.85, 4.95, 25.9], [9.2, GRIDGE, 4.86, 26.0], [12.75, 2.92, 4.86, 26.1], [-3.4, 2.4, 4.6, 25.7]];
let TREND = null;
function computeState(t) {
  const L = LIGHT.eval(t, []);
  const el = L[0] * DEG, az = L[1] * DEG;
  const sunDir = v3.norm([Math.cos(el) * Math.cos(az), Math.sin(el), Math.cos(el) * Math.sin(az)]);
  const sunI = L[2] * sstep(-1.5, 3, L[0]);
  const sunCol = [L[3] * sunI, L[4] * sunI, L[5] * sunI];
  const sky = [L[6], L[7], L[8]], hor = [L[9], L[10], L[11]];
  const night = 1 - sstep(-4, 6, L[0]);
  const end = sstep(28.85, 29.55, t);
  const rain = win(t, 12.7, 14.2, .35, .45);
  return {
    sunDir, sunI, sunCol, sky, hor, night, end, rain,
    fogDen: L[12], exposure: L[13], cloud: L[14], amb: L[15],
    gnd: v3.add(v3.mul(hor, .32), v3.mul(sunCol, .025)), fogCol: v3.add(v3.mul(hor, .92), v3.mul(sky, .12)),
    wet: sstep(12.9, 13.6, t) * (1 - sstep(14.8, 17, t)),
    shingles: clamp((t - 12.8) / 1.15) * 47,
    wrap: clamp((t - 13.0) / .9) * 1.02,
    floorR: t < 18.9 ? 0 : clamp((t - 18.95) / 1.15) * 15,
    paintR: clamp((t - 19.3) / 1.25) * 14,
    lawnR: sstep(15.4, 16.9, t) * 32 * (1 - sstep(29.0, 29.85, t)),
    door: eio(sstep(17.25, 17.85, t)) * (1 - eio(sstep(25.55, 26.3, t))),
    winGlow: sstep(19.8, 21.2, t) * (.55 + .45 * sstep(25, 28.3, t)) * (1 - end),
    intAmb: lerp(1, .2, sstep(12.2, 14.2, t)),
    warm: sstep(25.5, 27.5, t) * (1 - sstep(28.8, 29.8, t)) * .8,
  };
}
function orthoLight(sunDir) {
  const C = [3, 3, 0], eye = v3.add(C, v3.mul(sunDir, 45)), f = v3.mul(sunDir, -1);
  let up = Math.abs(sunDir[1]) > .98 ? [0, 0, 1] : [0, 1, 0];
  const r = v3.norm(v3.cross(f, up)), u = v3.cross(r, f);
  const V = lookAtM(eye, f, r, u, new Float32Array(16));
  const e = 21, n = 1, fa = 100, O = new Float32Array(16);
  O[0] = 1 / e; O[5] = 1 / e; O[10] = -2 / (fa - n); O[14] = -(fa + n) / (fa - n); O[15] = 1;
  return mul4(O, V);
}
const OPAQUE_SETS = ['cube', 'prism', 'sphere', 'cyl', 'cone'];
function renderFrame(t, wallTime) {
  STATS.calls = 0;
  const still = REDUCED.matches && CFG.freeze === null;   // reduced motion: static composition, no transient lines/words
  const interior = updateCamera(t);
  const S = computeState(t);
  // active lights (sorted by proximity, capped per tier)
  const act = [];
  for (const l of LIGHTS) {
    let k = l[8] < 0 ? S.night : sstep(l[8], l[8] + .25, t) * (l[9] ? 1 - sstep(l[9], l[9] + .2, t) : 1) * (1 - S.end);
    if (l[8] < 0) k *= 1; if (k <= .002) continue;
    act.push([l, k, Math.hypot(l[0] - cam.pos[0], l[1] - cam.pos[1], l[2] - cam.pos[2])]);
  }
  act.sort((a, b) => a[2] - b[2]); const nl = Math.min(act.length, Q.lights);
  for (let i = 0; i < nl; i++) { const [l, k] = act[i]; LP.set([l[0], l[1], l[2], l[3]], i * 4); LC.set([l[4] * k, l[5] * k, l[6] * k, l[7]], i * 4); }
  const shadowVP = S.sunI > .02 ? orthoLight(S.sunDir) : null;
  const lw = TAU / LOOP;
  Object.assign(GLOBAL, {
    uView: cam.view, uProj: cam.proj, uCamPos: cam.pos, uCamRight: cam.right, uCamUp: cam.up, uCamFwd: cam.fwd,
    uTime: wallTime, uT: t, uPS: RT.h * .5, uBoost: 1,
    uSunDir: S.sunDir, uSunCol: S.sunCol, uSkyCol: S.sky, uHorCol: S.hor, uGndCol: S.gnd, uFogCol: S.fogCol,
    uAmb: S.amb, uFogDen: S.fogDen, uShadowOn: shadowVP ? clamp(S.sunI / .6) : 0, uIntAmb: S.intAmb, uNight: S.night, uCloud: S.cloud, uWet: S.wet,
    uNL: nl, uPcf: Q.pcf, uLP: LP, uLC: LC, uShadowMat: shadowVP || cam.proj, uShadow: RT.shadow.tex, uLightVP: shadowVP || cam.proj,
    uEnd: S.end, uShingles: S.shingles, uWrap: S.wrap, uFloorR: S.floorR, uPaintR: S.paintR, uPaintO: [-1, 0, 3.2], uFloorO: [-1, 0, 4.4],
    uDoor: S.door, uWind: t * lw * 6, uWinGlow: S.winGlow, uLawnR: S.lawnR,
    uScanOn: win(t, 24.0, 24.7, .1, .15) + win(t, 25.35, 26.25, .15, .2), uScanPos: t < 25 ? lerp(.3, 3.0, clamp((t - 24.0) / .7)) : lerp(-.2, 10, clamp((t - 25.35) / .9)), uScanDir: [0, 1, 0],
  });
  // ---- shadow pass ----
  if (shadowVP) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, RT.shadow.fb); gl.viewport(0, 0, RT.shadow.size, RT.shadow.size);
    gl.depthMask(true); gl.clear(gl.DEPTH_BUFFER_BIT); gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1.6, 3.0);
    for (const k of OPAQUE_SETS) SETS[k].draw(P_SHADOW, { uShadowPass: 1 }, { depth: 'write' });
    gl.disable(gl.POLYGON_OFFSET_FILL);
  }
  // ---- main pass ----
  const target = RT.msaa || RT.scene;
  gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb); gl.viewport(0, 0, RT.w, RT.h);
  gl.clearColor(0, 0, 0, 1); gl.depthMask(true); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  SKY.draw({ uFwd: cam.fwd, uRight: cam.right, uUp: cam.up, uTan: cam.tan, uShift: cam.shift, uTime: t * lw }, { blend: 'none', depth: 'none' });
  GROUND.draw({}, { blend: 'none', depth: 'write' });
  for (const k of OPAQUE_SETS) SETS[k].draw(P_INST, { uShadowPass: 0, uPass: 0 }, { depth: 'write', cull: k !== 'prism' && k !== 'cube' });
  SETS.glass.draw(P_INST, { uShadowPass: 0, uPass: 1 }, { depth: 'test', blend: 'normal' });

  // ---- blueprint & identity lines ----
  const footA = t < 12 ? .35 * (1 - sstep(.9, 1.6, t)) : sstep(29.25, 29.7, t) * (1 - .65 * sstep(29.72, 30, t));
  if (footA > .003) drawLines(LN.footStatic, { uOpacity: footA * 1.4 });
  if (t < 7) drawLines(LN.foot, { uLocal: t, uOpacity: 1.5 * (1 - sstep(5.2, 6.6, t)), uHead: 1 });
  if (t < 6) drawLines(LN.survey, { uLocal: t, uOpacity: 1.3 * (1 - sstep(4.4, 5.4, t)), uHead: 1 });
  if (t > 2.2 && t < 7) drawLines(LN.plan, { uLocal: t, uOpacity: 1.2 * (1 - sstep(5.6, 6.6, t)), uHead: 1 });
  if (t > 2.5 && t < 7) drawLines(LN.dims, { uLocal: t, uOpacity: .9 * (1 - sstep(5.4, 6.4, t)), uHead: 1 });
  if (t > 2.7 && t < 7.2) drawLines(LN.elev, { uLocal: t, uOpacity: .9 * (1 - sstep(6.0, 6.9, t)), uHead: 1 });
  const rise = t < 12 ? eio(sstep(3.2, 4.8, t)) : 1 - eio(sstep(29.15, 29.75, t));
  const outA = t < 12 ? win(t, 3.1, 8.4, .3, 1.3) * .95 : (.45 * sstep(27.3, 28.3, t) + .55 * sstep(28.75, 29.15, t)) * (1 - sstep(29.7, 29.95, t));
  if (outA > .003 && !still) drawLines(LN.outline, { uYScale: Math.max(rise, .002), uOpacity: outA });
  if (t > 27.5 && !still) drawLines(LN.qcr, { uLocal: t - 27.6, uOpacity: 2.6 * (1 - sstep(29.0, 29.6, t)), uHead: 1 });

  // ---- glows ----
  Sprites.begin();
  if (t > .1 && t < 1.3) Sprites.push([lerp(-38, 40, clamp((t - .15) / .95)), .06, 7.8], 1.1, v3.mul([1, .7, .35], 2.2 * win(t, .12, 1.25, .1, .2)));
  if (S.night > .01) { Sprites.push([44, 5.8, 14.8], 2.2, v3.mul([1, .7, .35], .9 * S.night)); Sprites.push([21, 5.8, 14.8], 2.2, v3.mul([1, .7, .35], .9 * S.night)); }
  const sc = sstep(16.7, 17, t) * (1 - S.end) * (.4 + .6 * Math.max(S.night, 1 - sstep(2, 20, S.sunI * 10)));
  if (sc > .01) [[-1.78, 2.15, 4.75], [-.22, 2.15, 4.75], [6.45, 2.5, 4.75], [11.95, 2.5, 4.75]].forEach(p => Sprites.push(p, .9, v3.mul([1, .68, .34], .55 * sc)));
  for (const [x, y, z, tq] of QC_POINTS) { const k = bump(t, tq, .14); if (k > .02) { Sprites.push([x, y, z], .16, v3.mul([1, .9, .7], 1.8 * k)); Sprites.push([x, y, z], .34, v3.mul([1, .8, .5], .8 * k), 1); } }
  Sprites.flush();

  // ---- subtle words (never permanent) ----
  Labels.begin();
  const gold = [1, .8, .5];
  Labels.push('D40', [0, .06, 8.35], .32, .8 * win(t, 3.0, 6.3, .4, .6), gold, [1, 0, 0], [0, 0, -1]);
  Labels.push('D21', [9.2, .06, 8.35], .32, .8 * win(t, 3.1, 6.3, .4, .6), gold, [1, 0, 0], [0, 0, -1]);
  Labels.push('D30', [14.25, .06, 0], .32, .8 * win(t, 3.3, 6.3, .4, .6), gold, [0, 0, -1], [-1, 0, 0]);
  Labels.push('ELEV', [9.5 - 11 * .42 + 2.3, 5.4 - .75 * .42, -12], .2, .8 * win(t, 3.3, 6.8, .4, .6), gold, [1, 0, 0], [0, 1, 0]);
  Labels.push('FOUNDATION', [10.5, .9, 6.5], .3, .75 * win(t, 5.2, 7.0, .4, .6), gold);
  Labels.push('SENT', [2.6, .42, 7.2], .085, .7 * win(t, 6.3, 8.1, .4, .6), [1, .92, .8]);
  Labels.push('STRUCTURE', [11, 7.2, 1], .36, .7 * win(t, 9.0, 10.8, .4, .6), gold);
  Labels.push('CRAFTSMANSHIP', [8.5, 9.6, 2], .34, .65 * win(t, 15.2, 16.7, .4, .5), gold);
  Labels.push('DETAIL', [-3.0, 2.55, -3.95], .13, .7 * win(t, 21.3, 22.6, .3, .5), gold, [1, 0, 0], [0, 1, 0]);
  Labels.push('BUILT', [-1, 2.42, 4.2], .11, .8 * win(t, 24.3, 24.8, .15, .15), [1, .95, .85]);
  Labels.push('READY', [-1, 2.42, 4.2], .11, .9 * win(t, 24.75, 25.3, .15, .25), gold);
  if (!still) Labels.push('QCRNAME', [3.2, 9.62, 1.2], .2, .75 * win(t, 28.1, 29.4, .5, .4), gold);
  Labels.flush();

  // ---- atmosphere ----
  DUST.draw({ uDustA: (.18 + .8 * sstep(4.6, 6, t) * (1 - sstep(15.5, 17, t))) * (1 - interior * .85), uLW: lw }, { blend: 'add', depth: 'test' });
  if (S.rain > .01) RAIN.draw({ uRainA: S.rain * .8 }, { blend: 'add', depth: 'test' });
  postProcess(S.exposure, S.warm);
}

/* =====================================================================================
   17 · PERFORMANCE MANAGEMENT · REDUCED MOTION · LIFECYCLE
   ===================================================================================== */
const Perf = {
  scale: 1, bloom: Q.bloom, msaa: Q.msaa, dirty: false, acc: 0, frames: 0, last: 0, fps: 0,
  sample(dt, now) {
    this.acc += dt; this.frames++; if (this.acc < 1.5) return;
    const avg = this.acc / this.frames; this.fps = 1 / avg; this.acc = 0; this.frames = 0;
    if (CFG.freeze !== null || now - this.last < 2500) return;
    if (avg > 1 / 45) { if (this.msaa) this.msaa = 0; else if (this.scale > .62) this.scale = Math.max(.6, this.scale - .12); else if (this.bloom) this.bloom = false; else return; this.dirty = true; this.last = now; resize(); }
    else if (avg < 1 / 57 && this.scale < 1) { this.scale = Math.min(1, this.scale + .08); this.dirty = true; this.last = now; resize(); }
  },
};
function resize() {
  const r = HOST.getBoundingClientRect(), w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
  VIEW.w = w; VIEW.h = h;
  let d = Math.min(window.devicePixelRatio || 1, Q.dpr); d = Math.min(d, Math.sqrt(Q.maxPix / (w * h))); d *= Perf.scale; VIEW.dpr = d;
  const bw = Math.max(1, Math.round(w * d)), bh = Math.max(1, Math.round(h * d));
  if (canvasEl.width !== bw || canvasEl.height !== bh || RT.w !== bw || RT.h !== bh || Perf.dirty || !RT.scene) { canvasEl.width = bw; canvasEl.height = bh; resizeTargets(bw, bh); Perf.dirty = false; }
  if (!running && READY) drawOnce();
}
let running = false, READY = false, raf = 0, last = 0, clock = CFG.freeze ?? 0, wallT = 0, visible = true, inView = true, hud = null, reducedTimer = 0;
const loopT = () => ((clock % LOOP) + LOOP) % LOOP;
function drawOnce() { if (!READY) return; renderFrame(REDUCED.matches && CFG.freeze === null ? STATIC_T : loopT(), wallT); }
function frame(now) {
  if (!running || destroyed) return;
  const dt = Math.min((now - last) / 1000, .1); last = now;
  if (CFG.freeze === null) clock += dt * CFG.speed;
  wallT += dt;
  renderFrame(loopT(), wallT);
  Perf.sample(dt, now);
  if (hud) hud.textContent = `t ${loopT().toFixed(2)}s · ${Perf.fps.toFixed(0)} fps · ${TIER}\n${canvasEl.width}×${canvasEl.height} · bloom ${Perf.bloom ? 'on' : 'off'} · msaa ${RT.msaa ? Perf.msaa : 0} · draws ${STATS.calls}`;
  raf = requestAnimationFrame(frame);
}
/* reduced motion: a static finished-home composition; only light and leaves breathe (≤4 fps, adaptive) */
function reducedLoop() {
  if (!REDUCED.matches || !visible || !inView || !READY) { reducedTimer = 0; return; }
  const t0 = performance.now(); wallT += .25; renderFrame(STATIC_T, wallT);
  const cost = performance.now() - t0;                                  // back off on slow devices
  reducedTimer = setTimeout(reducedLoop, Math.max(250, cost * 6));
}
function updateRunning() {
  if (destroyed) return;
  const should = READY && visible && inView && !REDUCED.matches && CFG.freeze === null;
  if (should && !running) { running = true; last = performance.now(); raf = requestAnimationFrame(frame); }
  else if (!should && running) { running = false; cancelAnimationFrame(raf); }
  if (!running && READY) { drawOnce(); if (REDUCED.matches && !reducedTimer && CFG.freeze === null) reducedLoop(); }
}
const onVis = () => { visible = !document.hidden; updateRunning(); };
document.addEventListener('visibilitychange', onVis);
const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => { inView = es[0].isIntersecting; updateRunning(); }) : null; if (io) io.observe(HERO);
(REDUCED.addEventListener ? REDUCED.addEventListener('change', updateRunning) : REDUCED.addListener(updateRunning));
canvasEl.addEventListener('webglcontextlost', e => { e.preventDefault(); running = false; cancelAnimationFrame(raf); canvasEl.classList.remove('is-ready'); });

/* ---- boot: the hero HTML is already visible; build the world off the critical path ---- */
function boot() {
  Labels.setAtlas(buildLabelAtlas([
    ['FOUNDATION', 'FOUNDATION', 56, 300, .45], ['STRUCTURE', 'STRUCTURE', 56, 300, .45], ['CRAFTSMANSHIP', 'CRAFTSMANSHIP', 56, 300, .45], ['DETAIL', 'DETAIL', 56, 300, .45],
    ['SENT', 'A GREAT HOME STARTS WITH A STRONG FOUNDATION', 40, 400, .32], ['BUILT', 'BUILT', 52, 400, .5], ['READY', 'READY', 52, 600, .5],
    ['QCRNAME', 'QUALITY CONSTRUCTION & RESTORATION LLC', 40, 400, .34], ['D40', `40'-0"`, 52, 400, .1], ['D30', `30'-0"`, 52, 400, .1], ['D21', `21'-0"`, 52, 400, .1],
    ['ELEV', 'FRONT ELEVATION  ·  SCALE 1/4" = 1\'-0"', 36, 400, .25],
  ]));
  buildHouse(); buildEnvironment(); buildBlueprint();
  for (const k in SETS) SETS[k].build();
  resize();
  READY = true;
  if (CFG.debug) { hud = document.createElement('div'); hud.className = 'qcr-hud'; document.body.appendChild(hud); }
  drawOnce();
  requestAnimationFrame(() => canvasEl.classList.add('is-ready'));
  updateRunning();
  window.__QCR_READY = true; HERO.dispatchEvent(new CustomEvent('qcr-hero-ready'));
}
const ro = new ResizeObserver(() => { if (READY && !destroyed) resize(); }); ro.observe(HOST);
(window.requestIdleCallback || (f => setTimeout(f, 16)))(() => { if (destroyed) return; try { boot(); } catch (e) { console.error('[qcr-hero]', e); canvasEl.remove(); } }, { timeout: 400 });

const api = {
  pause() { CFG.freeze = loopT(); updateRunning(); }, play() { CFG.freeze = null; updateRunning(); },
  seek(t) { clock = t; if (!running) drawOnce(); }, get time() { return loopT(); }, tier: TIER,
  destroy() {
    if (destroyed) return; destroyed = true; running = false; cancelAnimationFrame(raf); clearTimeout(reducedTimer);
    document.removeEventListener('visibilitychange', onVis); if (io) io.disconnect(); ro.disconnect();
    (REDUCED.removeEventListener ? REDUCED.removeEventListener('change', updateRunning) : REDUCED.removeListener(updateRunning));
    if (hud) hud.remove();
    const lose = gl.getExtension('WEBGL_lose_context'); if (lose) lose.loseContext();
    canvasEl.remove(); if (window.QCRHero === api) delete window.QCRHero;
  },
};
window.QCRHero = api;
return api;
}
window.QCRHero3D = { mount };
})();
