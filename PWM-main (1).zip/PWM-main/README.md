# Quality Construction & Restoration LLC — QCR website

Updated from the supplied PWM project to match the published charlotteqcr.com website retrieved on October 6, 2026.

## What is included

- The actual published QCR frontend, styles, logo rendering, content, and responsive layouts.
- Charcoal navigation, copper/orange accents, Fraunces/Inter typography and cinematic construction hero.
- English/Spanish toggle, services and service detail pages, gallery, before/after comparisons, inspiration brief, process and service area sections, budget calculator, about and contact pages.
- Local project photography, hero image, project video and dependency-free WebGL hero script.
- Existing QCR phone, WhatsApp links and Web3Forms email integration.
- The original PMW frontend retained in `legacy-pmw-source/` for reference. It is not loaded by the updated site.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```sh
npm ci
npm run dev
```

Open http://localhost:3000. Use an HTTP server; do not double-click index.html.

## Build and publish

```sh
npm run lint
npm run build
npm start
```

`dist/` already contains the production build. For static hosting, publish the **contents of dist/**. Enable SPA rewrites to index.html for routes such as /services and /gallery. An `_redirects` file is included for compatible hosts. The old /estimator URL redirects to /calculator with the included server or redirect rules.

No live website or domain was changed by this update.

## Editing and integrations

The original QCR component source was not supplied. To preserve the exact published appearance, `src/qcr/application.js` and `src/qcr/runtime.js` contain QCR's published compiled frontend. `src/index.css` contains its published CSS; `public/qcr-hero-bg.js` contains the readable hero renderer. The application entry is `src/main.tsx`. Original third-party license comments are retained.

The forms retain QCR's existing Web3Forms access key and WhatsApp recipient. A Web3Forms access key is intended to be public. Email delivery still depends on that account's configuration and any allowed-domain settings. No real inquiries were sent during verification. Optional duplicate requests to the unavailable /api/submit-lead endpoint were removed. The original demo server's hardcoded admin login and public customer-data endpoints were removed; this version does not store leads on its own server.

Google fonts, Google Maps, WhatsApp and email submission require internet access. The hero uses WebGL when supported and preserves QCR's image fallback on unsupported devices. Canonical and social URLs still identify charlotteqcr.com, matching the reference.

## Verification

- TypeScript check: passed.
- Production build: passed.
- HTTP responses for home, services, gallery, calculator, about, contact and service detail: passed.
- /estimator redirect: passed.
- All frontend media references resolve to included files.
- Hero script syntax: passed.
- The live reference was inspected visually. The browser environment blocked localhost, so visual and interactive testing of the rebuilt local version could not be completed. Form delivery was not tested.
