import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'full' | 'compact' | 'light';
  showPhone?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  variant = 'full',
  showPhone = true,
}) => {
  const isLight = variant === 'light';
  const navyColor = isLight ? '#FFFFFF' : '#0A2540';
  const blueColor = isLight ? '#60A5FA' : '#2563EB';
  const grayColor = isLight ? '#E2E8F0' : '#475569';

  return (
    <div className={`flex flex-col items-center select-none ${className}`}>
      {/* SVG Icon part: Twin Houses & 4 Tools */}
      <svg
        viewBox="0 0 320 180"
        className="w-full max-w-[240px] h-auto transition-transform duration-200 hover:scale-[1.02]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* House Roof Outer Outlines */}
        {/* Left Roof Gable */}
        <path
          d="M 120 45 L 30 115 L 42 115 L 120 58 L 198 115 L 210 115 Z"
          fill={navyColor}
        />
        {/* Right Roof Gable + Chimney */}
        <path
          d="M 215 30 L 130 95 L 140 95 L 215 38 L 290 95 L 300 95 Z"
          fill={navyColor}
        />
        {/* Chimney on Right House */}
        <path d="M 245 42 L 245 28 L 260 28 L 260 54 Z" fill={navyColor} />
        {/* Window grid in Right House */}
        <rect x="200" y="52" width="10" height="10" fill={navyColor} />
        <rect x="214" y="52" width="10" height="10" fill={navyColor} />
        <rect x="200" y="66" width="10" height="10" fill={navyColor} />
        <rect x="214" y="66" width="10" height="10" fill={navyColor} />

        {/* 4 Tool Silhouettes Aligned */}
        {/* 1. Hammer (Far Left) */}
        <g transform="translate(75, 80)">
          {/* Head */}
          <path d="M 0 5 C 0 0, 10 0, 18 5 L 18 10 C 14 10, 8 10, 0 10 Z" fill={navyColor} />
          <path d="M 18 3 L 26 3 L 26 12 L 18 12 Z" fill={navyColor} />
          {/* Handle */}
          <rect x="10" y="10" width="6" height="35" rx="1" fill={navyColor} />
        </g>

        {/* 2. Paintbrush (Middle Left) */}
        <g transform="translate(130, 80)">
          {/* Bristles */}
          <path d="M 0 0 L 22 0 L 20 18 L 2 18 Z" fill={blueColor} />
          <line x1="6" y1="2" x2="6" y2="12" stroke={navyColor} strokeWidth="1" opacity="0.3" />
          <line x1="11" y1="2" x2="11" y2="14" stroke={navyColor} strokeWidth="1" opacity="0.3" />
          <line x1="16" y1="2" x2="16" y2="12" stroke={navyColor} strokeWidth="1" opacity="0.3" />
          {/* Ferrule */}
          <rect x="1" y="18" width="20" height="6" fill={navyColor} />
          {/* Handle */}
          <path d="M 7 24 L 15 24 L 13 45 L 9 45 Z" fill={blueColor} />
        </g>

        {/* 3. Wrench (Middle Right) */}
        <g transform="translate(182, 80)">
          {/* Open End Head */}
          <path
            d="M 2 8 C 2 0, 18 0, 18 8 L 14 8 C 14 4, 6 4, 6 8 L 6 12 L 14 12 L 14 15 L 2 15 Z"
            fill={grayColor}
          />
          {/* Handle */}
          <rect x="6" y="15" width="8" height="30" fill={grayColor} />
        </g>

        {/* 4. Screwdriver (Far Right) */}
        <g transform="translate(230, 80)">
          {/* Tip */}
          <rect x="8" y="0" width="3" height="15" fill={blueColor} />
          {/* Shaft collar */}
          <rect x="6" y="15" width="7" height="4" fill={navyColor} />
          {/* Handle */}
          <path d="M 4 19 C 4 19, 15 19, 15 23 L 13 42 C 13 45, 6 45, 6 42 Z" fill={blueColor} />
        </g>

        {/* Under-house Curved Arc */}
        <path d="M 15 128 Q 160 108 305 128" stroke={blueColor} strokeWidth="3" fill="none" />
      </svg>

      {/* Brand Text Branding */}
      <div className="text-center mt-1">
        <h1
          className="font-extrabold tracking-wider leading-none text-2xl md:text-3xl"
          style={{ color: navyColor, fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
        >
          PROPERTY
        </h1>
        <div className="flex items-center justify-center gap-1.5 mt-1">
          <span className="h-[2px] w-4 rounded" style={{ backgroundColor: blueColor }} />
          <span
            className="text-xs md:text-sm font-bold tracking-[0.2em] uppercase"
            style={{ color: blueColor }}
          >
            MAINTENANCE WORKS
          </span>
          <span className="h-[2px] w-4 rounded" style={{ backgroundColor: blueColor }} />
        </div>

        <p
          className="text-[11px] md:text-xs tracking-[0.25em] font-medium uppercase mt-1"
          style={{ color: grayColor }}
        >
          REPAIR &nbsp;|&nbsp; MAINTAIN &nbsp;|&nbsp; IMPROVE
        </p>

        {/* Phone Badge pill if requested */}
        {showPhone && (
          <div
            className={`inline-flex items-center gap-2 px-3 py-1 mt-2.5 rounded-full border border-blue-600/30 ${
              isLight ? 'bg-white/10 text-white' : 'bg-blue-50 text-slate-900'
            }`}
          >
            <div className="p-1 rounded-full bg-blue-600 text-white">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
              </svg>
            </div>
            <span className="text-xs md:text-sm font-extrabold tracking-wider">
              980-308-1727
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
