import React, { useState } from 'react';
import { Calculator, Sparkles, CheckCircle2, Clock, ShieldAlert, ArrowRight, RefreshCw, Send, DollarSign, Calendar, MessageCircle } from 'lucide-react';
import { ALL_SERVICES, COMPANY_INFO, CHARLOTTE_NEIGHBORHOODS } from '../data/pmwData';
import { AIAnalysisResult } from '../types';

interface EstimateCalculatorProps {
  selectedServiceIds: string[];
  onToggleService: (serviceId: string) => void;
  onOpenScheduleWithEstimate: (estimateDetails: {
    propertyType: string;
    totalMin: number;
    totalMax: number;
    summary: string;
  }) => void;
}

export const EstimateCalculator: React.FC<EstimateCalculatorProps> = ({
  selectedServiceIds,
  onToggleService,
  onOpenScheduleWithEstimate,
}) => {
  // Mode selection: 'interactive' or 'ai'
  const [calculatorMode, setCalculatorMode] = useState<'interactive' | 'ai'>('interactive');

  // Interactive Form State
  const [propertyType, setPropertyType] = useState<string>('Single Family Home');
  const [squareFootage, setSquareFootage] = useState<number>(1800);
  const [urgency, setUrgency] = useState<'standard' | 'priority' | 'emergency'>('standard');
  const [zipCode, setZipCode] = useState<string>('28202');

  // AI Analyzer State
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null);

  // Calculate live subtotal based on selected items + sqft multiplier
  const calculateTotalRange = () => {
    let baseMin = 0;
    let baseMax = 0;

    if (selectedServiceIds.length === 0) {
      // Default base estimate based on property type and square footage if no specific services picked yet
      const sqftRate = 0.12;
      baseMin = Math.round(squareFootage * sqftRate + 120);
      baseMax = Math.round(baseMin * 1.35);
    } else {
      selectedServiceIds.forEach((id) => {
        const item = ALL_SERVICES.find((s) => s.id === id);
        if (item) {
          baseMin += item.basePrice;
          baseMax += Math.round(item.basePrice * 1.25);
        }
      });
    }

    // Urgency Multipliers
    if (urgency === 'priority') {
      baseMin = Math.round(baseMin * 1.15);
      baseMax = Math.round(baseMax * 1.15);
    } else if (urgency === 'emergency') {
      baseMin = Math.round(baseMin * 1.35);
      baseMax = Math.round(baseMax * 1.35);
    }

    return { min: baseMin, max: baseMax };
  };

  const { min: estimatedMin, max: estimatedMax } = calculateTotalRange();

  // Call server-side Gemini API for Project Analysis
  const handleAiAnalyze = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    setAiError(null);

    try {
      const response = await fetch('/api/gemini/analyze-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectDescription: aiPrompt,
          propertyType,
          squareFootage,
          zipCode,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data: AIAnalysisResult = await response.json();
      setAiResult(data);
    } catch (err: any) {
      console.error('AI Project Analyzer Error:', err);
      setAiError('Could not compute AI estimate right now. Please try using the interactive estimator below or call 980-308-1727.');
    } finally {
      setAiLoading(false);
    }
  };

  const openWhatsAppEstimate = (summary: string) => {
    const text = encodeURIComponent(
      `Hi Hugo! I used the PMW Estimate Calculator on your website for a property in Charlotte.\n` +
      `Property: ${propertyType} (${squareFootage} sq ft)\n` +
      `Scope: ${summary}\n` +
      `Can we discuss scheduling an onsite visit for pricing?`
    );
    window.open(`https://wa.me/19803081727?text=${text}`, '_blank');
  };

  return (
    <section id="calculator" className="py-20 bg-blue-50/50 scroll-mt-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-600 text-white text-xs font-extrabold uppercase tracking-widest shadow-md">
            <Calculator className="w-4 h-4" />
            <span>Instant Conversion Tool</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Instant Property Maintenance Estimator
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Get an instant, transparent quote for your Charlotte property in seconds. Use our interactive builder or let our AI analyze your custom job description.
          </p>

          {/* Mode Switcher */}
          <div className="pt-4 flex justify-center">
            <div className="bg-slate-200/80 p-1.5 rounded-2xl inline-flex gap-2 border border-slate-300">
              <button
                onClick={() => setCalculatorMode('interactive')}
                className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                  calculatorMode === 'interactive'
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                Interactive Scope Builder
              </button>
              <button
                onClick={() => setCalculatorMode('ai')}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                  calculatorMode === 'ai'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>AI Project Description Analyzer</span>
              </button>
            </div>
          </div>
        </div>

        {/* AI Mode Layout */}
        {calculatorMode === 'ai' && (
          <div id="ai-analyzer" className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 shadow-xl border border-blue-200/80 mb-12 animate-in fade-in duration-300">
            <div className="max-w-4xl mx-auto space-y-6">
              
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-600 text-white rounded-2xl shadow-md">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-extrabold text-slate-900">
                    Smart AI Project Analyzer
                  </h3>
                  <p className="text-xs text-slate-500">
                    Powered by Gemini AI — Describe your home or rental property needs in plain English.
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  Describe what you need fixed, painted, or improved in Charlotte:
                </label>
                <textarea
                  rows={4}
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="e.g., 'I have a 1,600 sq ft home in Ballantyne. Need 2 bedrooms painted off-white, 3 drywall patches repaired from doorknobs, and gutters cleared before winter.'"
                  className="w-full rounded-2xl border border-slate-300 p-4 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600 focus:border-blue-600 shadow-sm"
                />
              </div>

              {/* Sample Prompts */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-500 uppercase">Try an example:</span>
                <div className="flex flex-wrap gap-2">
                  {[
                    "Rental turnover: paint living room, fix 2 sticking doors, clean gutters in South End.",
                    "Deck restoration: replace 4 damaged boards, power wash and stain 250 sq ft deck in Myers Park.",
                    "Handyman package: mount two 65-inch TVs, fix cabinet hinges, install 1 vanity faucet."
                  ].map((example, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setAiPrompt(example)}
                      className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-left transition-colors"
                    >
                      "{example}"
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleAiAnalyze}
                disabled={aiLoading || !aiPrompt.trim()}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white font-extrabold py-4 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-3 disabled:opacity-50 text-base"
              >
                {aiLoading ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Analyzing Project & Regional Charlotte Rates...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Generate AI Project Estimate</span>
                  </>
                )}
              </button>

              {aiError && (
                <div className="p-4 bg-red-50 text-red-700 rounded-xl text-xs font-semibold">
                  {aiError}
                </div>
              )}

              {/* AI Analysis Result Display */}
              {aiResult && (
                <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl animate-in fade-in zoom-in-95 duration-300 border border-slate-800">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-blue-400">
                        {aiResult.primaryCategory} &bull; {aiResult.complexity} Job
                      </span>
                      <h4 className="text-2xl font-black text-white mt-1">
                        {aiResult.summary}
                      </h4>
                    </div>

                    <div className="bg-blue-600/20 border border-blue-500/30 p-4 rounded-2xl text-right shrink-0 flex flex-col justify-center">
                      <div className="text-[11px] uppercase tracking-wider text-blue-300 font-bold">Upfront Estimate</div>
                      <div className="text-lg sm:text-xl font-black text-blue-400">
                        Contact for Pricing
                      </div>
                    </div>
                  </div>

                  {/* Recommended Services Breakdown */}
                  <div className="space-y-3">
                    <h5 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                      Itemized Scope Breakdown:
                    </h5>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {aiResult.recommendedServices.map((srv, idx) => (
                        <div key={idx} className="bg-slate-800 p-3.5 rounded-xl border border-slate-700">
                          <div className="text-xs font-bold text-slate-200">{srv.name}</div>
                          <div className="text-[11px] text-blue-400 mt-1">Est. {srv.estimatedHours} Hours &bull; {srv.category}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Technician Tip */}
                  <div className="bg-blue-950/60 border border-blue-800/60 p-4 rounded-2xl text-xs text-blue-200 flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">PMW Tech Insight:</strong> {aiResult.expertTips}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      onClick={() =>
                        onOpenScheduleWithEstimate({
                          propertyType,
                          totalMin: aiResult.estimatedCostRange.min,
                          totalMax: aiResult.estimatedCostRange.max,
                          summary: aiResult.summary,
                        })
                      }
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-extrabold py-3.5 px-6 rounded-xl text-center shadow-lg flex items-center justify-center gap-2 text-sm"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>Lock in & Schedule Onsite Visit</span>
                    </button>

                    <button
                      onClick={() => openWhatsAppEstimate(aiResult.summary)}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3.5 px-6 rounded-xl text-center flex items-center justify-center gap-2 text-sm shadow-lg"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Send to Hugo on WhatsApp</span>
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

        {/* Interactive Mode Layout */}
        {calculatorMode === 'interactive' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Controls Column */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200 space-y-6">
              
              {/* Step 1: Property Type */}
              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-800 mb-2">
                  1. Select Property Type:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {['Single Family Home', 'Townhome / Condo', 'Rental / Airbnb', 'Commercial Office'].map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setPropertyType(type)}
                      className={`p-3 rounded-xl text-xs font-bold border transition-all text-center ${
                        propertyType === type
                          ? 'bg-blue-600 text-white border-blue-600 shadow-md'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Square Footage Slider */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-extrabold uppercase tracking-wider text-slate-800">
                    2. Property Size / Area:
                  </label>
                  <span className="text-sm font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-lg border border-blue-200">
                    {squareFootage.toLocaleString()} sq. ft.
                  </span>
                </div>
                <input
                  type="range"
                  min="500"
                  max="6000"
                  step="100"
                  value={squareFootage}
                  onChange={(e) => setSquareFootage(Number(e.target.value))}
                  className="w-full accent-blue-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-slate-400 font-medium mt-1">
                  <span>500 sq ft</span>
                  <span>3,000 sq ft</span>
                  <span>6,000+ sq ft</span>
                </div>
              </div>

              {/* Step 3: Selected Service Items Checklist */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-extrabold uppercase tracking-wider text-slate-800">
                    3. Choose Specific Service Scopes:
                  </label>
                  <span className="text-xs font-bold text-blue-600">
                    {selectedServiceIds.length} Selected
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-1">
                  {ALL_SERVICES.map((service) => {
                    const isChecked = selectedServiceIds.includes(service.id);
                    return (
                      <button
                        key={service.id}
                        type="button"
                        onClick={() => onToggleService(service.id)}
                        className={`p-3 rounded-xl text-left border text-xs font-semibold flex items-center justify-between transition-all ${
                          isChecked
                            ? 'bg-blue-50 border-blue-500 text-blue-900 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span className="truncate max-w-[180px]">{service.name}</span>
                        <span className="shrink-0 text-slate-900 font-extrabold ml-1">
                          {isChecked ? 'Selected' : 'Select'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 4: Urgency Timeline */}
              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-800 mb-2">
                  4. Urgency & Dispatch Timeline:
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {[
                    { key: 'standard', label: 'Standard (3-5 Days)', desc: 'Regular rates' },
                    { key: 'priority', label: 'Priority (24-48 Hrs)', desc: 'Fast turnover' },
                    { key: 'emergency', label: 'Same-Day Urgent', desc: 'Immediate dispatch' },
                  ].map((item) => (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setUrgency(item.key as any)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        urgency === item.key
                          ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="text-xs font-extrabold">{item.label}</div>
                      <div className="text-[10px] opacity-80 mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Right Summary & Call to Action Panel */}
            <div className="lg:col-span-5 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-800 space-y-6">
              
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-blue-400">
                  PMW Real-Time Estimate Output
                </span>
                <h3 className="text-2xl font-black text-white mt-1">
                  Request Final Quote
                </h3>
              </div>

              {/* Big Price Display */}
              <div className="bg-slate-800/90 border border-slate-700/80 p-6 rounded-2xl text-center shadow-inner">
                <div className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-1">
                  Upfront Estimate Range
                </div>
                <div className="text-2xl sm:text-3xl font-black text-blue-400 tracking-tight">
                  Contact for Pricing
                </div>
                <div className="text-xs text-slate-400 mt-2">
                  Pricing varies based on final inspection. Submit your request for an accurate quote.
                </div>
              </div>

              {/* Selected Scopes List */}
              <div className="space-y-2 border-t border-b border-slate-800 py-4">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Included Items ({selectedServiceIds.length > 0 ? selectedServiceIds.length : 'Base Package'}):
                </div>
                {selectedServiceIds.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">
                    Base property maintenance allowance for {squareFootage.toLocaleString()} sq ft {propertyType}.
                  </p>
                ) : (
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {selectedServiceIds.map((id) => {
                      const item = ALL_SERVICES.find((s) => s.id === id);
                      return (
                        <div key={id} className="flex justify-between text-xs text-slate-300">
                          <span className="truncate">{item?.name}</span>
                            <span className="font-bold text-blue-400 flex items-center"><CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Included</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <button
                  onClick={() =>
                    onOpenScheduleWithEstimate({
                      propertyType,
                      totalMin: estimatedMin,
                      totalMax: estimatedMax,
                      summary: `${selectedServiceIds.length} service scopes for ${squareFootage} sq ft ${propertyType}`,
                    })
                  }
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl shadow-blue-600/30 transition-all flex items-center justify-center gap-2 text-sm"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Lock in Quote & Schedule Visit</span>
                </button>

                <button
                  onClick={() =>
                    openWhatsAppEstimate(
                      `${selectedServiceIds.length} service scopes for ${squareFootage} sq ft ${propertyType}`
                    )
                  }
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 text-xs sm:text-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Estimate to Hugo on WhatsApp</span>
                </button>
              </div>

              <div className="text-[11px] text-slate-400 text-center">
                *Final firm quote confirmed upon free onsite inspection by PMW technician.
              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
};
