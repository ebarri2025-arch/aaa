import React from 'react';
import { COMPANY_INFO } from '../data/pmwData';
import { MessageCircle } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  const whatsappNumber = "19803081727";
  const defaultText = encodeURIComponent(
    `Hi Hugo! I am contacting you from the Property Maintenance Works website. I need an estimate or property service in Charlotte.`
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${defaultText}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3 group">
      {/* Tooltip Badge */}
      <div className="hidden sm:flex items-center bg-slate-900 text-white text-xs font-bold py-2 px-3.5 rounded-2xl shadow-xl border border-slate-800 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse mr-2" />
        Chat with Hugo on WhatsApp ({COMPANY_INFO.phone})
      </div>

      {/* Floating Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="relative bg-emerald-500 hover:bg-emerald-400 text-white p-4 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-110 flex items-center justify-center ring-4 ring-emerald-500/30"
        aria-label="Chat with Hugo on WhatsApp"
      >
        <MessageCircle className="w-7 h-7 fill-white text-emerald-500" />
        {/* Pulse Indicator */}
        <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-300 rounded-full animate-ping opacity-75" />
        <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-slate-900" />
      </a>
    </div>
  );
};
