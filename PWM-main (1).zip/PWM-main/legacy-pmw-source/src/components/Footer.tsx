import React from 'react';
import { Link } from 'react-router-dom';
import { COMPANY_INFO, CHARLOTTE_NEIGHBORHOODS } from '../data/pmwData';
import { Logo } from './Logo';
import { Phone, Mail, MapPin, Clock, ShieldCheck, ArrowUp, Lock } from 'lucide-react';

interface FooterProps {
  onOpenSchedule: () => void;
  onOpenEstimator: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenSchedule, onOpenEstimator }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-50 text-slate-700 border-t border-slate-200 relative pt-16 pb-12 overflow-hidden">
      {/* Top Accent Line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 via-blue-500 to-sky-400" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-200">
          
          {/* Column 1: Brand & Logo */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white rounded-2xl p-4 w-fit inline-block border border-slate-200 shadow-xs">
              <Logo variant="full" showPhone={false} className="max-w-[200px]" />
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-sm">
              Property Maintenance Works (PMW) provides reliable handyman repairs, precision interior & exterior painting, preventative maintenance, and custom property improvements across Greater Charlotte, NC.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <span className="text-xs font-bold text-slate-900 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-2xs">
                {COMPANY_INFO.bbbRating}
              </span>
              <span className="text-xs text-blue-700 font-bold flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" />
                Licensed & Insured
              </span>
            </div>
          </div>

          {/* Column 2: Quick Links & Services */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest text-blue-700">
              Core Services
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/services" className="hover:text-blue-600 text-slate-600 transition-colors">Handyman Repairs</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-blue-600 text-slate-600 transition-colors">Interior & Exterior Painting</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-blue-600 text-slate-600 transition-colors">Preventative Gutter Care</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-blue-600 text-slate-600 transition-colors">Deck Restoration & Staining</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-blue-600 text-slate-600 transition-colors">Flooring & Bathroom Refreshes</Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Navigation & Tools */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest text-blue-700">
              Tools & Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={onOpenEstimator} className="hover:text-blue-600 text-left font-bold text-blue-700 transition-colors">
                  Instant Estimate Calculator
                </button>
              </li>
              <li>
                <Link to="/estimator" className="hover:text-blue-600 text-slate-600 transition-colors">AI Project Analyzer</Link>
              </li>
              <li>
                <Link to="/#why-us" className="hover:text-blue-600 text-slate-600 transition-colors">Why Choose PMW</Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Dispatch Details */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest text-blue-700">
              Direct Contact & Dispatch
            </h4>

            <div className="space-y-3 text-xs">
              <a
                href={`tel:${COMPANY_INFO.phone}`}
                className="flex items-center gap-3 p-3 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 transition-all text-slate-900 group shadow-sm"
              >
                <div className="p-2 bg-blue-600 rounded-xl text-white group-hover:scale-110 transition-transform">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Direct Office Line</div>
                  <div className="text-base font-extrabold text-blue-600 tracking-wide">{COMPANY_INFO.phone}</div>
                </div>
              </a>

              <div className="flex items-center gap-2.5 text-slate-700 font-medium">
                <Mail className="w-4 h-4 text-blue-600 shrink-0" />
                <span>{COMPANY_INFO.email}</span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-700 font-medium">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
                <span>{COMPANY_INFO.serviceArea}</span>
              </div>

              <div className="flex items-start gap-2.5 text-slate-700 font-medium">
                <Clock className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.hours}</span>
              </div>
            </div>

            <button
              onClick={onOpenSchedule}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all text-xs"
            >
              Schedule Online Inspection
            </button>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} Property Maintenance Works (PMW). All Rights Reserved. Serving Charlotte NC.
          </div>

          <div className="flex items-center gap-6">
            <span className="text-slate-600 font-bold">REPAIR &bull; MAINTAIN &bull; IMPROVE</span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors flex items-center gap-1 text-[11px] font-semibold"
              aria-label="Scroll back to top"
            >
              <span>Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
