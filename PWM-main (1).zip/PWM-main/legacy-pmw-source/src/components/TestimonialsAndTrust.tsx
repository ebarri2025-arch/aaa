import React, { useState } from 'react';
import { TESTIMONIALS, FAQS, COMPANY_INFO } from '../data/pmwData';
import { Star, ShieldCheck, ChevronDown, ChevronUp, Quote, CheckCircle2 } from 'lucide-react';

export const TestimonialsAndTrust: React.FC = () => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <section id="testimonials" className="py-20 bg-slate-50 text-slate-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Trust Badges Banner */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 mb-16 flex flex-wrap items-center justify-around gap-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 font-extrabold text-xl">
              A+
            </div>
            <div>
              <div className="font-extrabold text-slate-900 text-sm">{COMPANY_INFO.bbbRating}</div>
              <div className="text-xs text-slate-500">Better Business Bureau Certified</div>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-slate-200 hidden md:block" />

          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-50 rounded-2xl text-amber-500 border border-amber-200">
              <Star className="w-6 h-6 fill-amber-400" />
            </div>
            <div>
              <div className="font-extrabold text-slate-900 text-sm">5.0 Star Charlotte Rating</div>
              <div className="text-xs text-slate-500">Based on verified homeowner reviews</div>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-slate-200 hidden md:block" />

          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-50 rounded-2xl text-blue-600 border border-blue-200">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="font-extrabold text-slate-900 text-sm">{COMPANY_INFO.licenseInfo}</div>
              <div className="text-xs text-slate-500">100% General Liability Covered</div>
            </div>
          </div>
        </div>

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100 border border-blue-200 text-blue-900 text-xs font-extrabold uppercase tracking-widest">
            <span>Verified Client Feedback</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            What Charlotte Homeowners Say About PMW
          </h2>
          <p className="text-base text-slate-600">
            Read real experiences from local residents, landlords, and property managers in South End, Ballantyne, Myers Park, and Lake Norman.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg border border-slate-200 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex gap-1 text-amber-400">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-slate-200" />
                </div>

                <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed mb-6">
                  "{t.content}"
                </p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <div className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                    <span>{t.author}</span>
                    {t.verified && <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">{t.role}</div>
                </div>
                <span className="text-[10px] text-slate-400 font-semibold">{t.date}</span>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Accordion Section */}
        <div className="max-w-4xl mx-auto bg-white rounded-3xl p-6 sm:p-10 shadow-lg border border-slate-200">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-black text-slate-900">
              Frequently Asked Questions
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Have questions before booking? Call us anytime at {COMPANY_INFO.phone}.
            </p>
          </div>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="border border-slate-200 rounded-2xl overflow-hidden transition-all"
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-5 text-left font-bold text-slate-900 flex justify-between items-center bg-slate-50/50 hover:bg-slate-100/80 text-sm sm:text-base"
                  >
                    <span>{faq.question}</span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-blue-600 shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                    )}
                  </button>

                  {isOpen && (
                    <div className="p-5 pt-2 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-white">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
