import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Phone, Calendar, Menu, X, ShieldCheck, Lock } from 'lucide-react';
import { COMPANY_INFO } from '../data/pmwData';

interface NavbarProps {
  onOpenSchedule: () => void;
  onOpenEstimator: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSchedule, onOpenEstimator }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Services', href: '/services' },
    { name: 'Instant Estimator', href: '/estimator', highlight: true }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-md border-b border-slate-200 text-slate-900 py-2.5'
          : 'bg-white/90 backdrop-blur-sm border-b border-slate-200 text-slate-900 py-3.5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo Header Link */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="bg-blue-600 p-2 rounded-xl shadow-md group-hover:scale-105 transition-transform duration-200">
              <div className="w-10 h-10 flex items-center justify-center bg-white rounded-lg text-slate-900 font-extrabold text-lg tracking-tighter shadow-inner">
                <span className="text-blue-600">P</span>MW
              </div>
            </div>
            <div>
              <div className="font-extrabold text-lg md:text-xl tracking-tight text-slate-900 flex items-center gap-2">
                PROPERTY MAINTENANCE
              </div>
              <div className="text-[10px] md:text-xs tracking-[0.2em] font-semibold text-blue-600 uppercase">
                REPAIR &bull; MAINTAIN &bull; IMPROVE
              </div>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className={`transition-colors duration-150 py-1 ${
                  link.highlight
                    ? 'text-blue-700 font-bold hover:text-blue-600 flex items-center gap-1.5 bg-blue-50 px-3 py-1.5 rounded-full border border-blue-200'
                    : 'text-slate-700 hover:text-blue-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Contact Phone & CTA */}
          <div className="hidden md:flex items-center gap-3">
            {/* Direct Phone Call */}
            <a
              href={`tel:${COMPANY_INFO.phone}`}
              className="flex items-center gap-2.5 bg-slate-100 hover:bg-slate-200 text-slate-900 px-3.5 py-2 rounded-full border border-slate-200 transition-all hover:scale-105"
              title="Call PMW Direct"
            >
              <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center">
                <Phone className="w-3.5 h-3.5" />
              </div>
              <div className="text-left">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Call Charlotte</div>
                <div className="font-extrabold text-sm text-slate-900 tracking-wide">{COMPANY_INFO.phone}</div>
              </div>
            </a>

            {/* Schedule Service CTA Button */}
            <button
              onClick={onOpenSchedule}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-5 py-2.5 rounded-full shadow-md shadow-blue-600/20 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2 text-sm"
            >
              <Calendar className="w-4 h-4" />
              <span>Schedule Service</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={`tel:${COMPANY_INFO.phone}`}
              className="p-2 bg-blue-600 rounded-full text-white shadow-md"
              aria-label="Call Property Maintenance Works"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-blue-600 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-2xl animate-in slide-in-from-top duration-200">
          <div className="flex flex-col gap-2 pt-2">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-slate-800 hover:text-blue-600 font-medium py-2 px-3 rounded-lg hover:bg-slate-100 text-base"
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-200 space-y-3">
            <a
              href={`tel:${COMPANY_INFO.phone}`}
              className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-900 py-3 rounded-xl font-bold text-center border border-slate-200"
            >
              <Phone className="w-4 h-4 text-blue-600" />
              <span>Call Now: {COMPANY_INFO.phone}</span>
            </a>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSchedule();
              }}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-xl font-bold shadow-lg text-center flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Schedule Service Online</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
