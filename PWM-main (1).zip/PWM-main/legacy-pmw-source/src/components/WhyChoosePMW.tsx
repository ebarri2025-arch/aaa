import React from 'react';
import { ShieldCheck, Award, Clock, DollarSign, HeartHandshake, MapPin, CheckCircle, Phone } from 'lucide-react';
import { COMPANY_INFO, CHARLOTTE_NEIGHBORHOODS } from '../data/pmwData';

interface WhyChoosePMWProps {
  onOpenSchedule: () => void;
}

export const WhyChoosePMW: React.FC<WhyChoosePMWProps> = ({ onOpenSchedule }) => {
  const valuePillars = [
    {
      icon: <Clock className="w-8 h-8 text-blue-600" />,
      title: "Punctual & Unmatched Reliability",
      description: "We show up on time, respect your property, and complete jobs within agreed windows. No missing contractors or endless delays."
    },
    {
      icon: <Award className="w-8 h-8 text-blue-600" />,
      title: "Master Craftsmanship",
      description: "Over 12 years of hands-on expertise across drywall, painting, trim work, plumbing fixtures, and outdoor deck upgrades in Charlotte."
    },
    {
      icon: <DollarSign className="w-8 h-8 text-blue-600" />,
      title: "100% Transparent Upfront Pricing",
      description: "No hidden fees, surprise add-ons, or vague quotes. What you see on our instant estimate calculator is what we stand behind."
    },
    {
      icon: <ShieldCheck className="w-8 h-8 text-blue-600" />,
      title: "Charlotte Satisfaction Guarantee",
      description: "Every repair, maintenance visit, and improvement project is backed by our full workmanship warranty. Your peace of mind comes first."
    }
  ];

  return (
    <section id="why-us" className="py-20 bg-white text-slate-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-6 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-slate-900 text-xs font-extrabold uppercase tracking-widest">
              <HeartHandshake className="w-4 h-4 text-blue-600" />
              <span>The PMW Advantage</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900">
              Why Charlotte Property Owners Choose PMW
            </h2>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
              Founded on a simple promise: deliver honest, top-tier craftsmanship that keeps your property safe, functional, and visually stunning.
            </p>

            {/* Philosophy Pill */}
            <div className="p-4 bg-white text-slate-900 border border-slate-200 rounded-2xl flex flex-wrap items-center justify-around text-center gap-4 shadow-md">
              <div>
                <div className="text-blue-600 font-extrabold text-lg">REPAIR</div>
                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Fast Defect Fixes</div>
              </div>
              <div className="text-slate-300 text-2xl font-light">/</div>
              <div>
                <div className="text-blue-800 font-extrabold text-lg">MAINTAIN</div>
                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Preventative Care</div>
              </div>
              <div className="text-slate-300 text-2xl font-light">/</div>
              <div>
                <div className="text-sky-600 font-extrabold text-lg">IMPROVE</div>
                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Value-Add Upgrades</div>
              </div>
            </div>
          </div>

          {/* Hugo / PMW Guarantee Badge Card */}
          <div className="lg:col-span-6 bg-gradient-to-br from-blue-50 via-white to-sky-50 text-slate-900 p-8 rounded-3xl shadow-xl relative overflow-hidden border border-blue-200">
            <div className="relative z-10 space-y-4">
              <div className="inline-block px-3 py-1 bg-blue-100 border border-blue-200 rounded-lg text-xs font-bold text-blue-800">
                Direct Owner Commitment
              </div>

              <blockquote className="text-lg sm:text-xl font-medium text-slate-700 italic leading-relaxed">
                "Whether you own a single family home in South End or manage 30 rental doors across Charlotte, you deserve a contractor who communicates clearly, respects your budget, and gets the job done right the first time."
              </blockquote>

              <div className="pt-2 flex items-center justify-between border-t border-blue-100">
                <div>
                  <div className="font-extrabold text-slate-900 text-base">Hugo & The PMW Master Team</div>
                  <div className="text-xs text-blue-700 font-semibold">Lead Contractor & Owner, Property Maintenance Works</div>
                </div>

                <a
                  href={`tel:${COMPANY_INFO.phone}`}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-sm"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>980-308-1727</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Value Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {valuePillars.map((pillar, index) => (
            <div
              key={index}
              className="bg-slate-50 rounded-2xl p-6 border border-slate-200/80 hover:bg-white hover:shadow-xl transition-all duration-300 group"
            >
              <div className="p-3 bg-white rounded-xl w-fit shadow-sm border border-slate-200 mb-4 group-hover:scale-110 transition-transform">
                {pillar.icon}
              </div>
              <h3 className="text-lg font-black text-slate-900 mb-2">
                {pillar.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {pillar.description}
              </p>
            </div>
          ))}
        </div>

        {/* Service Radius & Charlotte Map Highlights */}
        <div className="bg-slate-50 text-slate-900 rounded-3xl p-8 sm:p-10 shadow-xl border border-slate-200 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-widest">
                <MapPin className="w-4 h-4" />
                <span>Charlotte Service Area</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
                Prompt Local Service Across Greater Charlotte, NC
              </h3>

              <p className="text-sm text-slate-600 leading-relaxed">
                Our technicians are dispatched daily throughout Mecklenburg and surrounding counties. Enjoy rapid response times and zero travel surcharges within our core zone.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2">
                {CHARLOTTE_NEIGHBORHOODS.map((area) => (
                  <div key={area} className="flex items-center gap-2 text-xs text-slate-800 font-semibold bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-2xs">
                    <CheckCircle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{area}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-4 shadow-md">
              <div className="text-lg font-black text-slate-900">Need Same-Day or Emergency Repairs?</div>
              <p className="text-xs text-slate-600">
                Water leak containment, door lock failures, or urgent rental tenant turn-around.
              </p>

              <a
                href={`tel:${COMPANY_INFO.phone}`}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-extrabold py-3.5 px-6 rounded-xl shadow-md flex items-center justify-center gap-2 text-sm inline-flex"
              >
                <Phone className="w-4 h-4" />
                <span>Emergency Hotline: {COMPANY_INFO.phone}</span>
              </a>

              <button
                onClick={onOpenSchedule}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-4 rounded-xl text-xs transition-colors border border-slate-200"
              >
                Book Regular Service Onsite
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
