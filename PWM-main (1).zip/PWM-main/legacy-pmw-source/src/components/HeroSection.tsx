import React from 'react';
import { Phone, Calculator, ShieldCheck, Sparkles, CheckCircle, ArrowRight, Clock, Star } from 'lucide-react';
import { COMPANY_INFO, CHARLOTTE_NEIGHBORHOODS } from '../data/pmwData';
import { Logo } from './Logo';

interface HeroSectionProps {
  onOpenEstimator: () => void;
  onOpenSchedule: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenEstimator,
  onOpenSchedule,
}) => {
  return (
    <section className="relative pt-28 pb-16 md:pt-36 md:pb-24 bg-gradient-to-b from-blue-50/70 via-white to-slate-50 overflow-hidden text-slate-900 border-b border-slate-200">
      {/* Background ambient lighting and subtle radial mesh */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-100/40 via-white to-transparent pointer-events-none" />
      <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-400/10 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Headlines & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/90 border border-blue-200 text-blue-900 text-xs sm:text-sm font-bold tracking-wide shadow-sm">
              <span className="flex h-2 w-2 rounded-full bg-blue-600 animate-ping" />
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              <span>Licensed & Insured Charlotte Property Specialist</span>
            </div>

            {/* Main Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.1]">
              Your Charlotte Property, <span className="text-blue-600">Perfected.</span>
            </h1>

            {/* Subhead with Tagline */}
            <p className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed max-w-2xl">
              Reliable maintenance, expert handyman repairs, and custom improvements for Charlotte homeowners and property managers.
            </p>

            {/* Core Tagline Pill */}
            <div className="inline-flex items-center gap-3 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-800 shadow-sm">
              <span className="text-blue-600 font-extrabold uppercase tracking-widest">REPAIR</span>
              <span className="text-slate-300 font-normal">|</span>
              <span className="text-blue-800 font-extrabold uppercase tracking-widest">MAINTAIN</span>
              <span className="text-slate-300 font-normal">|</span>
              <span className="text-sky-600 font-extrabold uppercase tracking-widest">IMPROVE</span>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                onClick={onOpenEstimator}
                className="bg-blue-600 hover:bg-blue-500 text-white font-extrabold px-8 py-4 rounded-2xl shadow-xl shadow-blue-600/25 transition-all transform hover:-translate-y-1 active:translate-y-0 flex items-center justify-center gap-3 text-base sm:text-lg group"
              >
                <Calculator className="w-5 h-5 text-blue-100 group-hover:rotate-12 transition-transform" />
                <span>GET YOUR INSTANT ESTIMATE</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href={`tel:${COMPANY_INFO.phone}`}
                className="bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold px-7 py-4 rounded-2xl border border-slate-300 hover:border-slate-400 transition-all flex items-center justify-center gap-3 text-base"
              >
                <Phone className="w-5 h-5 text-blue-600" />
                <span>Call {COMPANY_INFO.phone}</span>
              </a>
            </div>

            {/* Quick Benefits Bullet List */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-200">
              <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-700 font-semibold">
                <CheckCircle className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Upfront transparent quotes</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-700 font-semibold">
                <CheckCircle className="w-4 h-4 text-blue-600 shrink-0" />
                <span>24-48hr turnaround</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-700 font-semibold">
                <CheckCircle className="w-4 h-4 text-blue-600 shrink-0" />
                <span>100% Workmanship warranty</span>
              </div>
            </div>

            {/* Service Area Tags */}
            <div className="pt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span className="font-bold text-slate-700">Serving Charlotte Metro:</span>
              {CHARLOTTE_NEIGHBORHOODS.slice(0, 6).map((neighborhood) => (
                <span
                  key={neighborhood}
                  className="bg-white border border-slate-200 px-2.5 py-1 rounded-md text-slate-700 shadow-xs font-medium"
                >
                  {neighborhood}
                </span>
              ))}
              <span className="text-blue-600 font-extrabold">+ more</span>
            </div>

          </div>

          {/* Right Column: Visual Logo & Direct Booking Card */}
          <div className="lg:col-span-5">
            <div className="relative">
              {/* Outer subtle halo shadow */}
              <div className="absolute -inset-1 bg-blue-200/50 rounded-3xl blur-xl opacity-60" />

              <div className="relative bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5">
                
                {/* Official Brand Logo Box */}
                <div className="bg-slate-50/80 rounded-2xl p-5 shadow-inner text-slate-900 border border-slate-200 flex items-center justify-center">
                  <Logo variant="full" showPhone={true} className="w-full max-w-[280px]" />
                </div>

                {/* Direct Request Callout */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="text-xs font-bold text-slate-700">Fast Response Guarantee</span>
                    </div>
                    <div className="flex items-center gap-1 text-amber-500 text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>5.0 Charlotte Rating</span>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Need handyman repairs, painting, or preventative maintenance? Schedule a quick inspection or calculate your quote instantly.
                  </p>

                  <div className="space-y-2.5 pt-1">
                    <button
                      onClick={onOpenSchedule}
                      className="w-full bg-blue-600 hover:bg-blue-500 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm"
                    >
                      <span>Book Free Onsite Inspection</span>
                    </button>

                    <a
                      href={`tel:${COMPANY_INFO.phone}`}
                      className="w-full bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold py-3 px-4 rounded-xl border border-slate-300 transition-all flex items-center justify-center gap-2 text-xs sm:text-sm"
                    >
                      <Phone className="w-4 h-4 text-blue-600" />
                      <span>Direct Line: {COMPANY_INFO.phone}</span>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
