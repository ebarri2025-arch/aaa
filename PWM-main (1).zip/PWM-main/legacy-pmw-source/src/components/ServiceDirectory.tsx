import React, { useState } from 'react';
import { Hammer, Paintbrush, Wrench, Plus, Check, Info, Sparkles, ArrowRight } from 'lucide-react';
import { SERVICE_CATEGORIES, ALL_SERVICES, COMPANY_INFO } from '../data/pmwData';
import { ServiceItem, ServiceCategoryKey } from '../types';

interface ServiceDirectoryProps {
  selectedServiceIds: string[];
  onToggleService: (serviceId: string) => void;
  onOpenEstimator: () => void;
  onOpenSchedule: () => void;
}

export const ServiceDirectory: React.FC<ServiceDirectoryProps> = ({
  selectedServiceIds,
  onToggleService,
  onOpenEstimator,
  onOpenSchedule,
}) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [selectedDetailService, setSelectedDetailService] = useState<ServiceItem | null>(null);

  const getCategoryIcon = (iconName: string, color: string) => {
    switch (iconName) {
      case 'Hammer':
        return <Hammer className="w-6 h-6" style={{ color }} />;
      case 'Paintbrush':
        return <Paintbrush className="w-6 h-6" style={{ color }} />;
      case 'Wrench':
        return <Wrench className="w-6 h-6" style={{ color }} />;
      case 'Screwdriver':
        return <Wrench className="w-6 h-6" style={{ color }} />;
      default:
        return <Wrench className="w-6 h-6 text-blue-600" />;
    }
  };

  const categories = Object.values(SERVICE_CATEGORIES);

  const filteredServices = activeCategoryFilter === 'all'
    ? ALL_SERVICES
    : ALL_SERVICES.filter(s => s.category === activeCategoryFilter);

  return (
    <section id="services" className="py-20 bg-slate-50 text-slate-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-900 text-xs font-extrabold uppercase tracking-widest">
            <span>Property Care Menu</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Complete Property Services Directory
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Organized around our core disciplines: <strong className="text-slate-900">Repair, Maintain, and Improve</strong>. Select any service to add it directly to your instant cost calculator.
          </p>
        </div>

        {/* Category Navigation Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-12">
          <button
            onClick={() => setActiveCategoryFilter('all')}
            className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all shadow-sm ${
              activeCategoryFilter === 'all'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            All Services ({ALL_SERVICES.length})
          </button>

          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setActiveCategoryFilter(cat.key)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all shadow-sm ${
                activeCategoryFilter === cat.key
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {getCategoryIcon(cat.iconName, activeCategoryFilter === cat.key ? '#FFFFFF' : cat.color)}
              <span>{cat.title}</span>
            </button>
          ))}
        </div>

        {/* 4 Core Category Overview Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {categories.map((cat) => {
            const itemsInCat = ALL_SERVICES.filter(s => s.category === cat.key);
            return (
              <div
                key={cat.key}
                className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl border border-slate-200 transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Category Header Icon */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3.5 rounded-xl bg-slate-100 border border-slate-200 group-hover:scale-110 transition-transform">
                      {getCategoryIcon(cat.iconName, cat.color)}
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-slate-100 text-slate-600">
                      {itemsInCat.length} Scopes
                    </span>
                  </div>

                  <h3 className="text-xl font-extrabold text-slate-900 mb-2">
                    {cat.title}
                  </h3>
                  <p className="text-xs font-semibold text-blue-600 mb-3 uppercase tracking-wider">
                    {cat.tagline}
                  </p>
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">
                    {cat.description}
                  </p>

                  {/* Sample Service Scopes Bullets */}
                  <div className="space-y-2 border-t border-slate-100 pt-3 mb-4">
                    {itemsInCat.map((item) => (
                      <div key={item.id} className="flex items-center justify-between text-xs text-slate-700">
                        <span className="font-medium text-slate-800">{item.name}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setActiveCategoryFilter(cat.key)}
                  className="w-full mt-2 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <span>Explore {cat.title}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Detailed Services Listing Cards with "Add to Estimator" interactive selection */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 md:p-10 shadow-lg border border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-8 border-b border-slate-200">
            <div>
              <h3 className="text-2xl font-extrabold text-slate-900">
                {activeCategoryFilter === 'all'
                  ? 'Selected Property Service Scopes'
                  : SERVICE_CATEGORIES[activeCategoryFilter]?.title}
              </h3>
              <p className="text-sm text-slate-600">
                Click <strong className="text-blue-600">+ Add to Estimator</strong> to stack items into your instant quote.
              </p>
            </div>

            {selectedServiceIds.length > 0 && (
              <button
                onClick={onOpenEstimator}
                className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-md flex items-center gap-2 animate-bounce"
              >
                <span>Calculate Quote ({selectedServiceIds.length} Selected)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => {
              const isSelected = selectedServiceIds.includes(service.id);
              const catInfo = SERVICE_CATEGORIES[service.category];

              return (
                <div
                  key={service.id}
                  className={`rounded-2xl p-5 border transition-all duration-200 flex flex-col justify-between ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 shadow-md ring-2 ring-blue-500/20'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-md'
                  }`}
                >
                  <div>
                    {/* Top Row */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700">
                        {catInfo?.title}
                      </span>
                      {service.popular && (
                        <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-amber-600" />
                          Popular
                        </span>
                      )}
                    </div>

                    <h4 className="font-extrabold text-slate-900 text-lg mb-1.5 leading-snug">
                      {service.name}
                    </h4>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-4">
                      {service.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="text-xs text-slate-500 font-semibold">Pricing varies</div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedDetailService(service)}
                        className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                        title="View scope details"
                      >
                        <Info className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onToggleService(service.id)}
                        className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-blue-600 text-white shadow-sm'
                            : 'bg-slate-900 hover:bg-slate-800 text-white'
                        }`}
                      >
                        {isSelected ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Detail Modal for a specific service */}
      {selectedDetailService && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                  {SERVICE_CATEGORIES[selectedDetailService.category]?.title}
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">
                  {selectedDetailService.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedDetailService(null)}
                className="p-2 rounded-full hover:bg-slate-100 text-slate-500"
              >
                ✕
              </button>
            </div>

            <p className="text-sm text-slate-700 leading-relaxed">
              {selectedDetailService.description}
            </p>

            <div className="bg-slate-50 p-4 rounded-2xl space-y-2 border border-slate-200 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Typical Pricing:</span>
                <span className="font-bold text-slate-900">${selectedDetailService.basePrice} ({selectedDetailService.unitLabel})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Est. Time on Site:</span>
                <span className="font-bold text-slate-900">~{selectedDetailService.estimatedHours} Hours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Service Coverage:</span>
                <span className="font-bold text-slate-900">Charlotte NC Metro Area</span>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  onToggleService(selectedDetailService.id);
                  setSelectedDetailService(null);
                }}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl text-sm"
              >
                {selectedServiceIds.includes(selectedDetailService.id) ? 'Remove from Quote' : 'Add to Estimate Calculator'}
              </button>
              <button
                onClick={() => {
                  setSelectedDetailService(null);
                  onOpenSchedule();
                }}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-3 rounded-xl text-sm"
              >
                Book Directly
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
