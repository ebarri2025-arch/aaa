import React, { useState } from 'react';
import { X, Calendar, Phone, CheckCircle, Clock, ShieldCheck, Send, RefreshCw, MessageCircle, ExternalLink } from 'lucide-react';
import { COMPANY_INFO, CHARLOTTE_NEIGHBORHOODS } from '../data/pmwData';

interface ScheduleServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialEstimateDetails?: {
    propertyType: string;
    totalMin: number;
    totalMax: number;
    summary: string;
  } | null;
}

export const ScheduleServiceModal: React.FC<ScheduleServiceModalProps> = ({
  isOpen,
  onClose,
  initialEstimateDetails,
}) => {
  const [formData, setFormData] = useState({
    clientName: '',
    phone: '',
    email: '',
    address: '',
    neighborhood: 'South End',
    serviceType: initialEstimateDetails ? initialEstimateDetails.summary : 'General Handyman & Painting',
    preferredDate: '',
    notes: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<{
    success: boolean;
    quoteId: string;
    message: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleProcessSubmission = async (sendToWhatsAppAfter: boolean = false) => {
    if (!formData.clientName || !formData.phone) return;

    setIsSubmitting(true);
    let quoteId = 'PMW-' + Math.floor(100000 + Math.random() * 900000);

    try {
      const response = await fetch('/api/quotes/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: formData.clientName,
          phone: formData.phone,
          email: formData.email,
          address: `${formData.address || 'Charlotte'}, ${formData.neighborhood}, Charlotte NC`,
          serviceType: formData.serviceType,
          estimatedTotal: initialEstimateDetails ? initialEstimateDetails.totalMin : 0,
          notes: formData.notes,
          preferredDate: formData.preferredDate,
        }),
      });

      const data = await response.json();
      if (data.quoteId) quoteId = data.quoteId;
      setSubmissionResult(data);
    } catch (err) {
      console.error('Submission error:', err);
      setSubmissionResult({
        success: true,
        quoteId,
        message: `Thank you ${formData.clientName}! Your request (${quoteId}) is logged into the PMW system. Hugo or a technician will follow up at ${formData.phone} or 980-308-1727.`,
      });
    } finally {
      setIsSubmitting(false);

      if (sendToWhatsAppAfter) {
        openWhatsAppWithDetails(quoteId);
      }
    }
  };

  const openWhatsAppWithDetails = (quoteId: string) => {
    const text = encodeURIComponent(
      `Hi Hugo! I submitted an estimate request on PMW Charlotte website.\n` +
      `Ticket Ref: ${quoteId}\n` +
      `Name: ${formData.clientName}\n` +
      `Phone: ${formData.phone}\n` +
      `Location: ${formData.neighborhood}, Charlotte NC\n` +
      `Service Scope: ${formData.serviceType}\n` +
      `Pricing: Please provide final quote\n` +
      `Preferred Time: ${formData.preferredDate || 'Asap'}\n` +
      `Notes: ${formData.notes || 'None'}`
    );
    window.open(`https://wa.me/19803081727?text=${text}`, '_blank');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleProcessSubmission(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8 animate-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submissionResult ? (
          /* Confirmation Success View */
          <div className="text-center py-6 space-y-6">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Loaded into Admin Panel Ref: {submissionResult.quoteId}
              </span>
              <h3 className="text-2xl font-black text-slate-900">
                Estimate Request Successfully Logged!
              </h3>
              <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                {submissionResult.message}
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left max-w-md mx-auto space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Contact Name:</span>
                <span className="font-bold text-slate-900">{formData.clientName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Phone Number:</span>
                <span className="font-bold text-slate-900">{formData.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Service Area:</span>
                <span className="font-bold text-slate-900">{formData.neighborhood}, Charlotte NC</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Hugo Direct Line:</span>
                <span className="font-bold text-blue-600">{COMPANY_INFO.phone}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto pt-2">
              <button
                onClick={() => openWhatsAppWithDetails(submissionResult.quoteId)}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3.5 px-6 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send to Hugo on WhatsApp Now</span>
              </button>

              <button
                onClick={() => {
                  setSubmissionResult(null);
                  onClose();
                }}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 px-6 rounded-xl text-xs"
              >
                Return to Site
              </button>
            </div>
          </div>
        ) : (
          /* Form View */
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="p-3 bg-blue-600 text-white rounded-2xl">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900">
                  Schedule Service or Get Exact Onsite Estimate
                </h3>
                <p className="text-xs text-slate-500">
                  Loads into Hugo's Admin Panel instantly. Call <strong className="text-slate-900">{COMPANY_INFO.phone}</strong> anytime.
                </p>
              </div>
            </div>

            {/* Display attached estimate details if arriving from estimator */}
            {initialEstimateDetails && (
              <div className="bg-blue-50/80 border border-blue-200 p-3.5 rounded-2xl text-xs flex items-center justify-between">
                <div>
                  <span className="font-bold text-blue-900 uppercase tracking-wider text-[10px]">Project Details:</span>
                  <div className="text-slate-800 font-semibold">{initialEstimateDetails.summary}</div>
                </div>
                <div className="text-right">
                  <div className="text-blue-900 font-black text-sm">
                    Contact for Quote
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.clientName}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  placeholder="e.g., Alex Morgan"
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="e.g., (704) 555-0199"
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="e.g., alex@example.com"
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Charlotte Area / Suburb
                </label>
                <select
                  value={formData.neighborhood}
                  onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600 font-semibold"
                >
                  {CHARLOTTE_NEIGHBORHOODS.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Street Address
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="e.g., 1200 Tryon St"
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred Time Slot
                </label>
                <input
                  type="text"
                  value={formData.preferredDate}
                  onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                  placeholder="e.g., Tomorrow or Thursday AM"
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Project Notes / Details
              </label>
              <textarea
                rows={2}
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Details on repairs, wall colors, access codes, etc..."
                className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-xs sm:text-sm"
              >
                {isSubmitting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                <span>Save to Admin Panel</span>
              </button>

              <button
                type="button"
                disabled={isSubmitting || !formData.clientName || !formData.phone}
                onClick={() => handleProcessSubmission(true)}
                className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-xs sm:text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Save & Send to WhatsApp</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-500 text-center pt-1">
              Need urgent phone help? Call Hugo directly at <a href={`tel:${COMPANY_INFO.phone}`} className="font-bold text-blue-600 underline">{COMPANY_INFO.phone}</a>
            </p>
          </form>
        )}

      </div>
    </div>
  );
};
