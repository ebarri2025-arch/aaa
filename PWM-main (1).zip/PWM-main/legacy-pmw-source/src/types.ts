export type ServiceCategoryKey = 'handyman' | 'painting' | 'preventative' | 'improvements';

export interface ServiceItem {
  id: string;
  name: string;
  category: ServiceCategoryKey;
  description: string;
  basePrice: number; // base estimate or per sqft / per hour
  unitLabel: string; // e.g. "per patch", "per 100 sq ft", "per job", "per hour"
  estimatedHours: number;
  popular?: boolean;
}

export interface CategoryInfo {
  key: ServiceCategoryKey;
  title: string;
  tagline: string;
  iconName: string;
  description: string;
  color: string;
  accentBg: string;
}

export interface AIAnalysisResult {
  summary: string;
  complexity: string;
  primaryCategory: string;
  recommendedServices: {
    name: string;
    estimatedHours: number;
    category: string;
  }[];
  estimatedCostRange: {
    min: number;
    max: number;
  };
  turnaroundDays: string;
  expertTips: string;
}

export interface ProjectShowcaseItem {
  id: string;
  title: string;
  location: string;
  category: ServiceCategoryKey;
  beforeImage: string;
  afterImage: string;
  description: string;
  duration: string;
  highlight: string;
}

export interface Testimonial {
  id: string;
  author: string;
  role: string; // e.g. "Homeowner in South End", "Property Manager at Queen City Rentals"
  rating: number;
  content: string;
  date: string;
  verified: boolean;
}

export interface QuoteRequestForm {
  clientName: string;
  phone: string;
  email: string;
  address: string;
  propertyType: string;
  serviceType: string;
  selectedServices: string[];
  squareFootage: number;
  urgency: 'standard' | 'priority' | 'emergency';
  notes: string;
  preferredDate: string;
  estimatedTotalMin: number;
  estimatedTotalMax: number;
}
