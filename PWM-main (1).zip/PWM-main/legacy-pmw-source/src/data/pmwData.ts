import { CategoryInfo, ServiceItem, ProjectShowcaseItem, Testimonial } from '../types';

export const COMPANY_INFO = {
  name: "Property Maintenance Works",
  shortName: "PMW",
  tagline: "REPAIR | MAINTAIN | IMPROVE",
  phone: "980-308-1727",
  formattedPhone: "(980) 308-1727",
  email: "service@propertymaintenanceworks.com",
  serviceArea: "Greater Charlotte Metro Area, NC",
  hours: "Mon - Sat: 7:00 AM - 7:00 PM | 24/7 Emergency Response Available",
  bbbRating: "A+ Accredited Business",
  licenseInfo: "Licensed & Fully Insured NC General Contracting & Repairs",
  yearsInBusiness: "12+ Years serving Charlotte",
  guaranteeText: "100% Workmanship & Price Integrity Guarantee"
};

export const CHARLOTTE_NEIGHBORHOODS = [
  "South End",
  "Myers Park",
  "Ballantyne",
  "Dilworth",
  "NoDa",
  "Plaza Midwood",
  "Lake Norman",
  "Huntersville",
  "Matthews",
  "Pineville",
  "Concord",
  "Fort Mill, SC"
];

export const SERVICE_CATEGORIES: Record<string, CategoryInfo> = {
  handyman: {
    key: 'handyman',
    title: "Handyman & Repair",
    tagline: "Fixing everyday wear, damages & functional issues fast",
    iconName: "Hammer",
    description: "From drywall patches to door alignments and fixture repairs, our skilled handymen resolve property defects quickly and reliably.",
    color: "#0F294A", // Navy Blue from logo
    accentBg: "bg-slate-50 border-slate-200"
  },
  painting: {
    key: 'painting',
    title: "Painting & Finishing",
    tagline: "Interior & exterior precision coating and surface restoration",
    iconName: "Paintbrush",
    description: "Flawless wall prep, cabinet refinishing, deck staining, and exterior painting with premium weather-resistant finishes.",
    color: "#2563EB", // Royal Blue from logo
    accentBg: "bg-blue-50/50 border-blue-100"
  },
  preventative: {
    key: 'preventative',
    title: "Preventative Maintenance",
    tagline: "Proactive care to protect your property's value and prevent costly damages",
    iconName: "Wrench",
    description: "Gutter cleaning, HVAC filter checks, weatherproofing, and seasonal checklists tailored for homeowners and rental property managers.",
    color: "#0A2540",
    accentBg: "bg-slate-50 border-slate-200"
  },
  improvements: {
    key: 'improvements',
    title: "Property Improvements",
    tagline: "Upgrades, remodeling refreshes, and value-adding enhancements",
    iconName: "Screwdriver",
    description: "Kitchen and bath updates, deck build/repairs, custom trim, flooring installation, and modern fixture upgrades.",
    color: "#1E40AF",
    accentBg: "bg-blue-50/50 border-blue-100"
  }
};

export const ALL_SERVICES: ServiceItem[] = [
  // Handyman & Repair
  {
    id: "hm-1",
    name: "Drywall Repair & Hole Patching",
    category: "handyman",
    description: "Seamless repair of doorknob holes, drywall cracks, water spots, sanding, primer & smooth texture matching.",
    basePrice: 165,
    unitLabel: "per patch / spot",
    estimatedHours: 2,
    popular: true
  },
  {
    id: "hm-2",
    name: "Door & Window Hardware Alignment",
    category: "handyman",
    description: "Align sticking doors, replace deadbolts, adjust latches, weatherstripping, and repair window sashes.",
    basePrice: 135,
    unitLabel: "per door / window",
    estimatedHours: 1.5
  },
  {
    id: "hm-3",
    name: "Trim, Baseboard & Crown Molding Repair",
    category: "handyman",
    description: "Replace or caulk damaged shoe molding, baseboards, door casings, and decorative trim.",
    basePrice: 195,
    unitLabel: "per room",
    estimatedHours: 2.5
  },
  {
    id: "hm-4",
    name: "TV Wall Mounting & Hidden Cable Run",
    category: "handyman",
    description: "Heavy-duty TV mounting on stud/brick with in-wall wire concealment and outlet power kit.",
    basePrice: 185,
    unitLabel: "per TV setup",
    estimatedHours: 1.5,
    popular: true
  },
  {
    id: "hm-5",
    name: "Plumbing & Electrical Fixture Replacement",
    category: "handyman",
    description: "Safe swap of kitchen/bath faucets, garbage disposals, ceiling fans, vanity lights, and GFCI outlets.",
    basePrice: 195,
    unitLabel: "per fixture",
    estimatedHours: 1.5,
    popular: true
  },

  // Painting & Finishing
  {
    id: "pnt-1",
    name: "Interior Room Wall Painting",
    category: "painting",
    description: "Full wall prep, hole filling, sanding, primer, and two coats of premium Sherwin-Williams Duration paint.",
    basePrice: 480,
    unitLabel: "per standard room (12x12)",
    estimatedHours: 4,
    popular: true
  },
  {
    id: "pnt-2",
    name: "Deck & Fence Staining or Sealing",
    category: "painting",
    description: "High-pressure wash, wood conditioner, nail reset, and commercial-grade translucent oil stain application.",
    basePrice: 580,
    unitLabel: "per 200 sq ft deck",
    estimatedHours: 5,
    popular: true
  },
  {
    id: "pnt-3",
    name: "Cabinet Refinishing & Factory Spraying",
    category: "painting",
    description: "Full kitchen cabinet transformation with primer, factory-smooth lacquer spraying, and new hardware install.",
    basePrice: 2200,
    unitLabel: "per average kitchen set",
    estimatedHours: 18
  },
  {
    id: "pnt-4",
    name: "Exterior Siding, Trim & Fascia Touch-Up",
    category: "painting",
    description: "Scrape loose paint, spot caulk, prime wood, and paint eaves, shutters, window trim, or siding sections.",
    basePrice: 420,
    unitLabel: "per section / facade",
    estimatedHours: 3.5
  },
  {
    id: "pnt-5",
    name: "Pressure Washing (Driveways, Patios, Siding)",
    category: "painting",
    description: "Soft-wash house siding and high-pressure cleaning for concrete driveways, walkways, and patios.",
    basePrice: 280,
    unitLabel: "per driveway / house side",
    estimatedHours: 2.5
  },

  // Preventative Maintenance
  {
    id: "prev-1",
    name: "Gutter Cleaning & Downspout Flushing",
    category: "preventative",
    description: "Remove organic debris, clear downspout blockages, inspect fascia brackets, and test drainage flow.",
    basePrice: 195,
    unitLabel: "per 1,500 - 2,500 sq ft home",
    estimatedHours: 2,
    popular: true
  },
  {
    id: "prev-2",
    name: "Heavy-Duty Micro-Mesh Gutter Guards",
    category: "preventative",
    description: "Supply and install stainless steel micro-mesh guards to keep leaves and pine needles out permanently.",
    basePrice: 650,
    unitLabel: "per 100 linear ft",
    estimatedHours: 4
  },
  {
    id: "prev-3",
    name: "Seasonal Maintenance Tune-Up Inspection",
    category: "preventative",
    description: "30-point Charlotte property inspection: HVAC filters, smoke detectors, exterior caulking, hose bib frost prep.",
    basePrice: 240,
    unitLabel: "per full inspection visit",
    estimatedHours: 2.5,
    popular: true
  },
  {
    id: "prev-4",
    name: "Dryer Vent Cleaning & Safety Audit",
    category: "preventative",
    description: "Rotary brush lint removal through entire exhaust duct to eliminate fire hazard and improve energy efficiency.",
    basePrice: 165,
    unitLabel: "per dryer duct run",
    estimatedHours: 1.5
  },

  // Property Improvements
  {
    id: "imp-1",
    name: "Luxury Vinyl Plank (LVP) Flooring",
    category: "improvements",
    description: "Floor prep, underlayment, precision click-lock LVP laying, transition strips, and quarter-round trim.",
    basePrice: 4.85, // per sq ft
    unitLabel: "per sq ft (labor + prep)",
    estimatedHours: 8,
    popular: true
  },
  {
    id: "imp-2",
    name: "Bathroom Refresh & Vanity Swap",
    category: "improvements",
    description: "Demo old vanity, install new plumbing supply & drain lines, set new vanity top, mirror, and modern lighting.",
    basePrice: 750,
    unitLabel: "per bathroom refresh",
    estimatedHours: 6,
    popular: true
  },
  {
    id: "imp-3",
    name: "Deck Board Replacement & Railings",
    category: "improvements",
    description: "Replace rotted deck boards, reinforce joist framing, fix stairs, and install sturdy composite/wood railings.",
    basePrice: 680,
    unitLabel: "per section repair",
    estimatedHours: 5
  },
  {
    id: "imp-4",
    name: "Custom Shelving & Closet Systems",
    category: "improvements",
    description: "Custom wood closet organization, pantry shelving, garage storage systems, and heavy-duty racks.",
    basePrice: 450,
    unitLabel: "per closet system",
    estimatedHours: 4
  }
];

export const PROJECT_SHOWCASE: ProjectShowcaseItem[] = [
  {
    id: "proj-1",
    title: "Full Interior Paint & Drywall Refresh",
    location: "South End, Charlotte",
    category: "painting",
    beforeImage: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80",
    description: "Repaired 14 wall punctures and applied two coats of crisp Sherwin-Williams Alabaster white across a 2,200 sq ft townhouse before tenant turnover.",
    duration: "2 Days",
    highlight: "Repaired & Painted in 48 Hours"
  },
  {
    id: "proj-2",
    title: "Deck Restoration & Custom Railings",
    location: "Ballantyne, Charlotte",
    category: "improvements",
    beforeImage: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1595877244568-8318f2843a99?auto=format&fit=crop&w=800&q=80",
    description: "Replaced weathered deck planks, power washed, applied cedar oil-based stain, and installed heavy-duty aluminum spindle railings.",
    duration: "3 Days",
    highlight: "Complete Outdoor Living Refresh"
  },
  {
    id: "proj-3",
    title: "Preventative Gutter & Exterior Weatherproofing",
    location: "Lake Norman, NC",
    category: "preventative",
    beforeImage: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80",
    description: "Cleared clogged multi-story gutters, re-hung sagging brackets, flushed downspouts, and installed stainless steel micro-mesh guards.",
    duration: "1 Day",
    highlight: "Water Proofing Defense"
  },
  {
    id: "proj-4",
    title: "Rental Property Turnkey Repairs & Fixtures",
    location: "Myers Park, Charlotte",
    category: "handyman",
    beforeImage: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80",
    afterImage: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=800&q=80",
    description: "Replaced 3 sticking interior doors, swapped vanity light fixtures, fixed kitchen cabinet hinges, and mounted 65-inch television above fireplace.",
    duration: "1.5 Days",
    highlight: "Turnkey Property Handyman"
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    author: "Marcus & Sarah L.",
    role: "Homeowners in South End",
    rating: 5,
    content: "Hugo and the PMW team were fantastic! They fixed several drywall holes left by our previous movers and repainted our entire main floor in just two days. Clean, punctual, and exact pricing with no surprises.",
    date: "July 2026",
    verified: true
  },
  {
    id: "t2",
    author: "David Vance",
    role: "Property Manager at Queen City Holdings",
    rating: 5,
    content: "As a rental property manager with 25+ doors across Charlotte, having PMW on speed dial (980-308-1727) is a game changer. Their instant online calculator is spot on and their turn-around time between tenants is unbeatable.",
    date: "June 2026",
    verified: true
  },
  {
    id: "t3",
    author: "Elena Rostova",
    role: "Homeowner in Ballantyne",
    rating: 5,
    content: "Our back deck was looking old and unsafe. PMW replaced the damaged boards, power-washed, and stained it to look brand new. The quote was transparent and the craftsmanship exceeded our expectations!",
    date: "May 2026",
    verified: true
  },
  {
    id: "t4",
    author: "Robert Chen",
    role: "HOA President, Lake Norman",
    rating: 5,
    content: "We hired Property Maintenance Works for gutter cleaning and seasonal preventative care across 12 unit buildings. Thorough work, excellent communication, and total professionalism.",
    date: "April 2026",
    verified: true
  }
];

export const FAQS = [
  {
    question: "How does the Instant Estimate Calculator work?",
    answer: "Select your property type, choose the specific service items or square footage, and choose your timeline. The calculator uses regional Charlotte labor rates and material costs to generate an immediate cost range. You can also type your project details into our AI Project Analyzer for a custom breakdown!"
  },
  {
    question: "Are you licensed and insured in North Carolina?",
    answer: "Yes, 100%! Property Maintenance Works is fully licensed, general liability insured, and worker's comp covered in North Carolina for all repair, maintenance, and improvement services."
  },
  {
    question: "How quickly can a technician come out to my property?",
    answer: "We offer standard scheduling within 3-5 days, as well as priority 24-48 hour turnover response for rental property managers and emergency repairs. Call us directly at 980-308-1727 for immediate dispatch."
  },
  {
    question: "Do you serve both residential homes and commercial or rental properties?",
    answer: "Yes. We work extensively with individual homeowners, rental property management firms, Airbnb hosts, real estate agents pre-listing homes, and commercial offices throughout Greater Charlotte."
  }
];
