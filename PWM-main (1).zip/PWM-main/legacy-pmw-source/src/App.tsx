import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServiceDirectory } from './components/ServiceDirectory';
import { EstimateCalculator } from './components/EstimateCalculator';
import { WhyChoosePMW } from './components/WhyChoosePMW';
import { TestimonialsAndTrust } from './components/TestimonialsAndTrust';
import { ScheduleServiceModal } from './components/ScheduleServiceModal';
import { WhatsAppButton } from './components/WhatsAppButton';
import { Footer } from './components/Footer';

export default function App() {
  const [selectedServiceIds, setSelectedServiceIds] = useState<string[]>([
    'hm-1', // Drywall Repair
    'pnt-1', // Interior Painting
    'prev-1' // Gutter Cleaning
  ]);

  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);

  const [attachedEstimate, setAttachedEstimate] = useState<{
    propertyType: string;
    totalMin: number;
    totalMax: number;
    summary: string;
  } | null>(null);

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const toggleService = (id: string) => {
    setSelectedServiceIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleOpenScheduleWithEstimate = (details: {
    propertyType: string;
    totalMin: number;
    totalMax: number;
    summary: string;
  }) => {
    setAttachedEstimate(details);
    setIsScheduleModalOpen(true);
  };

  const handleOpenScheduleGeneral = () => {
    setAttachedEstimate(null);
    setIsScheduleModalOpen(true);
  };

  const handleOpenEstimator = () => {
    navigate('/estimator');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased selection:bg-blue-600 selection:text-white">
      {/* Sticky Top Navigation */}
      <Navbar
        onOpenSchedule={handleOpenScheduleGeneral}
        onOpenEstimator={handleOpenEstimator}
      />

      <Routes>
        <Route path="/" element={
          <>
            <HeroSection
              onOpenEstimator={handleOpenEstimator}
              onOpenSchedule={handleOpenScheduleGeneral}
            />
            <WhyChoosePMW onOpenSchedule={handleOpenScheduleGeneral} />
            <TestimonialsAndTrust />
          </>
        } />
        <Route path="/services" element={
          <ServiceDirectory
            selectedServiceIds={selectedServiceIds}
            onToggleService={toggleService}
            onOpenEstimator={handleOpenEstimator}
            onOpenSchedule={handleOpenScheduleGeneral}
          />
        } />
        <Route path="/estimator" element={
          <EstimateCalculator
            selectedServiceIds={selectedServiceIds}
            onToggleService={toggleService}
            onOpenScheduleWithEstimate={handleOpenScheduleWithEstimate}
          />
        } />
      </Routes>

      {/* Footer */}
      <Footer
        onOpenSchedule={handleOpenScheduleGeneral}
        onOpenEstimator={handleOpenEstimator}
      />

      {/* Floating WhatsApp Quick Chat Button */}
      <WhatsAppButton />

      {/* Schedule Service & Estimate Booking Modal */}
      <ScheduleServiceModal
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        initialEstimateDetails={attachedEstimate}
      />
    </div>
  );
}
