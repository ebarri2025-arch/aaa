/* QCR published frontend, preserved to match charlotteqcr.com. */
import "./index.css";
import "./qcr/application.js";
