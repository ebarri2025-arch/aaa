import express from 'express';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';

const app = express();
const port = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'Quality Construction & Restoration LLC' }));
// QCR forms send directly through the existing Web3Forms integration.
// The uploaded demo's public customer-data and hardcoded admin endpoints are not used.
app.use('/api', (_req, res) => res.status(404).json({ error: 'Endpoint not available' }));
app.get('/estimator', (_req, res) => res.redirect(301, '/calculator'));

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, { dotfiles: 'deny' }));
    app.get('*', (req, res) => {
      if (path.extname(req.path)) return res.sendStatus(404);
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
  app.listen(port, '0.0.0.0', () => console.log(`QCR website: http://localhost:${port}`));
}
startServer();
